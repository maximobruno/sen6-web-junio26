# Novedades

## V1 (oct 2026)
- Primera versión: ficha del canal, entrenamiento con textos propios y de la competencia (huella de voz, mapa del nicho, lista negra anti-IA, firma), recorrido guiado de 7 pasos, análisis de guiones con semáforo, guion en otras estructuras y salidas.
