# Estructuras (20)

> Regla de oro: estas son FUNCIONES y FÓRMULAS. Nunca copies frases de ejemplo: escribí todo con la huella de voz del canal.

Fuente: 46 outliers faceless (24 ES, 22 EN), 23 oct 2026. `pct` = posición aproximada en el video.

## Elegir rápido

| id | en una línea | ideal para | duración | frecuencia |
|---|---|---|---|---|
| `misterio-en-capas` | Cada bloque abre una puerta y detrás aparece otra más rara. | misterio, arte, arqueología, geografía con dato raro, investigación | 12-25 min | es 3 · en 0 |
| `investigacion-con-pistas` | El video como escena del crimen: cada dato es una pista que el espectador junta. | arte, true crime, ciencia con misterio, historia, análisis de objetos | 8-18 min | es 3 · en 1 |
| `viaje-del-heroe-corto` | Un protagonista, un ascenso, una caída y lo que queda. | biografías, deportes, música, empresas (auge y caída), historias de superación | 13-25 min | es 3 · en 1 |
| `empezar-por-el-final` | Mostrás el desenlace primero; el video es el cómo. | true crime, casos resueltos, biografías trágicas, empresas que quebraron | 15-28 min | es 2 · en 1 |
| `mito-vs-realidad` | Lo que todos creen, desarmado con fuentes, hasta la explicación de por qué ganó el mito. | historia, ciencia, finanzas, empresas, cultura popular | 14-25 min | es 2 · en 2 |
| `antes-y-despues` | De esto a esto: ¿cómo pasó? | historia de países, geografía, empresas, ciudades, transformaciones | 15-35 min | es 1 · en 0 |
| `cuenta-regresiva` | Del número más alto al 1: el peor (o el mejor) queda para el final. | listas, empresas en caída, curiosidades, what if, rankings | 10-30 min | es 1 · en 2 |
| `de-simple-a-profundo` | Empezás por lo que todos ven y bajás escalón por escalón hasta lo que da vértigo. | ciencia, espacio, explicativos, geografía, economía | 9-22 min | es 1 · en 4 |
| `versus` | Dos (o más) lados enfrentados y una pregunta: ¿quién gana? | tecnología, economía, países, deportes, explicativos estilo Vox | 15-33 min | es 1 · en 1 |
| `problema-solucion` | Un problema concreto, las soluciones que fallaron y la que (quizás) funciona. | naturaleza, psicología, ciudades, salud general (con fuentes), finanzas personales | 12-20 min | es 1 · en 1 |
| `pero-entonces` | Cada bloque termina en 'pero' (algo se complica) o 'entonces' (consecuencia), nunca en 'y después'. | negocios, economía, crisis, historia política | 12-20 min | es 0 · en 1 |
| `historia-mas-leccion` | Contás una vida o un hecho completo y al final lo resignificás. | biografías de personajes secundarios, historia social, psicología, documentales largos | 20-45 min | es 0 · en 1 |
| `biografia-por-capitulos` | Una vida dividida en capítulos con título hablado; cada uno termina anunciando el siguiente golpe. | biografías, deportes, música, celebridades, personajes históricos | 18-30 min | es 0 · en 2 |
| `capitulos-con-pregunta-puente` | Cada capítulo termina con una pregunta que solo responde el siguiente. | ciencia, espacio, tecnología, historia de inventos | 15-25 min | es 1 · en 0 |
| `escenario-por-fases` | Un hipotético o un futuro posible contado como línea de tiempo: minuto 0, día 1, fase 3… | what if, ciencia, tecnología, clima, catástrofes hipotéticas | 13-25 min | es 1 · en 1 |
| `antologia-de-casos` | Varias mini historias completas, cada una con su propio gancho y remate, unidas por un criterio. | misterios, curiosidades, productos, desapariciones, historias raras | 20-90 min | es 1 · en 1 |
| `recorrido-guiado` | Visita de afuera hacia adentro (de una máquina, una obra, un lugar) o de punta a punta de una jornada. | tecnología, oficios, arte, lugares extremos, cómo funciona | 8-15 min | es 1 · en 2 |
| `diseccion-elemento-por-elemento` | Una sola imagen (cuadro, foto, documento) recorrida figura por figura; cada una es una mini revelación. | arte, fotografía histórica, portadas, mapas, documentos | 6-10 min | es 1 · en 0 |
| `lista-de-menor-a-mayor` | Los ítems agrupados en bloques de impacto creciente: lo leve primero, lo que duele al final. | finanzas personales, hábitos, consejos, consumo, salud general (con fuentes) | 8-14 min | es 1 · en 0 |
| `lista-de-senales` | 'Las señales de que sos (o conocés a) alguien así': cada señal se encadena con la anterior. | psicología, relaciones, personalidad, bienestar | 12-18 min | es 0 · en 1 |

Recomendá 2-3 según formato, duración y lo que el alumno ya usó (rotar estructuras evita el riesgo de 'contenido no auténtico').

## Misterio en capas · `misterio-en-capas`

**Para qué:** Sostener un video largo sobre un enigma sin resolverlo de golpe: cada capa responde algo y deja una pregunta más profunda.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Presentás el enigma con un dato concreto que no cierra. |
| 5 | re-gancho | Avisás qué tipo de cosas vas a revelar, sin decir cuáles. |
| 10 | contexto | Lo mínimo para entender: lugar, época, quién. |
| 22 | revelacion | Primera capa: una respuesta chica y verificable. |
| 35 | giro | Esa respuesta abre una pregunta mayor o derriba lo que se creía. |
| 50 | revelacion | Segunda y tercera capa, cada una más rara que la anterior. |
| 70 | climax | La capa más profunda: el hallazgo que cambia la lectura de todo. |
| 85 | contexto | Hipótesis honestas: qué se sabe, qué no, quién especula. |
| 95 | cierre | La última puerta sigue cerrada: imagen final o pregunta abierta. |

**Errores comunes:** Prometer una capa 'impactante' y entregar un dato menor. · Que todas las capas tengan el mismo peso: tiene que escalar. · Cerrar con 'nunca lo sabremos' sin haber dado ninguna respuesta parcial. · Anunciar cada capa con la misma frase-puente.

**Ejemplo real (parafraseado):** Misterio/arqueología (ES, 15 min): un canal chico cuenta los tres robots que entraron, en años distintos, por un conducto de una pirámide. Cada robot es una capa: el primero encuentra una piedra, el segundo descubre otra detrás, el tercero ve marcas pintadas. Cierra sin resolver: la segunda piedra sigue sellada.

## Investigación con pistas · `investigacion-con-pistas`

**Para qué:** Convertir un análisis (una obra, un caso, un fenómeno) en un juego de detective donde el espectador siente que descubre.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Señalás algo concreto que todos vieron y nadie entendió. |
| 6 | re-gancho | Proponés el marco: 'vamos a mirarlo como evidencia'. Plantás una pista que se cobra al final. |
| 12 | contexto | Quién, cuándo, para qué: la escena antes del hecho. |
| 28 | revelacion | Primera pista: un detalle que el espectador puede comprobar. |
| 42 | revelacion | Segunda pista que confirma o complica la primera. |
| 55 | giro | Aparece un dato que desarma la teoría fácil. |
| 72 | climax | Se juntan las pistas: la lectura completa. |
| 90 | cierre | Cobrás la pista plantada y devolvés la pregunta al espectador. |

**Errores comunes:** Dar pistas que el espectador no puede ver ni verificar. · Olvidarse de cobrar la pista plantada al principio. · Afirmar como prueba algo que es una teoría. · Pistas sin orden: tienen que construir una sola conclusión.

**Ejemplo real (parafraseado):** Arte (ES, 8,5 min): un canal de menos de mil suscriptores analiza un cuadro barroco 'como escena del crimen'. Cada fruta y cada sombra es una pista; la más fuerte es una forma escondida en la canasta. El giro es biográfico: el pintor comete un crimen y repinta la escena más oscura.

## Viaje del héroe corto · `viaje-del-heroe-corto`

**Para qué:** Contar la vida de una persona (o empresa) como arco emocional: el espectador se queda por saber cómo termina alguien que ya le importa.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Una escena fuerte del medio o del final de la historia. |
| 5 | re-gancho | 'Eso no fue lo peor' o 'para entenderlo hay que volver al principio'. |
| 10 | contexto | Origen humilde o herida de infancia: lo que lo explica. |
| 25 | giro | El llamado: alguien lo descubre, una oportunidad, una apuesta. |
| 38 | climax | La cima: el éxito con su detalle más memorable. |
| 55 | giro | La grieta: rival, traición, error, enfermedad. |
| 70 | revelacion | El lado que casi nadie cuenta. |
| 85 | giro | Golpe final o redención. |
| 95 | cierre | Volvés a la escena del inicio con otra mirada + pregunta o derivación. |

**Errores comunes:** Contar la vida en orden de Wikipedia sin conflicto. · Un protagonista sin defecto: no genera tensión. · Meter todos los datos: elegí los que mueven el arco. · Cerrar con un resumen de logros en vez de una imagen.

**Ejemplo real (parafraseado):** Deportes (ES, 14 min): la historia de un surfista campeón abre con un chisme de celebridad y enseguida dice que esa no fue su herida más profunda. Va dosificando el 'lado oscuro' en capas (padre, hija, rival) y cierra volviendo al chico que dormía afuera de su casa.

## Empezar por el final · `empezar-por-el-final`

**Para qué:** Cuando el final es fuerte pero el camino lo es más: el espectador sabe qué pasó y se queda por cómo y por qué.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El desenlace en escena: el hallazgo, la conferencia, la muerte, la quiebra. |
| 4 | giro | Un dato que hace la pregunta central: '¿cómo llegó hasta acá?'. |
| 8 | re-gancho | Formulás la pregunta que va a guiar todo el video. |
| 12 | contexto | Volvés atrás: quién era, qué quería. |
| 35 | giro | La primera versión oficial o el primer intento, que después se cae. |
| 50 | revelacion | La prueba o el dato que cambia el rumbo. |
| 70 | climax | El detalle más escalofriante o la confirmación. |
| 92 | cierre | Volvés a la escena inicial; ahora pesa distinto. |

**Errores comunes:** Revelar también el cómo en el gancho: no queda nada que esperar. · No volver nunca a la escena inicial. · En casos reales: afirmar culpas que la justicia no confirmó (usá 'presunto', 'según el expediente').

**Ejemplo real (parafraseado):** True crime (EN, 18,6 min): un caso frío resuelto 61 años después arranca con la frase de la conferencia de prensa final, resume el crimen en 40 segundos y avisa 'así lo encontraron'. Un personaje (la hermana que llamaba cada año) sostiene la emoción hasta el cierre, que repite la imagen del principio.

## Mito contra realidad · `mito-vs-realidad`

**Para qué:** Dar la sensación de 'ahora sé la verdad'. Funciona cuando el mito es conocido y la realidad es más interesante.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | La versión que todos conocen, contada con una escena o una cifra. |
| 5 | re-gancho | Pregunta central: si la verdad era otra, ¿por qué ganó la leyenda? |
| 10 | contexto | Lo indiscutido: el piso de datos sobre el que vas a pararte. |
| 30 | revelacion | Lo que dicen los registros reales. |
| 45 | giro | Mitos derribados uno por uno, con su fuente. |
| 60 | climax | El hecho documentado más fuerte. |
| 75 | giro | Escuchás a quien tendría interés en sostener el mito, y tampoco puede. |
| 88 | revelacion | Respondés la pregunta central entera. |
| 96 | cierre | Imagen final que resume la paradoja. |

**Errores comunes:** Derribar un mito que nadie cree (hombre de paja). · Reemplazar un mito por otro sin fuentes. · Tono burlón con quien creía el mito: aleja. · No explicar por qué ganó la versión falsa.

**Ejemplo real (parafraseado):** Historia (ES, 23 min): un documental sobre los verdaderos espías del Japón feudal abre con una invasión de decenas de miles de soldados y plantea la pregunta: si la verdad era otra, ¿por qué ganó la leyenda? Desmiente los mitos con un 'Falso.' seco antes de cada uno y la responde casi al final.

## Antes y después · `antes-y-despues`

**Para qué:** Ordenar una cronología larga (un país, una empresa, una ciudad) alrededor de una sola pregunta y una tesis que se repite.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El estado actual con una comparación absurda + 'hace X años no existía'. |
| 4 | re-gancho | Ráfaga de personajes o momentos que vas a ver + tesis en una frase. |
| 10 | contexto | El punto cero: lo poco que había. |
| 25 | giro | La primera catástrofe o cambio de rumbo. |
| 40 | revelacion | El protagonista inesperado del crecimiento. |
| 55 | climax | El momento de mayor peligro o gloria. |
| 75 | giro | La transformación moderna. |
| 96 | cierre | Volvés a la tesis y la conectás con hoy. |

**Errores comunes:** Cronología sin tesis: se vuelve una clase. · Épocas del mismo largo: comprimí lo aburrido, estirá lo dramático. · No abrir cada era con un personaje y un rasgo memorable.

**Ejemplo real (parafraseado):** Historia/geografía (ES, 31 min): cómo se formó el país más grande del mundo. Abre con el tamaño actual y 'hace mil años no existía'. La tesis (crecer para no ser invadido) se repite y le da hilo a 30 minutos; cada era abre con un personaje y una rareza.

## Cuenta regresiva · `cuenta-regresiva`

**Para qué:** Dar una barra de progreso visible: el espectador sabe cuánto falta y quiere llegar al número 1.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El fenómeno que une a todos los ítems + anuncio del número. |
| 4 | contexto | El criterio común: por qué estos y no otros. |
| 6 | re-gancho | 'El primero ya muestra lo extremo que es esto'. |
| 10 | revelacion | Primeros ítems, rápidos y fuertes. |
| 45 | re-gancho | Cambio de tramo: 'desde acá pasa otra cosa'. |
| 75 | giro | Un ítem que rompe el patrón (el intruso). |
| 85 | climax | El número 1. |
| 95 | cierre | Repaso ultrarrápido + qué tienen en común. |

**Errores comunes:** Ítems sin hilo: lista suelta. · Poner el mejor ítem al principio y vaciar el final. · Todos los ítems del mismo largo y tono: monotonía. · Repetir 'número X' con la misma fórmula de entrada.

**Ejemplo real (parafraseado):** Empresas (ES, 27 min, outlier de más de 1.000x): quince cadenas de restaurantes en caída. Un solo criterio (el cliente ya no siente que valga lo que paga) las convierte en análisis. En el tramo final mete un supermercado entre restaurantes para romper la monotonía.

## De lo simple a lo profundo · `de-simple-a-profundo`

**Para qué:** Explicar un tema complejo sin perder a nadie: cada escalón responde una pregunta y deja otra más filosa.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Algo cotidiano o visible + una contradicción que no cierra. |
| 6 | contexto | Lo básico, en escala humana. |
| 15 | re-gancho | 'Ahora la escala se vuelve rara de verdad'. |
| 30 | revelacion | Primer escalón profundo con comparación cotidiana. |
| 45 | re-gancho | Falso final: 'esto tiene que ser todo, ¿no? Ni cerca'. |
| 60 | giro | Volvés a la contradicción del inicio. |
| 75 | climax | La explicación que la resuelve. |
| 92 | cierre | Reflexión o vuelta a la escena cotidiana del inicio. |

**Errores comunes:** Saltar escalones: el espectador se pierde y se va. · Cifras sin comparación cotidiana. · Plantear la contradicción y no resolverla nunca. · Empezar ya en lo profundo.

**Ejemplo real (parafraseado):** Ciencia/espacio (EN, 15,6 min): arranca en una persona y hace zoom hasta billones de galaxias; en el camino planta dos datos que no pueden ser ciertos juntos y no los resuelve hasta el minuto 11. Cada salto usa una comparación casera (en auto, una moneda) y un falso final que se rompe.

## Versus · `versus`

**Para qué:** Dar tensión a temas técnicos o de actualidad poniendo rivales, caminos o países frente a frente.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El retador y el gigante, o el país que muestra el futuro del otro. |
| 5 | contexto | Qué tan grande es la ventaja del favorito. |
| 13 | re-gancho | Pregunta central + mapa: 'hay tres caminos y un cuarto'. |
| 20 | revelacion | Camino o argumento 1. |
| 38 | giro | Honestidad: lo que no está resuelto del retador. |
| 50 | revelacion | Caminos 2 y 3. |
| 75 | giro | Un dato que reconfigura la pelea (son rivales y socios a la vez). |
| 88 | climax | Respondés el título con matices. |
| 96 | cierre | Capa emocional o histórica + '¿cuál te parece más fuerte?'. |

**Errores comunes:** Hinchada: si se nota de qué lado estás desde el minuto 1, se pierde la tensión. · Comparar con datos de fechas distintas. · Responder 'depende' sin compromiso.

**Ejemplo real (parafraseado):** Tecnología (ES, 33 min): un fabricante japonés contra el monopolio de una máquina clave para chips. Ordena el video con un mapa explícito (cuatro caminos), admite límites antes de concluir y responde el título con matices: no lo reemplaza, pero rompió la creencia de que no había alternativa.

## Problema y solución · `problema-solucion`

**Para qué:** Temas donde hay algo roto: el espectador quiere saber por qué no se arregló y qué se puede hacer. También autoayuda práctica.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El problema con un superlativo raro o una situación que te toca. |
| 4 | giro | El detalle que lo trabó todo (una foto, una ley, un hábito). |
| 10 | contexto | Lo conocido, contado rápido. |
| 25 | revelacion | Por qué el problema crece: la causa de fondo. |
| 40 | revelacion | Las soluciones que fallaron, con recuento. |
| 55 | giro | El daño invisible que nadie medía. |
| 70 | climax | Los bandos enfrentados o la solución real. |
| 92 | cierre | Dilema al espectador o reto concreto. |

**Errores comunes:** Solución mágica: pierde credibilidad. · En salud o finanzas: dar consejos sin fuentes o contra autoridades sanitarias. · Mostrar un solo bando del problema.

**Ejemplo real (parafraseado):** Naturaleza (ES, 16 min): los hipopótamos descendientes de un zoológico privado en Colombia. Pasa rápido por lo conocido, cuenta las soluciones fallidas con un recuento brutal que se repite como estribillo y cierra con un dilema: ¿firmarías la orden o el santuario?

## Pero / entonces · `pero-entonces`

**Para qué:** Causalidad pura: la historia avanza por consecuencias y obstáculos. Ideal para auges y caídas de empresas o crisis económicas.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Un hecho récord + 12 meses después, lo contrario. |
| 6 | giro | 'Parece X, pero no: el problema empezó mucho antes'. |
| 10 | contexto | El origen del poder del protagonista. |
| 30 | giro | Pero: la decisión que llegó tarde. |
| 50 | re-gancho | Entonces: la apuesta grande que parecía salvarlo. |
| 60 | revelacion | Pero había una trampa. |
| 72 | climax | La dependencia o el riesgo que lo define todo. |
| 90 | cierre | Tres escenarios posibles y una frase que invierte el poder. |

**Errores comunes:** Bloques unidos por 'y además': se cae la tensión. · Usar 'pero' literal en cada transición: es la lógica, no la palabra. · Escenarios finales sin probabilidad ni datos.

**Ejemplo real (parafraseado):** Negocios (EN, 15,6 min): el derrumbe de una gran tecnológica de bases de datos. Arranca con una suba histórica de la acción y, un año después, la mitad del valor. Alterna 'pero' y 'entonces' cada uno o dos minutos y cierra con tres escenarios.

## Historia más lección · `historia-mas-leccion`

**Para qué:** Videos largos y empáticos donde la recompensa es una mirada nueva sobre alguien o algo, no un dato.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Una imagen (foto, objeto) donde algo no encaja. |
| 3 | contexto | Quién era antes del conflicto. |
| 11 | re-gancho | 'Antes de ver qué pasó, tenés que entender el mundo al que entró'. |
| 25 | giro | Las primeras grietas. |
| 35 | climax | La noche o el hecho que lo cambió todo. |
| 55 | giro | La exposición pública y su costo. |
| 70 | revelacion | Lo que hizo después, que casi nadie cuenta. |
| 85 | cierre | Qué le quitaron y qué quedó: la lección, sin sermón. |
| 98 | cta | Pedido breve. |

**Errores comunes:** Moraleja de manual ('y así aprendemos que…'). · Lección que no sale de la historia sino que se pega al final. · Juzgar al personaje en vez de mostrarlo.

**Ejemplo real (parafraseado):** Biografías (EN, 41 min): la historia de la esposa olvidada de una familia política famosa. Abre con una foto donde la sonrisa no llega a los ojos, cada capítulo termina con una frase-puente que anuncia algo peor y cierra dando vuelta la etiqueta pública con la imagen de la foto inicial.

## Biografía por capítulos · `biografia-por-capitulos`

**Para qué:** Biografías largas: los capítulos marcan el avance, permiten saltar sin perderse y cada cierre de capítulo funciona como re-gancho.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Un objeto o lugar que no encaja con la vida del protagonista, o un collage de archivo. |
| 3 | cta | Opcional: bienvenida con identidad de comunidad. |
| 5 | contexto | Capítulo 1: infancia y herida de origen. |
| 15 | revelacion | Capítulo 2: el talento descubierto. |
| 25 | climax | Capítulo 3: la gloria. |
| 32 | re-gancho | Presagio: 'lo que le dio con una mano se lo iba a quitar con la otra'. |
| 45 | giro | Capítulos del medio: la caída, el escándalo, el secreto. |
| 80 | giro | El capítulo más raro (lo que pasó después de su muerte, el legado). |
| 95 | cierre | Volvés al objeto o lugar del gancho + pregunta que divide. |

**Errores comunes:** Capítulos sin frase de cierre que empuje al siguiente. · Títulos de capítulo genéricos ('Sus inicios'). · Demasiados capítulos chicos: agrupá.

**Ejemplo real (parafraseado):** Deportes (EN, 21 min): un atleta enterrado en un pueblo que nunca pisó. Diez capítulos numerados, cada uno termina anunciando el siguiente golpe; el cierre vuelve a la tumba del inicio. Variante ES (biografía musical, 23 min): capítulos con título hablado y pregunta al público al final de cada uno.

## Capítulos con pregunta puente · `capitulos-con-pregunta-puente`

**Para qué:** Explicativos largos sin punto de salida natural: el espectador nunca llega a un final de bloque sin una duda nueva.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Cifra extrema traducida a algo cotidiano + 'al final te digo por qué, y no es lo que creés'. |
| 5 | contexto | Capítulo 1: el origen. |
| 16 | re-gancho | Pregunta puente: '¿cómo hizo para…?'. |
| 20 | revelacion | Capítulo 2: los logros, que abren otra pregunta. |
| 30 | giro | Corregís un error muy extendido. |
| 47 | climax | La crisis y cómo se resolvió. |
| 73 | giro | Honestidad: lo que no está resuelto. |
| 90 | revelacion | Cerrás el loop del gancho con una respuesta humana, no técnica. |
| 96 | cta | Pregunta creativa para comentarios. |

**Errores comunes:** Preguntas puente que se responden en la misma frase. · Prometer al final algo que no se cumple. · Capítulos que no necesitan del anterior.

**Ejemplo real (parafraseado):** Ciencia/espacio (ES, 21 min): una sonda de los años 70 que sigue funcionando. Cada capítulo cierra con una pregunta ('si nada la frena, ¿por qué no necesita motor?') y el gancho promete una respuesta final que resulta ser emocional: sigue viva por la paciencia de las personas que la cuidan.

## Escenario por fases · `escenario-por-fases`

**Para qué:** Los '¿qué pasaría si…?' y los escenarios de riesgo: la línea de tiempo funciona como barra de progreso mental.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Escena cotidiana en segunda persona + el evento imposible, o 'no va a ser como en las películas'. |
| 5 | contexto | Reglas honestas del experimento o autoridad de quién lo plantea. |
| 15 | revelacion | Fase 1: lo que nadie nota. |
| 30 | giro | Fase 2: la primera consecuencia en cascada. |
| 50 | revelacion | Fases del medio, cada una con un detalle concreto y local. |
| 70 | climax | La fase extrema. |
| 78 | giro | 'Parece el final feliz, pero no lo es': la consecuencia tardía. |
| 87 | revelacion | Prueba real (un hecho histórico parecido) que hace creíble la ficción. |
| 95 | cierre | Lo que damos por sentado + derivación a otro escenario. |

**Errores comunes:** Presentar el escenario como predicción segura. · Fases sin consecuencias concretas (solo adjetivos). · Alarmismo: en temas de riesgo, separá lo que se sabe de lo que no.

**Ejemplo real (parafraseado):** Ciencia (ES, 24 min): ¿qué pasaría si el Sol desapareciera una semana? Línea de tiempo del minuto 0 al día 7, localizada en ciudades latinoamericanas, con un caso histórico real como prueba. Variante EN (tecnología, 18 min): un escenario de riesgo de IA fase por fase, citando expertos con nombre.

## Antología de casos · `antologia-de-casos`

**Para qué:** Videos largos de 'X casos' donde se puede entrar en cualquier punto: cada caso es un mini video.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Regla general + la excepción imposible + número de casos + dos adelantos contrastantes. |
| 2 | revelacion | Caso 1, empezando por su momento más raro. |
| 10 | re-gancho | Puente que contrasta el tono: 'el próximo va para el otro lado'. |
| 30 | revelacion | Casos del medio, alternando ritmo y tono. |
| 60 | re-gancho | Cambio de subcategoría para renovar la promesa. |
| 75 | giro | Opinión personal del narrador o caso que molesta. |
| 88 | climax | El caso final, el más fuerte o el más silencioso. |
| 97 | cierre | Reflexión breve + pregunta + derivación. |

**Errores comunes:** Casos que se cuentan todos igual (misma entrada, mismo remate). · Sin puentes: se siente como lista plana. · Criterio flojo que no justifica juntar los casos.

**Ejemplo real (parafraseado):** Curiosidades (ES, 23 min): veinticinco productos que desaparecieron por funcionar demasiado bien. Cada ítem es una mini historia con su ironía final (micro-gancho cada 50 segundos aprox.) y el narrador mete opiniones personales para romper el ritmo. Variante EN (misterios, 97 min): diez desapariciones, cada una empieza por el final.

## Recorrido guiado · `recorrido-guiado`

**Para qué:** Explicar cómo funciona algo o cómo se vive en un lugar extremo: cada parada responde una pregunta que el espectador ya se hacía.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | La escala del objeto o la restricción extrema ('no puede bajar') + qué vas a ver. |
| 5 | contexto | Principio básico o primera parada. |
| 15 | revelacion | Parada 2: un detalle contraintuitivo. |
| 30 | re-gancho | 'Ahora veamos qué hay adentro' o 'la parte que más me sorprendió'. |
| 45 | revelacion | Paradas del medio, cada una con una pregunta concreta. |
| 62 | giro | 'Pero acá está la trampa': el único conflicto real. |
| 75 | climax | Cómo se resuelve ese conflicto, o la pregunta incómoda que todos tienen. |
| 92 | cierre | Salida del recorrido y resumen en una frase que responde el título. |

**Errores comunes:** Recorrido sin conflicto: se vuelve manual de instrucciones. · Paradas en orden arbitrario. · Esquivar la pregunta incómoda que el título insinúa.

**Ejemplo real (parafraseado):** Tecnología (EN, 12 min): por dentro de un molino eólico, de las aspas al transformador; el conflicto (viento variable contra frecuencia exacta de la red) llega en el último tercio. Variante jornada (ES, 8 min, outlier enorme): ocho horas de un operador de grúa a 200 metros, incluida la pregunta del baño.

## Disección elemento por elemento · `diseccion-elemento-por-elemento`

**Para qué:** Videos cortos y densos de análisis visual: el espectador mira junto con el narrador y cada elemento aporta un sentido nuevo.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | El encargo o la situación + la paradoja de lo que salió. |
| 10 | contexto | Quién lo hizo y qué lo volvía capaz de hacerlo. |
| 20 | re-gancho | Invitás a acercarse y mirar despacio. |
| 26 | revelacion | Elemento 1: lo que está fuera de lugar. |
| 38 | revelacion | Elemento 2: dónde está la luz y por qué. |
| 50 | revelacion | Elementos 3 y 4: gestos, ausencias. |
| 80 | climax | El elemento guardado para el final (la firma, el autor escondido). |
| 92 | cierre | Pregunta abierta que resignifica la imagen. |

**Errores comunes:** Describir lo que se ve sin decir qué significa. · No guiar la mirada: decir dónde mirar antes de explicar. · Gastar el mejor elemento al principio.

**Ejemplo real (parafraseado):** Arte (ES, 6,6 min): un retrato real que humilló a la familia que lo encargó. Recorre la tela figura por figura (cada una, unos 40 segundos) y guarda para el final al pintor autorretratado en la sombra.

## Lista de menor a mayor (por bloques) · `lista-de-menor-a-mayor`

**Para qué:** Listas prácticas (gastos, hábitos, errores) que no se sienten planas: cada bloque sube la apuesta.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Algo que te pasa sin que lo notes + anuncio de la lista. |
| 3 | contexto | Por qué ahora: el cambio de época que lo explica. |
| 6 | re-gancho | Promesa: vas a mirar algo cotidiano de otra forma. |
| 9 | revelacion | Bloque 1: los ítems chicos, rápidos. |
| 35 | re-gancho | Aviso de que el siguiente cálculo va a doler. |
| 40 | revelacion | Bloque 2: los ítems grandes. |
| 62 | re-gancho | 'Quedan los dos más polémicos'. |
| 66 | climax | El ítem más fuerte, con cálculo en voz alta. |
| 82 | revelacion | La idea que une todo (el insight). |
| 92 | cierre | Tarea concreta + pregunta confesional. |

**Errores comunes:** Ítems sin cifras ni ejemplo concreto. · Tono de sermón: mostrá el cálculo, no retes. · Consejos financieros personalizados: mantenete en lo general y educativo.

**Ejemplo real (parafraseado):** Finanzas personales (ES, 11 min): diez gastos que ya no valen la pena, agrupados en tres bloques de impacto creciente. Cálculos en voz alta con una muletilla de marca propia del canal, y cierre con una tarea concreta (revisar tres meses de gastos).

## Lista de señales · `lista-de-senales`

**Para qué:** Psicología y comportamiento: el espectador se reconoce, se siente descrito y comenta cuál le tocó.

| % | función | qué pasa |
|---|---|---|
| 0 | gancho | Retrato de un tipo de persona con detalles en los que te reconocés + 'no es lo que creés'. |
| 6 | contexto | Promesa y origen del rasgo. |
| 20 | revelacion | Señal 1, con un ejemplo cotidiano muy concreto. |
| 32 | revelacion | Señal 2, que nace de la anterior. |
| 50 | revelacion | Señales 3 a 5, cada una más íntima. |
| 68 | climax | El costo oculto del rasgo. |
| 78 | giro | Qué hacer: dos o tres principios aplicables. |
| 90 | cierre | Metáfora que resignifica + validación, sin juzgar. |
| 97 | cta | '¿Qué señal te representa?' |

**Errores comunes:** Señales vagas tipo horóscopo ('a veces te sentís cansado'). · Diagnosticar: no es un video clínico; evitá términos médicos como etiqueta. · Señales sueltas sin conexión entre sí.

**Ejemplo real (parafraseado):** Psicología (EN, 16 min): las personas 'demasiado conscientes'. Cinco señales encadenadas ('eso lleva a la señal tres'), ejemplos concretos (un mensaje del jefe) y un cierre que valida en vez de juzgar, lo que dispara comentarios.
