# Ritmo

| | ES | EN |
|---|---|---|
| Palabras por minuto (promedio) | 145 | 154 |
| Mediana | 149 | 154 |
| Rango observado | 105-170 | 128-180 |
| Duración del gancho | ~70 s hasta el primer bloque de contexto (los más cortos, 20-40 s; los documentales llegan a 1,5 min) | ~50 s |
| Duración de los videos | Mediana ~21 min (rango 6,6 a 33 min) | Mediana ~17 min (rango 8,4 a 97 min) |

Nota ES: Documentales largos y solemnes ~110-125; listas y curiosidades ~150-165.

**Cálculo:** Minutos de video ≈ palabras ÷ ppm. Ejemplo: 2.200 palabras a 145 ppm ≈ 15 min. Para el guion de un video de 12 min a 145 ppm: ~1.740 palabras.

## Tabla rápida (ES, 145 ppm)

| minutos | palabras |
|---|---|
| 8 | ~1.160 |
| 10 | ~1.450 |
| 12 | ~1.740 |
| 15 | ~2.175 |
| 20 | ~2.900 |
| 25 | ~3.625 |
| 30 | ~4.350 |

## Reglas prácticas

- El gancho entero tiene que caber en 120-170 palabras en español (~50-70 s). Si necesitás más, falta cortar.
- Primer re-gancho antes del minuto 1,5.
- Ningún tramo de más de 3 min sin re-gancho, giro o cambio de tramo (en español apuntá a 1,5-2,5 min).
- Una idea por frase. Frases de más de 30 palabras se pierden al oído: partilas.
- Alterná frases largas con frases secas de 1 a 4 palabras ('Falso.', 'Ocho días.'). El ritmo es variación, no velocidad.
- Cifras: redondeá al decirlas ('casi 300.000') y escribilas como se leen si va a una voz IA.
- Si vas a locutar con ElevenLabs, cortá en tramos de menos de 5.000 caracteres en pausas naturales (fin de bloque).
- Leé el guion en voz alta: donde te trabás, el espectador se va.
- El clímax suele caer entre el 60 % y el 80 % del video; el cierre, en el último 5-10 %.
- Si el ppm de tu guion queda fuera de 105-170, revisá: muy lento aburre, muy rápido no se entiende con imágenes.
