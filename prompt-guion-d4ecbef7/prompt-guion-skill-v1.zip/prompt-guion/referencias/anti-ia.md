# Anti-IA: lista negra de escritura

Uso: en la revisión, marcá cada aparición y proponé el reemplazo **con la voz del canal**. Se suma a la lista negra específica del nicho (clichés detectados en las transcripciones de competidores).

Tipos: frase · estructura · puntuacion · vocabulario. Una aparición aislada puede pasar; tres o más del mismo tipo = el guion suena a IA.

## Frases (22)

| patrón | ejemplo | por qué delata | cómo reemplazarlo |
|---|---|---|---|
| **En un mundo donde…** | En un mundo donde la tecnología avanza a pasos agigantados… | Apertura genérica que sirve para cualquier tema: no dice nada del tuyo. | Arrancá con un hecho, una escena o una cifra del tema concreto. |
| **¿Alguna vez te preguntaste…?** | ¿Alguna vez te preguntaste por qué el cielo es azul? | Es la pregunta de apertura por defecto de los modelos y de miles de videos. | Hacé la afirmación que la pregunta esconde, o una pregunta específica que solo tu video responde. |
| **Imaginá… (abusado)** | Imaginá un lugar donde el tiempo se detiene. | Sirve una vez y con escena concreta; la IA lo usa para todo y sin detalles. | Entrá directo a la escena en presente ('Son las 8. Abrís la canilla y no sale nada'). |
| **Desde tiempos inmemoriales / Desde el principio de los tiempos** | Desde tiempos inmemoriales, el ser humano miró las estrellas. | Relleno de redacción escolar; ningún narrador con voz propia arranca así. | Dale una fecha o un nombre ('En 1610, un profesor de Padua…'). |
| **En definitiva / En conclusión / En resumen** | En definitiva, la historia de Roma es una lección para todos. | Cierre de ensayo escolar; en un video anuncia que podés irte. | Cerrá con una imagen, un dato final o la vuelta al gancho. |
| **Cabe destacar / Vale la pena mencionar / Es importante señalar** | Cabe destacar que el proyecto costó millones. | Muletilla de informe; anuncia en vez de decir. | Decilo directamente: 'El proyecto costó millones'. |
| **Un verdadero testimonio de…** | Este edificio es un verdadero testimonio del ingenio humano. | Calco de 'a testament to', típico de traducción automática y de IA. | Decí qué demuestra en concreto ('lo construyeron sin una sola grúa'). |
| **Y aquí es donde todo cambia** | Y aquí es donde la historia da un giro inesperado. | Bisagra comodín (también es un cliché de retención en todos los nichos). | Decí el hecho que cambia todo, sin anunciarlo. |
| **Nos recuerda que… / Nos invita a reflexionar** | Este caso nos invita a reflexionar sobre la condición humana. | Fórmula de ensayo; le dice al espectador qué pensar. | Hacé una pregunta concreta o dejá la imagen final sola. |
| **Hedging excesivo: podría decirse, en cierta medida, de alguna manera** | Podría decirse que, en cierta medida, fue un éxito. | La IA evita comprometerse; el narrador pierde autoridad. | Afirmá lo que sabés y marcá la duda solo donde existe, con su motivo. |
| **Jugó un papel crucial / desempeñó un rol fundamental** | La religión jugó un papel crucial en su vida. | Calco de 'played a crucial role'; frase hueca. | Decí qué hizo concretamente ('rezaba antes de cada batalla y lo usaba en la propaganda'). |
| **Dejó una huella imborrable / marcó un antes y un después** | Su obra dejó una huella imborrable en la historia. | Cliché de cierre de biografía; no dice cuál huella. | Nombrá la huella: quién lo copió, qué cambió, qué sigue existiendo. |
| **A lo largo de la historia / a lo largo de los siglos** | A lo largo de la historia, muchos intentaron explicarlo. | Generalización sin datos; relleno de transición. | Nombrá dos intentos concretos con fecha. |
| **Un viaje (metafórico) / acompañame en este viaje** | Acompañame en este viaje a través del tiempo. | 'Journey': metáfora comodín de la IA para cualquier tema. | Empezá el recorrido directamente con la primera parada. |
| **Sin lugar a dudas / Indudablemente / Sin duda alguna** | Sin lugar a dudas, fue el mejor de su época. | Refuerzo vacío; si fuera indudable no haría falta decirlo. | El dato que lo prueba ('ganó 14 de 15 finales'). |
| **Ahora bien / Dicho esto / Con esto en mente** | Dicho esto, pasemos al siguiente punto. | Conectores de presentación corporativa. | Cortá y empezá el siguiente bloque con su propio gancho. |
| **Hablemos de… / Exploremos…** | Hablemos de su infancia. | Anuncio de tema sin gancho; la IA lo usa como título hablado. | Abrí el bloque con una escena o pregunta de la infancia. |
| **Personificación abstracta: la historia nos enseña, el destino quiso** | El destino tenía otros planes. | Cliché narrativo de plantilla. | El hecho concreto que cambió los planes. |
| **Final con '¡Hasta la próxima!' y saludo de plantilla** | ¡Gracias por acompañarnos y hasta la próxima aventura! | Despedida genérica igual en miles de canales. | Despedida propia del canal (parte de la firma) o cortar en la última imagen. |
| **(EN→ES) 'Let's dive in' / 'Buckle up' traducidos** | Abróchate el cinturón, porque esto se pone intenso. | Fórmulas de YouTube en inglés pasadas al español literal. | Saltealas: empezá directamente. |
| **(EN→ES) 'Here's the thing' / 'Here's the kicker' → 'Pero aquí está la cosa'** | Pero aquí está la cosa: nadie lo sabía. | Calco literal; en español no se dice así. | 'El tema es que…', 'lo raro es que…', o directamente el dato. |
| **(EN→ES) 'It's worth noting' → 'Vale la pena notar'** | Vale la pena notar que el puente sigue en pie. | Calco de informe en inglés. | 'El puente sigue en pie.' Punto. |

## Estructuras (17)

| patrón | ejemplo | por qué delata | cómo reemplazarlo |
|---|---|---|---|
| **No es solo X, es Y** | No es solo un cuadro, es una ventana al alma de una época. | La estructura retórica más asociada a la IA. Infla en vez de informar. | Decí Y directamente con un dato: 'El cuadro esconde la lista de deudas del pintor'. |
| **No se trata de X; se trata de Y** | No se trata de dinero; se trata de dignidad. | Variante del anterior; falso contraste para sonar profundo. | Mostrá la escena donde se ve la dignidad, sin anunciarla. |
| **Tríos de adjetivos** | Un lugar misterioso, fascinante y aterrador. | La IA agrupa de a tres por reflejo; suena a folleto. | Un solo adjetivo preciso, o ninguno y un detalle. |
| **Enumeraciones de tres perfectas en cada párrafo** | Poder, ambición y traición. Fuego, sangre y cenizas. | La regla de tres usada siempre se vuelve un tic predecible. | Variá: a veces dos, a veces cuatro, a veces uno solo. |
| **Paralelismos simétricos** | Llegó como un desconocido. Se fue como una leyenda. | Frases espejo que suenan a eslogan; usadas en cadena delatan fórmula. | Guardalas para un momento (como mucho una por video) o rompé la simetría. |
| **Preguntas retóricas en cadena** | ¿Qué lo llevó a hacerlo? ¿Fue ambición? ¿Fue miedo? ¿O algo más? | Relleno que simula suspenso sin dar información. | Una sola pregunta, específica, y respondela o dejala colgando a propósito. |
| **La moraleja final forzada** | Y así, esta historia nos recuerda que nunca debemos rendirnos. | La IA cierra todo con una enseñanza universal pegada. | Cerrá con una imagen o un dato del caso; que la lección la saque el espectador. |
| **Cierre tipo resumen escolar** | Hoy vimos su infancia, su carrera y su legado. Espero que te haya gustado. | Repite lo que el espectador acaba de ver; es el cierre por defecto de los modelos. | Ver tipos de cierre: círculo, dilema, gancho al próximo. |
| **Introducción que anuncia el video en vez de empezarlo** | En este video vamos a explorar la historia, las causas y las consecuencias de… | Índice genérico; los outliers anuncian cosas concretas, no categorías. | Si hacés mapa, que sean tres cosas específicas y raras, no 'historia, causas y consecuencias'. |
| **Párrafos todos del mismo largo** | Bloques de 4 frases, 4 frases, 4 frases… | Ritmo uniforme = máquina. La voz humana acelera y frena. | Alterná bloques largos con frases sueltas de una línea. |
| **Gerundios encadenados** | Llegó a la ciudad, conquistando territorios, estableciendo alianzas y cambiando la historia. | Calco del inglés '-ing'; en español es pesado e incorrecto muchas veces. | Verbos conjugados en frases cortas: 'Llegó. Conquistó. Pactó.' |
| **Voz pasiva de traducción** | La ciudad fue fundada por los españoles y fue destruida por un terremoto. | El español oral prefiere activa o 'se'; la pasiva suena a texto traducido. | 'Los españoles fundaron la ciudad. Un terremoto la borró.' |
| **Posesivos innecesarios** | Levantó su mano y abrió sus ojos. | Calco del inglés; en español el posesivo con partes del cuerpo sobra. | 'Levantó la mano y abrió los ojos.' |
| **Datos sin fuente pero con decimales** | El 73,4 % de las personas no lo sabe. | La IA inventa cifras precisas; es el error más peligroso (desinformación). | Verificá cada número con una fuente; si no la hay, sacalo. |
| **Fechas, nombres o citas inventadas (alucinaciones)** | Como dijo Einstein: 'La curiosidad es el motor del universo'. | La IA atribuye frases y fechas con seguridad aunque no existan. | Chequeá cada cita en la fuente original; si no aparece, no va. |
| **Equilibrio forzado: 'por un lado… por otro lado…' en todo** | Por un lado fue un héroe; por otro lado, un villano. | La IA neutraliza todo; el canal pierde postura. | Tomá postura cuando los datos lo permiten y marcá tu opinión como tal. |
| **Apertura con definición de diccionario** | La palabra 'misterio' proviene del griego… | Arranque escolar; ningún outlier abre así. | Escena, dato o pregunta concreta (ver ganchos). |

## Vocabulario (15)

| patrón | ejemplo | por qué delata | cómo reemplazarlo |
|---|---|---|---|
| **Sumergirse / adentrarse** | Hoy nos sumergimos en la fascinante historia de… | Calco del inglés 'dive into', una de las muletillas más típicas de la IA. | 'Hoy te cuento', 'vamos a ver', o directamente empezá a contar. |
| **Fascinante / apasionante / cautivador** | Una historia fascinante que cautivó al mundo. | Adjetivo que le dice al espectador qué sentir en vez de darle motivos. | Sacá el adjetivo y poné el dato que lo vuelve fascinante. |
| **Crucial / fundamental / vital / clave (en cadena)** | Es crucial entender este punto fundamental. | Énfasis vacío repetido; la IA marca todo como importante. | Mostrá la consecuencia: 'si no entendés esto, lo que sigue no tiene sentido'. |
| **Tapiz / rico tapiz** | El rico tapiz de culturas de la región. | Calco de 'tapestry', metáfora favorita de los modelos. | Nombrá las culturas o el cruce concreto. |
| **Navegar (desafíos, complejidades)** | Navegar las complejidades del mercado. | Calco de 'navigate'; en español rioplatense nadie habla así. | 'Lidiar con', 'arreglárselas', 'moverse en', o el verbo concreto. |
| **Panorama / paisaje (en sentido abstracto)** | El panorama tecnológico actual. | Calco de 'landscape'; abstracción que suena a consultora. | Nombrá a los actores: 'hoy tres empresas hacen el 90 %'. |
| **Desentrañar / descifrar los misterios** | Desentrañaremos los misterios de esta civilización. | Verbo solemne de IA ('unravel') para prometer sin concretar. | Prometé la respuesta concreta: 'vas a saber quién lo construyó'. |
| **Intrincado / entramado complejo** | Un intrincado sistema de alianzas. | 'Intricate': adjetivo comodín para no explicar. | Explicá el sistema en una frase simple o con una comparación. |
| **Resonar (con el público, a través del tiempo)** | Su mensaje sigue resonando hoy. | Calco de 'resonate'; vaguedad elegante. | Mostrá dónde aparece hoy (un dato, una cita, un uso). |
| **Increíble / asombroso / impresionante (en serie)** | Un descubrimiento increíble con resultados asombrosos. | Vocabulario neutro de traducción; no tiene registro ni país. | Usá el registro del canal o, mejor, dejá que el dato asombre. |
| **Tuteo o español neutro cuando el canal es voseante (o al revés)** | 'Tú puedes ver aquí…' en un canal que habla de vos. | La IA escribe por defecto en neutro/tuteo; rompe la identidad del canal. | Fijá el registro en la ficha del canal (vos/tú/usted, 'acá'/'aquí') y revisalo línea por línea. |
| **Transiciones de manual: Además, Asimismo, Por otro lado, Sin embargo (en cada párrafo)** | Además… Asimismo… Por otro lado… | Conectores de redacción escrita; al oído suenan a ensayo. | Conectores orales del canal ('y acá', 'el tema es que', 'encima') o ninguno. |
| **Descubrí / explorá / desbloqueá (verbos de marketing)** | Desbloqueá los secretos del éxito. | Lenguaje de anuncio ('unlock', 'discover') traducido. | Verbos concretos del tema: aprender, ver, calcular, entender. |
| **Superlativos en serie: el más grande, el más impactante, el más misterioso** | El caso más misterioso, más perturbador y más impactante de la historia. | Exageración de plantilla; además puede ser engañoso. | Un superlativo comprobable con su fuente, o ninguno. |
| **(EN→ES) 'Spoiler alert' / 'Plot twist'** | Plot twist: era su hermano. | Muletilla anglo gastada en todos los nichos. | Contá el giro con tus palabras y una pausa. |

## Puntuación (6)

| patrón | ejemplo | por qué delata | cómo reemplazarlo |
|---|---|---|---|
| **Abuso de la raya (—)** | El rey —siempre ambicioso— decidió —contra todo consejo— atacar. | La raya larga en serie es una firma visual de texto de IA (y la voz IA la lee mal). | Comas, punto y seguido, o partí la frase. |
| **Dos puntos dramáticos** | Y entonces lo entendió: nada volvería a ser igual. | Revelación con dos puntos en cada párrafo = fórmula. | Usalo poco; probá con punto y una frase corta. |
| **Signos de exclamación en exceso** | ¡Y lo logró! ¡Increíble! | Entusiasmo impostado; en voz IA suena falso. | Que la emoción salga del contenido y de la locución, no del signo. |
| **Puntos suspensivos para crear misterio en cada frase** | Pero lo que encontraron… cambiaría todo… | Suspenso de plantilla; cansa a la tercera vez. | Una pausa marcada en el momento clave, no en cada frase. |
| **Mayúsculas iniciales a lo inglés en títulos y subtítulos** | La Historia Secreta Del Imperio | Convención inglesa que la IA arrastra al español. | En español, mayúscula solo al inicio y en nombres propios (salvo estilo deliberado del canal). |
| **Emojis o lenguaje de redes en el guion hablado** | Esto es 🔥 total. | Los modelos mezclan registros escritos de redes con guion oral. | El guion es para escuchar: todo tiene que poder decirse en voz alta. |

## Chequeo rápido (3 preguntas)

1. ¿Suena a IA? → esta lista.
2. ¿Suena a vos? → comparar con la huella de voz (largo de frase, vos/tú, muletillas, conectores, humor).
3. ¿Suena a la competencia? → frases compartidas con las transcripciones del mapa del nicho.
