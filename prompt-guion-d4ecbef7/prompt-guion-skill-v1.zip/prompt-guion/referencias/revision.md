# Revisión con semáforo

Revisá el guion contra el PERFIL DE CANAL (si lo hay) y la biblioteca. Entregá primero el **resumen** y después el **detalle**. Cada punto amarillo o rojo lleva: dónde (cita corta o minuto), por qué importa (una línea) y el arreglo concreto escrito con la voz del canal. Al final ofrecé: "¿Corrijo los rojos y amarillos?".

## Medidas (calculalas primero)
- Palabras totales y **duración estimada** = palabras ÷ palabras por minuto de su voz (perfil) o de `ritmo.md`.
- **Duración del gancho:** palabras hasta que termina la promesa inicial → segundos.
- **Mapa de retención:** minuto de cada re-gancho, giro y revelación; el hueco más largo sin ninguno.
- Frases de más de 30 palabras; palabras repetidas cerca (misma palabra 3+ veces en 100 palabras).

## Los 10 chequeos
| # | Chequeo | 🟢 | 🟡 | 🔴 |
|---|---|---|---|---|
| 1 | **Gancho** | promesa clara en el tiempo de `ritmo.md`, con contraste | llega tarde o sin promesa | arranca con contexto/saludo/"en este video" vacío |
| 2 | **Estructura** | los beats de la estructura elegida están y en orden | falta un beat o un giro llega tarde | no hay arco: es una lista de datos |
| 3 | **Retención** | re-gancho cada 1,5-3 min; cabo suelto plantado y pagado | algún hueco de 3-4 min | hueco de 4+ min o promesa que nunca se paga |
| 4 | **Ritmo y duración** | dentro de ±10% de lo buscado; frases para decir en voz alta | ±20%; varias frases largas | muy fuera de duración; frases imposibles de decir |
| 5 | **¿Suena a IA?** | 0-1 rasgos de la lista negra | 2-4 | 5 o más (listalos todos) |
| 6 | **¿Suena a vos?** | respeta la huella (registro, largo de frase, muletillas, humor) | se aleja en partes | podría ser de cualquier canal |
| 7 | **¿Suena a tu competencia?** | nada calcado del mapa del nicho | usa 1-2 recursos gastados del nicho | repite frases o estructura de un competidor |
| 8 | **Firma del canal** | aparece donde corresponde | aparece débil | no aparece |
| 9 | **Políticas de YouTube** (`politicas-youtube.md`) | nada sensible o bien tratado | términos/temas que pueden limitar anuncios (sobre todo en los primeros segundos, título y miniatura) | riesgo alto: desinformación, contenido engañoso, repetitivo/producido en masa, o falta avisar contenido sintético realista |
| 10 | **Hechos** | todo dato tiene fuente o lo dio el alumno | datos sin fuente | datos dudosos o inventados → `[VERIFICAR]` |

## Formato de entrega
```
REVISIÓN · <título provisorio> · <palabras> palabras ≈ <min> min (voz de <ppm> ppm)

🟢 Gancho — …
🟡 Retención — hueco de 3:40 entre el min 4 y el 7:40
🔴 ¿Suena a IA? — 6 rasgos: …
…
Lo más urgente: 1) … 2) … 3) …
```
Aclaración fija al final de la parte de políticas: "Esto es una ayuda para revisar, no una garantía: la decisión final la toma YouTube."
