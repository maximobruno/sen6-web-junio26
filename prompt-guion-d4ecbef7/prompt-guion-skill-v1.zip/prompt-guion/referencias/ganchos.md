# Ganchos (24 tipos)

> Regla de oro: estas son FUNCIONES y FÓRMULAS. Nunca copies frases de ejemplo: escribí todo con la huella de voz del canal.

Duración objetivo del gancho: ES ~70 s (120-170 palabras), EN ~50 s. Ofrecé 3 tipos distintos, escritos con la voz del canal; los ejemplos son solo para entender la mecánica.

| id | fórmula | frecuencia |
|---|---|---|
| `dato-que-no-cierra` | Hecho verificable + segundo hecho que lo contradice + pregunta directa (+ descartar la respuesta obvia). | es 4 · en 3 |
| `escena-cinematografica` | Fecha y lugar exactos + un personaje haciendo algo concreto + giro en pocas frases + la pregunta que abre el video. | es 3 · en 1 |
| `secreto-oculto` | Algo famosísimo + alguien escondió algo adentro + casi nadie lo vio + promesa de mostrar dónde. | es 2 · en 2 |
| `numero-imposible` | Una cifra extrema sola + traducción a algo cotidiano + paradoja + '¿cómo es posible?'. | es 2 · en 1 |
| `objeto-o-detalle-misterioso` | Señalar algo concreto en pantalla + 'no debería estar ahí' + todos los que pasaron sin verlo + el misterio no es qué es, sino cómo llegó. | es 1 · en 3 |
| `y-si-hipotetico` | '¿Y si…?' o 'Imaginá…' + escena cotidiana local + el evento imposible + una regla que complica + dato contraintuitivo. | es 1 · en 1 |
| `mito-a-derribar` | Lo que todos creen (o lo que 'pensaste al ver X') + 'parece así; no lo es' + lo extraño de la verdad + pregunta grande. | es 1 · en 3 |
| `contraste-antes-despues` | Cómo es hoy (con comparación absurda) + cómo era antes (casi nada) + '¿cómo pasó de esto a esto?' + ráfaga de lo que vas a ver. | es 1 · en 1 |
| `empezar-por-el-final` | El desenlace (una cita, un hallazgo, una muerte) + salto a la fecha del origen + resumen en pocas frases + 'así pasó'. | es 1 · en 1 |
| `promesa-concreta` | Qué es el tema en una frase + 'en este video vas a ver A, B y C' (+ un misterio al final de la lista) + arranque. | es 1 · en 1 |
| `te-afecta-a-vos` | Situación cotidiana del espectador + consecuencia invisible + la causa nombrada + promesa de cambiar cómo lo mirás. | es 1 · en 2 |
| `anuncio-de-lista` | Lo esperable + la paradoja que une la lista + número y criterio, todo en menos de 20 segundos. | es 1 · en 1 |
| `personaje-en-peligro` | 'Ahora mismo' + persona anónima en un lugar extremo con cifras + restricción ('no puede salir') + lo que no puede hacer + 'resuelve problemas que ni imaginaste'. | es 1 · en 0 |
| `pregunta-imposible` | Viaje imaginario hasta el límite de lo conocido + '¿qué hay del otro lado?' + respuesta aburrida posible vs. respuesta asombrosa + '¿es ciencia o especulación?'. | es 0 · en 1 |
| `desafio-o-apuesta` | Reto directo ('rápido: decime…', 'señalá en el mapa…') + 'la mayoría falla' + ráfaga de datos raros + anuncio. | es 0 · en 1 |
| `cita-de-archivo` | Una frase real (de un documento, una conferencia, una carta) + quién la dijo y cuándo + qué escondía + promesa. | es 0 · en 0 |
| `error-que-cometes` | Algo que el espectador hace + por qué está mal (con dato) + qué pierde + promesa de corregirlo. | es 0 · en 0 |
| `comparacion-de-escala` | Algo enorme o diminuto puesto al lado de algo familiar + el detalle que vuelve la escala inquietante + pregunta. | es 0 · en 0 |
| `postura-del-narrador` | Una opinión fuerte y argumentable del canal + por qué la mayoría piensa lo contrario + 'te muestro por qué'. | es 0 · en 0 |
| `injusticia` | Autoridad que afirma 'fue el mejor' + 'y sin embargo' + la injusticia concreta + '¿cómo es posible?' + promesa emocional. | es 0 · en 0 |
| `pregunta-de-la-audiencia` | Dato que indigna o intriga + 'la pregunta que más se repitió en los comentarios' + aviso de que la respuesta no es un eslogan + promesa con minuto concreto. | es 1 · en 0 |
| `titular-con-dato-retenido` | Titular de la noticia + 'pero lo más impactante no es eso, es…' (sin decir qué) + promesa de contarlo. | es 1 · en 0 |
| `alarma-de-tendencia` | 'Está pasando ahora' + metáfora de amenaza silenciosa + 'no es pasajero, es estructural' + imagen nostálgica que se apaga + causa común + anuncio. | es 1 · en 0 |
| `david-contra-goliat` | Lugar discreto + equipo chico con años de esfuerzo + el gigante que esperaba que fallara + 'funcionó' + qué hace de forma casi absurda + 'hoy vemos si alcanza'. | es 1 · en 0 |

## El dato que no cierra · `dato-que-no-cierra`

- **Fórmula:** Hecho verificable + segundo hecho que lo contradice + pregunta directa (+ descartar la respuesta obvia).
- **Cuándo:** Cuando tenés una contradicción real en los datos. Es el gancho más frecuente en la investigación (7 de 46) porque sirve para casi cualquier nicho.
- **Pasos:** Dato 1, concreto y comprobable. → Dato 2 que choca con el primero. → Pregunta + 'y no, no es lo que pensás'.
- **Ejemplos inventados (no copiar):**
  - El pueblo con más apicultores de la provincia compra miel importada. No una vez: todos los inviernos. ¿Por qué un lugar que produce toneladas paga por la de otros? Y no, no es el precio.
  - El faro más alto de la costa nunca evitó un naufragio. Los tres hundimientos de la zona pasaron con la luz encendida.
- **Riesgo:** Se vuelve clickbait si la contradicción es aparente y se resuelve con una obviedad en el minuto 1, o si el dato está inflado.

## Escena cinematográfica · `escena-cinematografica`

- **Fórmula:** Fecha y lugar exactos + un personaje haciendo algo concreto + giro en pocas frases + la pregunta que abre el video.
- **Cuándo:** Historias con un momento visual fuerte: true crime, biografías, historia. Ideal si vas a ilustrar con imágenes.
- **Pasos:** Fecha, lugar y acción concreta. → Lo que se esperaba vs. lo que pasó. → Pregunta o 'pero eso no fue lo peor de su vida' dicho con tus palabras.
- **Ejemplos inventados (no copiar):**
  - 11 de febrero de 1959, puerto de Bahía Blanca. Un pescador sube la red y en vez de merluza saca una valija cerrada con candado. La lleva a la comisaría. Nadie la reclama durante 40 años.
  - Una noche de agosto, en un hotel de Mar del Plata, el pianista que tocaba todas las noches no apareció. Su piano tampoco.
- **Riesgo:** Cliché si arranca con clima genérico ('era una noche oscura y tormentosa') o si la escena no tiene nada que ver con el corazón del video.

## Secreto oculto · `secreto-oculto`

- **Fórmula:** Algo famosísimo + alguien escondió algo adentro + casi nadie lo vio + promesa de mostrar dónde.
- **Cuándo:** Obras, edificios, marcas o personajes muy conocidos donde realmente hay un detalle documentado poco difundido.
- **Pasos:** Lo famoso, en una línea. → Lo escondido y quién lo escondió. → Promesa concreta: 'hoy te muestro dónde está'.
- **Ejemplos inventados (no copiar):**
  - El himno que cantás en cada acto escolar tiene una estrofa que se dejó de cantar a propósito. Está impresa en los archivos y casi nadie la leyó. Hoy te la muestro y te cuento por qué la sacaron.
  - En el billete que tenés en el bolsillo hay una firma que no corresponde a nadie del Banco Central.
- **Riesgo:** Muy gastado en arte y misterio. Si el 'secreto' es una teoría sin respaldo, presentalo como teoría; si no, es título engañoso.

## Número imposible · `numero-imposible`

- **Fórmula:** Una cifra extrema sola + traducción a algo cotidiano + paradoja + '¿cómo es posible?'.
- **Cuándo:** Cuando tenés una cifra que impresiona por sí sola: temperaturas, distancias, dinero, edades.
- **Pasos:** La cifra, sin adornos. → Comparación física o casera. → La paradoja que la vuelve rara.
- **Ejemplos inventados (no copiar):**
  - 4.000 metros. Esa es la altura a la que juega de local un club de fútbol en los Andes. Los rivales llevan tubos de oxígeno al banco. Y el club casi nunca gana de visitante.
  - Una sola colmena puede volar el equivalente a tres vueltas al mundo para fabricar medio kilo de miel.
- **Riesgo:** Cifras sin fuente o redondeadas para impresionar. El espectador que la busca y no la encuentra no vuelve.

## Objeto o detalle misterioso · `objeto-o-detalle-misterioso`

- **Fórmula:** Señalar algo concreto en pantalla + 'no debería estar ahí' + todos los que pasaron sin verlo + el misterio no es qué es, sino cómo llegó.
- **Cuándo:** Formatos visuales: arte, fotos de archivo, mapas, objetos de museo. Funciona si podés mostrar el detalle en pantalla.
- **Pasos:** Guiar la mirada hasta el detalle. → Por qué no debería existir. → Reformular el misterio: el cómo o el por qué.
- **Ejemplos inventados (no copiar):**
  - Mirá la esquina de abajo de esta foto de 1910. Al lado del carro hay un chico con un reloj pulsera. En esa época casi nadie usaba reloj en la muñeca, y menos un chico de campo.
  - En la puerta de esta iglesia hay una cerradura de un modelo que se patentó 200 años después de construida.
- **Riesgo:** Si el detalle no se ve bien en pantalla, el gancho se cae. Evitá insinuar viajes en el tiempo o fenómenos paranormales como hecho.

## ¿Y si…? hipotético · `y-si-hipotetico`

- **Fórmula:** '¿Y si…?' o 'Imaginá…' + escena cotidiana local + el evento imposible + una regla que complica + dato contraintuitivo.
- **Cuándo:** Canales de 'qué pasaría si', ciencia y futuro. Localizar la escena (tu ciudad, tu rutina) multiplica el efecto.
- **Pasos:** Escena cotidiana en segunda persona. → El evento imposible y su regla. → Lo contraintuitivo: 'lo raro es que al principio nadie lo nota'.
- **Ejemplos inventados (no copiar):**
  - ¿Y si mañana, al despertarte, todos los relojes del mundo marcaran la misma hora, sin importar el país? Hay una sola regla: nadie puede cambiarlos. Lo raro es que el primer problema no aparece en los aviones, aparece en la panadería.
  - Supongamos que la Luna se alejara un metro por día. Los primeros meses, nada. Después, las mareas.
- **Riesgo:** 'Imaginá' es una de las aperturas más gastadas (y un tic de IA). Usalo solo si la escena es muy concreta; si no, entrá directo al evento.

## Mito a derribar · `mito-a-derribar`

- **Fórmula:** Lo que todos creen (o lo que 'pensaste al ver X') + 'parece así; no lo es' + lo extraño de la verdad + pregunta grande.
- **Cuándo:** Cuando la versión popular es conocida y la real es más interesante. Da sensación de 'ahora sé la verdad'.
- **Pasos:** La creencia, con una imagen concreta. → El 'no' seco. → La pregunta que abre la verdad.
- **Ejemplos inventados (no copiar):**
  - Pensás en un gaucho y ves poncho, mate y caballo criollo. Los primeros gauchos de los registros casi no tomaban mate y muchos ni siquiera eran de acá. Entonces, ¿de dónde salió la imagen que tenemos?
  - Todos dicen que los camellos guardan agua en la joroba. No guardan agua.
- **Riesgo:** Derribar algo que nadie cree, o reemplazar un mito por otro sin fuentes. También gastado si cada video del canal 'desmiente' algo.

## Contraste antes / después · `contraste-antes-despues`

- **Fórmula:** Cómo es hoy (con comparación absurda) + cómo era antes (casi nada) + '¿cómo pasó de esto a esto?' + ráfaga de lo que vas a ver.
- **Cuándo:** Transformaciones grandes: países, ciudades, empresas, personas, también caídas (de 1.200 locales a 30).
- **Pasos:** El hoy, en grande. → El antes, en chico. → La pregunta + adelanto en ráfaga.
- **Ejemplos inventados (no copiar):**
  - Hoy esa avenida tiene más tráfico que cualquier ruta del país. Hace 120 años era un arroyo donde las lavanderas tendían la ropa. ¿Cómo pasó? Una inundación, un intendente terco y una apuesta que casi lo deja en la ruina.
  - En 2015 vendían una zapatilla cada tres segundos. Hoy la marca no tiene un solo local propio.
- **Riesgo:** Se vuelve una clase si después no hay tesis. Cuidado con fotos 'antes/después' que no corresponden al mismo lugar.

## Empezar por el final · `empezar-por-el-final`

- **Fórmula:** El desenlace (una cita, un hallazgo, una muerte) + salto a la fecha del origen + resumen en pocas frases + 'así pasó'.
- **Cuándo:** Cuando el final es conocido o fuerte y el interés está en el cómo: casos resueltos, quiebras, tragedias.
- **Pasos:** El final en escena. → La pregunta: quién se queda, cómo llegó, por qué. → Promesa del recorrido.
- **Ejemplos inventados (no copiar):**
  - 'Lo encontramos', dijo la guardaparques por radio. Habían pasado once días. El chico que todos daban por perdido estaba sentado, tranquilo, a dos kilómetros del sendero. Lo que contó después no coincidía con nada de lo que encontraron.
  - El último vuelo de la aerolínea salió con siete pasajeros. Diez años antes, era la más rentable del continente.
- **Riesgo:** Revelar también el cómo en el gancho. Y en casos reales, usar la tragedia como anzuelo sin respeto (monetización limitada por eventos sensibles).

## Promesa concreta · `promesa-concreta`

- **Fórmula:** Qué es el tema en una frase + 'en este video vas a ver A, B y C' (+ un misterio al final de la lista) + arranque.
- **Cuándo:** Explicativos, recorridos y biografías donde el público ya busca el tema. Directo, sin truco.
- **Pasos:** El tema y por qué impresiona. → El mapa: tres cosas concretas. → El cierre del mapa con un cabo suelto.
- **Ejemplos inventados (no copiar):**
  - Una cosechadora moderna procesa en una hora lo que una familia cosechaba en un mes. En este video vas a ver cómo corta, cómo separa el grano y cómo sabe, sola, por dónde ir. Y por qué el modelo más caro no siempre es el que más rinde.
  - Hoy recorremos la vida de la primera relatora de fútbol del país: el barrio, la radio que la echó, el partido que la hizo famosa y el día que dejó el micrófono sin explicar por qué.
- **Riesgo:** Gastado cuando el mapa es genérico ('vamos a ver todo lo que tenés que saber'). La lista tiene que ser específica y cumplirse en orden.

## Te afecta a vos · `te-afecta-a-vos`

- **Fórmula:** Situación cotidiana del espectador + consecuencia invisible + la causa nombrada + promesa de cambiar cómo lo mirás.
- **Cuándo:** Finanzas personales, psicología, hábitos, economía explicada. El espectador tiene que reconocerse en la primera frase.
- **Pasos:** Escena o pregunta cotidiana. → Lo que te cuesta sin que lo notes. → Promesa práctica.
- **Ejemplos inventados (no copiar):**
  - Si cada vez que cargás la SUBE ponés el mínimo 'porque total después cargo', hay un costo que no ves en ningún ticket. No es plata: es tiempo. Hoy te muestro cuánto y cómo recuperarlo.
  - Esa notificación que mirás 'solo un segundo' te cuesta, en promedio, más de veinte minutos de concentración.
- **Riesgo:** Alarmismo o promesas de transformación exageradas ('esto te va a cambiar la vida'). En finanzas o salud, no dar consejos personalizados ni datos sin fuente.

## Anuncio de lista · `anuncio-de-lista`

- **Fórmula:** Lo esperable + la paradoja que une la lista + número y criterio, todo en menos de 20 segundos.
- **Cuándo:** Listas y antologías. El criterio paradójico es lo que hace que no sea 'otra lista'.
- **Pasos:** Regla general. → La excepción o paradoja. → Número + criterio.
- **Ejemplos inventados (no copiar):**
  - La mayoría de los inventos fracasan porque nadie los quiere. Estos fracasaron porque los quería demasiada gente al mismo tiempo. Doce inventos que murieron de éxito.
  - Casi todos los barcos hundidos se quedan en el fondo. Estos ocho volvieron a flote solos.
- **Riesgo:** Lista sin criterio paradójico = relleno. Inflar el número con ítems flojos para llegar a '25'.

## Personaje en peligro (ahora mismo) · `personaje-en-peligro`

- **Fórmula:** 'Ahora mismo' + persona anónima en un lugar extremo con cifras + restricción ('no puede salir') + lo que no puede hacer + 'resuelve problemas que ni imaginaste'.
- **Cuándo:** Oficios extremos, lugares inhóspitos, supervivencia. Mete al espectador en el cuerpo de otro.
- **Pasos:** Dónde está y con qué cifras. → La restricción. → La promesa de soluciones inesperadas.
- **Ejemplos inventados (no copiar):**
  - En este momento, en una base de la Antártida, hay un cocinero que tiene que alimentar a 40 personas durante seis meses sin que llegue un solo barco. Si se equivoca con la harina en marzo, en agosto no hay pan. Lo que hace con los huevos te va a parecer una locura.
  - Hay alguien, ahora, colgado de una cuerda a 90 metros, limpiando un vidrio que nadie va a mirar.
- **Riesgo:** Exagerar el peligro o inventar detalles del oficio. Usá fuentes o testimonios reales.

## Pregunta imposible · `pregunta-imposible`

- **Fórmula:** Viaje imaginario hasta el límite de lo conocido + '¿qué hay del otro lado?' + respuesta aburrida posible vs. respuesta asombrosa + '¿es ciencia o especulación?'.
- **Cuándo:** Temas grandes y abiertos (universo, conciencia, origen). La honestidad sobre lo que no se sabe da credibilidad.
- **Pasos:** Llevar al espectador al borde. → Las dos respuestas posibles. → La pregunta honesta.
- **Ejemplos inventados (no copiar):**
  - Si pudieras seguir bajando por la fosa más profunda del océano, más allá del fondo, más allá de la roca, ¿dónde termina el agua del planeta? Quizás solo en más piedra. Pero hay geólogos que creen que abajo hay más agua que en todos los mares juntos. ¿Es una idea seria o una fantasía?
  - ¿Qué había un segundo antes del primer segundo?
- **Riesgo:** Responder con certezas lo que es especulación. Cliché si se usa 'una pregunta que la ciencia no puede responder' sin explicar por qué.

## Desafío al espectador · `desafio-o-apuesta`

- **Fórmula:** Reto directo ('rápido: decime…', 'señalá en el mapa…') + 'la mayoría falla' + ráfaga de datos raros + anuncio.
- **Cuándo:** Geografía, curiosidades, trivia. Involucra desde el primer segundo porque el espectador responde en su cabeza.
- **Pasos:** El reto. → La respuesta que casi nadie sabe. → Ráfaga + anuncio del video.
- **Ejemplos inventados (no copiar):**
  - Rápido: ¿cuántas capitales de provincia tienen salida al mar? Si dijiste más de tres, te pasaste. Y una de esas tiene un puerto que casi nunca usa. Acá van 20 datos que te van a desordenar el mapa del país.
  - Probá decir, sin buscar, en qué país nace el río más largo de tu continente.
- **Riesgo:** Retos de respuesta obvia o tramposa. Si se usa en cada video, se vuelve fórmula del canal.

## Cita de archivo · `cita-de-archivo`

- **Fórmula:** Una frase real (de un documento, una conferencia, una carta) + quién la dijo y cuándo + qué escondía + promesa.
- **Cuándo:** Cuando tenés una frase documentada que resume el conflicto. Da autenticidad sin necesidad de cara.
- **Pasos:** La cita breve y textual (con fuente). → Contexto en una línea. → Lo que esa frase no decía.
- **Ejemplos inventados (no copiar):**
  - 'No vamos a cerrar ninguna planta.' Lo dijo el presidente de la empresa en una conferencia, con fábrica de fondo. Cinco meses después cerró tres. La frase no era mentira del todo, y esa es la parte interesante.
  - En la última carta que mandó desde el barco escribió una sola línea sobre el viaje: 'Acá nadie habla del capitán'.
- **Riesgo:** Inventar o retocar citas es desinformación. Citas largas de terceros pueden traer problemas de derechos; usá frases breves y nombrá la fuente.

## El error que cometés · `error-que-cometes`

- **Fórmula:** Algo que el espectador hace + por qué está mal (con dato) + qué pierde + promesa de corregirlo.
- **Cuándo:** Tutoriales, hábitos, finanzas, cocina, tecnología. Funciona si el error es común de verdad.
- **Pasos:** La acción cotidiana. → La consecuencia medible. → La corrección prometida.
- **Ejemplos inventados (no copiar):**
  - Si guardás el pan en la heladera para que dure más, lo estás poniendo viejo más rápido. Hay una temperatura exacta a la que se endurece, y la heladera está justo ahí. Te muestro dónde conviene guardarlo.
  - Cargar el celular hasta el 100 % todas las noches no es el problema. El problema es otro.
- **Riesgo:** Retar al espectador o exagerar el daño. En salud: no contradecir a autoridades sanitarias.

## Comparación de escala · `comparacion-de-escala`

- **Fórmula:** Algo enorme o diminuto puesto al lado de algo familiar + el detalle que vuelve la escala inquietante + pregunta.
- **Cuándo:** Espacio, geografía, ingeniería, economía (deudas, fortunas). Cuando la cifra sola no se entiende.
- **Pasos:** Lo familiar. → Lo comparado. → La consecuencia rara de esa escala.
- **Ejemplos inventados (no copiar):**
  - Si pusieras todos los cables submarinos de internet en línea recta, darían más de 30 vueltas al planeta. Y la mayoría tienen el grosor de una manguera de jardín. Uno solo, cortado por el ancla de un barco, dejó a un país entero sin bancos un día.
  - El presupuesto anual de esa liga cabe en lo que cobra un solo jugador europeo en un mes.
- **Riesgo:** Comparaciones mal calculadas (chequeá la cuenta) o tan usadas que ya no impresionan ('del tamaño de una cancha de fútbol').

## Postura del narrador · `postura-del-narrador`

- **Fórmula:** Una opinión fuerte y argumentable del canal + por qué la mayoría piensa lo contrario + 'te muestro por qué'.
- **Cuándo:** Canales con voz propia y criterio (ensayos, análisis, reseñas). Construye identidad: es el gancho menos copiable.
- **Pasos:** La postura en una frase. → La opinión mayoritaria. → La promesa de argumentar.
- **Ejemplos inventados (no copiar):**
  - Creo que el mejor disco de esa banda es el que todos odiaron. No el más vendido, no el de la tapa famosa: el que los echó de la discográfica. Y tengo cuatro razones que no tienen nada que ver con la nostalgia.
  - La peor decisión de la historia del club no fue vender a su ídolo. Fue cómo lo compró.
- **Riesgo:** Polémica fabricada o ataques a personas (contenido incendiario/denigrante limita anuncios). La postura tiene que sostenerse con argumentos.

## Injusticia · `injusticia`

- **Fórmula:** Autoridad que afirma 'fue el mejor' + 'y sin embargo' + la injusticia concreta + '¿cómo es posible?' + promesa emocional.
- **Cuándo:** Deportes, biografías, historia social. La indignación sostiene la atención y genera comentarios.
- **Pasos:** El mérito, dicho por alguien con peso. → El 'y sin embargo'. → La pregunta y la promesa.
- **Ejemplos inventados (no copiar):**
  - Sus compañeros dicen que fue la mejor enfermera que tuvo el hospital en 50 años. Y sin embargo, el pabellón que ella abrió con sus ahorros lleva el nombre de un director que llegó después. ¿Cómo se borra a alguien así? Al final vas a entender por qué todavía molesta.
  - Ganó tres veces la carrera. Ninguna de las tres figura en el registro oficial.
- **Riesgo:** Exagerar la injusticia o acusar sin pruebas (difamación: limita o quita anuncios y puede violar normas).

## Pregunta de la audiencia · `pregunta-de-la-audiencia`

- **Fórmula:** Dato que indigna o intriga + 'la pregunta que más se repitió en los comentarios' + aviso de que la respuesta no es un eslogan + promesa con minuto concreto.
- **Cuándo:** Canales que ya tienen comentarios. Hace sentir escuchada a la comunidad y te da temas validados.
- **Pasos:** El dato. → La pregunta real de un comentario (parafraseada). → La promesa: 'a la mitad del video te muestro…'.
- **Ejemplos inventados (no copiar):**
  - En el último video les conté que el tren de pasajeros dejó de pasar por 600 pueblos. La pregunta que más se repitió fue: si las vías siguen ahí, ¿por qué no vuelve? La respuesta no es 'por los políticos'. A la mitad del video te muestro quién decide hoy.
  - Me preguntaron tantas veces por qué la yerba sube más que todo lo demás que hice este video.
- **Riesgo:** Inventar comentarios que no existen. Si el canal es nuevo, no lo uses: se nota.

## Titular con dato retenido · `titular-con-dato-retenido`

- **Fórmula:** Titular de la noticia + 'pero lo más impactante no es eso, es…' (sin decir qué) + promesa de contarlo.
- **Cuándo:** Actualidad y casos del momento. Retiene el dato más fuerte y lo anuncia varias veces antes de entregarlo.
- **Pasos:** El hecho noticioso. → El 'lo más raro no es eso'. → La promesa de revelarlo.
- **Ejemplos inventados (no copiar):**
  - Encontraron al perro del intendente, desaparecido hace dos semanas, a 300 kilómetros. Pero lo más raro no es la distancia: es quién lo estaba cuidando. En este video te cuento quién era y cómo llegó hasta ahí.
  - Cerró la fábrica de alfajores más antigua de la ciudad. Lo sorprendente es lo que anunciaron que van a hacer con la receta.
- **Riesgo:** Si se retiene demasiado o el dato es flojo, es clickbait puro. En tragedias recientes, cuidado con explotar el hecho (sin anuncios).

## Alarma de tendencia · `alarma-de-tendencia`

- **Fórmula:** 'Está pasando ahora' + metáfora de amenaza silenciosa + 'no es pasajero, es estructural' + imagen nostálgica que se apaga + causa común + anuncio.
- **Cuándo:** Empresas, consumo, economía, cultura. Mezcla urgencia con nostalgia.
- **Pasos:** El fenómeno en marcha. → Por qué no es pasajero. → Lo que se pierde + la causa común.
- **Ejemplos inventados (no copiar):**
  - Los videoclubes ya cayeron. Ahora le toca a otro lugar donde pasaste horas de chico: los kioscos de diarios. No es una mala racha, es un cambio de fondo. Las persianas que abrían a las seis de la mañana bajan una por una. Y todas tienen la misma causa.
  - Las canchas de bochas de los clubes de barrio se están convirtiendo en estacionamientos, una por mes.
- **Riesgo:** Alarmismo sin datos. 'Se está desmoronando' sobre empresas concretas sin cifras puede ser engañoso.

## David contra Goliat · `david-contra-goliat`

- **Fórmula:** Lugar discreto + equipo chico con años de esfuerzo + el gigante que esperaba que fallara + 'funcionó' + qué hace de forma casi absurda + 'hoy vemos si alcanza'.
- **Cuándo:** Tecnología, negocios, deportes. Le da narrativa emocional a un tema técnico.
- **Pasos:** El chico y su esfuerzo. → El gigante y su miedo. → El resultado + la pregunta abierta.
- **Ejemplos inventados (no copiar):**
  - En una cooperativa de Misiones, doce productores pasaron ocho años intentando secar yerba con energía solar. Las grandes marcas decían que era imposible a escala. Lo lograron. Cuesta la mitad. Hoy vemos si de verdad puede competir, y la respuesta tiene una trampa.
  - Un club de pueblo con presupuesto de kiosco le ganó la final al equipo más rico del país.
- **Riesgo:** Exagerar la amenaza al gigante. Responder el título con honestidad aunque la respuesta sea 'todavía no'.
