# Adaptarse a las herramientas del alumno

Nunca mandes al alumno a una herramienta que no marcó en la ficha. Si no tiene ninguna, todo el recorrido funciona con Claude o ChatGPT (gratis) + YouTube + Google Trends.

| Necesidad | Si NO tiene herramientas pagas | Si tiene NexLev | Si tiene vidIQ |
|---|---|---|---|
| Transcripción de un video | YouTube en la compu: "…más" → "Mostrar transcripción" → copiar | Transcripción del video desde NexLev | Transcripción desde la extensión/app de vidIQ |
| ¿El tema tiene demanda? | Google Trends (comparar 2-3 términos, últimos 12 meses) + buscar el tema en YouTube y mirar fechas y vistas de los resultados | Buscar outliers del nicho (videos que rinden muchas veces el promedio del canal) | Outliers y búsqueda de palabras clave |
| Encontrar competidores | Buscar el tema en YouTube, filtrar por "videos", abrir canales con videos de muchas vistas y pocos suscriptores | Buscador de nichos/canales similares | Canales similares |

**IA para escribir**
- Plan **gratis** (Claude o ChatGPT): mensajes más cortos, pedí y entregá el guion **por secciones**, y recordale que el perfil tiene que estar en cada conversación (proyecto o adjunto).
- Plan pago: se puede trabajar el guion entero de una vez, pero igual mostrá el esqueleto antes.

**Voz**: ElevenLabs/otra IA → texto para voz cortado en < 5.000 caracteres. Propia → teleprompter (ver `salidas.md`).

**Imágenes**: Midjourney → prompts en inglés con parámetros de proporción (`--ar 16:9`). ChatGPT/Gemini → descripción natural en una o dos frases. Higgsfield → prompt corto con sujeto, acción, luz y lente. Ninguna → palabras clave para bancos gratis.

**Edición**: sólo si pregunta; las salidas de escenas con minutos sirven para cualquier editor.
