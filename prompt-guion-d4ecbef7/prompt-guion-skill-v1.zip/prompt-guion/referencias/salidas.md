# Salidas (paso 7) — ofrecelas como menú, que elija

1. **Títulos + idea de miniatura.** 10 títulos de tipos distintos (pregunta, dato que no cierra, promesa, contraste…) que prometan lo que el guion realmente entrega (si el título promete algo que el video no cumple, es título engañoso). Marcá tus 3 favoritos y por qué. Respetá las reglas propias del perfil. Para la miniatura: 2 ideas en una línea cada una (qué se ve, dónde mira el ojo, texto sí/no) que completen el título sin repetirlo.
2. **Escenas para imágenes.** Partí el guion en planos de 5-8 segundos (≈ 12-20 palabras de voz cada uno). Por plano: n.º, frase de la voz, qué se ve, y un prompt de imagen en el formato de la herramienta que tenga (perfil). Si no tiene generador de imágenes, sugerí qué buscar en bancos gratis (Pexels, Wikimedia Commons, archivos de museos) con las palabras clave. Mencioná que Prompt Cine (para prompts de imagen cinematográficos) y Prompt Camera (para movimientos de cámara) de SEN6 sirven para este paso.
3. **Texto listo para la voz.**
   - ElevenLabs u otra voz IA: sin marcas ni emojis, números y siglas escritos como se dicen, pausas con puntos, y cortado en partes de menos de 5.000 caracteres (cortar siempre al final de un párrafo).
   - Voz propia: formato teleprompter (frases cortas, un salto de línea por respiración, palabras clave en MAYÚSCULAS para remarcar).
4. **Descripción.** 2-3 líneas que enganchen (sin repetir el título), capítulos con minutos si el video pasa de 8 min, y espacio para sus links. Sin relleno de palabras clave.
5. **Pregunta para los comentarios.** 3 opciones concretas o polarizantes ligadas al tema, con su voz.
