# Entrenamiento: huella de voz, mapa del nicho, lista negra y firma

Objetivo: que la skill escriba como ESTE creador y distinto a SU competencia. Nunca al revés.

## 1. Pedir las muestras (guiado, en dos mensajes)

**Mensaje A — textos propios.** Pedí 1.500 palabras o más, de lo que tenga:
- guiones que ya grabó (mejor si son de videos que le fueron bien),
- posts, mensajes largos, emails, descripciones que haya escrito él,
- **si no tiene nada escrito (lo más común en principiantes):** que grabe un audio de 3 minutos contándole a un amigo una historia de su nicho, como si estuviera tomando un café, y te pegue la transcripción. Cómo transcribirlo gratis: el dictado del celular, la nota de voz con transcripción, o subir el audio a su IA (Claude o ChatGPT). Explicale por qué: "así sale cómo hablás de verdad, no cómo creés que hay que escribir".
Aclarale que no importa si tiene errores: se analiza el estilo, no la ortografía.

**Mensaje B — competencia.** Pedí 3 a 5 transcripciones de videos de canales fuertes de su nicho (si no sabe cuáles, ayudalo a elegir: canales de su idioma con videos que superan claramente el promedio del canal). Cómo copiarlas **gratis** desde YouTube en la compu: abrir el video → debajo del título, "…más" → "Mostrar transcripción" → en el panel, los tres puntitos → desactivar marcas de tiempo si aparece la opción → seleccionar todo el texto y copiar. Con NexLev o vidIQ (si los tiene) se descargan directo; decile dónde.
Si no puede conseguirlas, seguí igual y marcá el mapa del nicho como "provisorio".

## 2. Analizar y devolver (en un solo mensaje ordenado, para aprobar)

### Huella de voz (de SUS textos; citá frases suyas cortas como evidencia)
| Rasgo | Qué medir | Ejemplo de salida |
|---|---|---|
| Largo de frase | promedio y variación (¿alterna cortas y largas?) | "Frases cortas, 9 palabras promedio; remata con una de 3." |
| Registro | voseo / tuteo / ustedeo / neutro; formal o de charla | "Voseo, de charla." |
| Persona | ¿le habla al espectador?, ¿usa 'yo'?, ¿'nosotros'? | "Te habla a vos; cuenta en primera persona." |
| Muletillas y giros propios | palabras o expresiones que repite | "'Mirá', 'la posta', 'ojo con esto'." |
| Humor | tipo y dosis | "Ironía seca, una vez cada tanto." |
| Conectores | cómo pasa de una idea a otra | "Usa 'y ojo', 'pero bancá'." |
| Imágenes y metáforas | de qué mundo las saca | "Fútbol y cocina." |
| Arranques y cierres | cómo abre y cómo termina | "Abre con una escena; cierra con una pregunta." |
| Ritmo | ¿pausas, enumeraciones, preguntas? | "Pocas preguntas retóricas." |
| Lo que NO hace | rasgos ausentes que conviene respetar | "Nunca exagera ni usa superlativos." |

### Mapa del nicho (de las transcripciones de la competencia)
- **Lo que todos hacen igual:** ganchos repetidos, frases calcadas, misma estructura, mismo tono, mismas fuentes, mismo tipo de cierre. Esto es la **zona a evitar**.
- **Clichés del nicho:** frases o recursos que aparecen en 2+ competidores → van a la lista negra propia.
- **Huecos / oportunidades:** ángulos, formatos, tonos o tipos de historia que nadie usa y que encajan con la huella del creador.
- **Lo que sí funciona y conviene mantener (como función, no como frase):** p. ej. "todos plantan un dato en el minuto 1 y lo pagan al final".

### Lista negra propia
= `anti-ia.md` (general) + clichés del nicho detectados + lo que el creador diga que odia. Formato: patrón · por qué · cómo reemplazarlo con SU voz.

### Firma del canal (proponé 3, que elija 1-3)
Recursos propios y repetibles que lo hagan reconocible sin ver el nombre, coherentes con su huella. Ejemplos de tipo (no para copiar): una pregunta fija al cerrar, una sección recurrente, una forma de presentar los datos, una metáfora de su mundo, una regla autoimpuesta ("nunca digo el nombre de la obra en el primer minuto").

## 3. Generar el PERFIL DE CANAL
Con la ficha + lo aprobado, generá el perfil completo con el formato de `plantillas/perfil-canal.md` y explicá cómo guardarlo (SKILL.md, "Guardar el perfil").

## Re-entrenar
Cuando sume textos o videos nuevos: recalculá solo lo que cambia, mostrale las diferencias ("ahora usás frases más cortas"), y regenerá el perfil con la versión siguiente.
