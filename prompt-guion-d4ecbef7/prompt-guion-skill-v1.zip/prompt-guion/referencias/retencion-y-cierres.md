# Retención y cierres

> Regla de oro: estas son FUNCIONES y FÓRMULAS. Nunca copies frases de ejemplo: escribí todo con la huella de voz del canal.

Un re-gancho es una FUNCIÓN (renovar las ganas de seguir mirando), no una frase. La misma función se puede escribir de mil maneras: escribila con la voz de tu canal.

## Datos de la investigación

- **Primer re-gancho:** Cerca del minuto 1 (mediana: 1,35 min en español y 1,15 min en inglés). Suele llegar justo cuando termina el gancho.
- **Español:** Cada 1,5 a 2,5 minutos en los outliers en español. Los de true crime y actualidad llegan a uno cada 40-60 segundos.
- **Inglés:** Cada ~3 minutos en inglés, con frases-bisagra más explícitas.
- **Regla de revisión:** Si pasan más de 3 minutos sin renovar la promesa, abrir una pregunta o cambiar de tramo, marcalo en la revisión.

## Funciones de re-gancho

| función | para qué | cada cuánto | cómo escribirlo sin cliché |
|---|---|---|---|
| **Renovar la promesa** (`renovar-la-promesa`) | Recordar qué se lleva el espectador si se queda, sin repetir el gancho. | Una vez entre el minuto 1 y 2, y otra pasada la mitad. | Nombrá lo concreto que falta ('todavía no te dije quién cobraba') en vez de anunciar 'lo mejor viene ahora'. Una promesa con sustantivo vale más que una con adjetivo. |
| **Subir la apuesta** (`subir-la-apuesta`) | Marcar que lo que viene es más grave, más raro o más importante que lo anterior. | En cada cambio de bloque grande (cada 3-5 min). | Mostrá la escalada con un dato: 'eso eran 28 animales; ahora son 200'. Evitá el comparativo vacío ('esto se pone peor'). |
| **Cabo suelto (plantar y pagar)** (`cabo-suelto`) | Plantar un dato, una fecha o una frase que vuelve más adelante. El espectador se queda para ver dónde encaja. | Plantalo en el primer 10 % y pagalo entre el 40 % y el final. La mitad de los outliers en español (12 de 24) lo hacen. | Plantalo como dato concreto ('guardá esta fecha: 1956') y, al pagarlo, nombralo de nuevo con las mismas palabras. Nunca lo plantes sin pagarlo. |
| **Mapa numerado / barra de progreso** (`mapa-numerado`) | Que el espectador sepa cuánto falta: 'cuatro caminos', 'tercera capa', 'día 6'. | Anunciado en el gancho o al minuto 1 y marcado en cada parada. | Variá la forma de anunciar cada parada (un título hablado, una pregunta, un número seco). No uses 'número X' con la misma muletilla diez veces. |
| **Giro** (`giro`) | Romper lo que el espectador creía haber entendido. Resetea la atención. | Al menos uno por tercio del video. | Dejá que el dato haga el giro: decí el hecho que contradice, sin prólogo tipo 'y aquí es donde todo cambia'. |
| **Honestidad / credibilidad** (`honestidad`) | Admitir lo que no se sabe o separar dato de opinión. Genera confianza justo antes de una conclusión fuerte. | Una o dos veces por video, antes del clímax o en el cierre. | Decí exactamente qué parte es dudosa y por qué ('esta fuente es de 150 años después'). Evitá el 'dejame ser honesto con vos' genérico. |
| **Pregunta al espectador** (`pregunta-al-espectador`) | Que el espectador responda en su cabeza (o en comentarios) y se sienta parte. | Una a mitad de video como mucho, y otra en el cierre. | Preguntá algo que se pueda contestar con una palabra o una experiencia ('¿tuviste uno de esos?'). Nada de '¿te imaginás?'. |
| **Pregunta puente** (`pregunta-puente`) | Cerrar un bloque con una pregunta que solo responde el siguiente. Elimina los puntos de salida. | Al final de cada capítulo o bloque. | Que la pregunta salga del dato recién dado ('si nada la frena, ¿para qué el motor?'), no de una fórmula. |
| **Anticipar la objeción** (`anticipar-la-objecion`) | Responder lo que el espectador está pensando antes de que se vaya a comentarlo. | Una vez, en el segundo tercio. | Formulá la objeción con las palabras que usaría tu público y respondela con un dato, sin 'sé lo que estás pensando'. |
| **Cambio de tramo o de tono** (`cambio-de-tramo`) | Avisar que empieza otra cosa (otra categoría, otro tono, otra escala). Renueva la promesa en listas largas. | Cada 3-6 ítems en listas; en cada capa en estructuras por capas. | Describí el contraste concreto ('ese era el suelo; ahora, lo que vive encima') en vez de 'esto se pone más raro'. |
| **Opinión o reacción del narrador** (`opinion-personal`) | Romper el ritmo informativo con una reacción humana. Da personalidad sin cara. | Una o dos veces por video. | Que sea específica y con motivo ('este me molesta porque…'). Es donde más se nota la huella de voz del canal. |

## Clichés de retención (gastados)

> Gastadas: usá la función, no la frase. Aparecen en casi todos los nichos y el espectador ya las saltea. Si tu guion tiene una, reescribila con un dato concreto o con tu voz.

| frase gastada | función que intenta cumplir |
|---|---|
| ~~Pero eso no es lo peor~~ | subir-la-apuesta |
| ~~Esto se pone más raro / se pone peor~~ | cambio-de-tramo |
| ~~Quedate hasta el final~~ | renovar-la-promesa |
| ~~Y aquí es donde todo cambió~~ | giro |
| ~~Lo que pasó después nadie lo vio venir~~ | giro |
| ~~Lo más importante todavía estaba por llegar~~ | renovar-la-promesa |
| ~~Y todavía hay algo más~~ | subir-la-apuesta |
| ~~Este detalle lo cambia todo~~ | revelacion |
| ~~Un detalle que te hiela la sangre~~ | subir-la-apuesta |
| ~~Pero acá está lo más sorprendente~~ | subir-la-apuesta |
| ~~Lo que estás por ver te va a sorprender~~ | renovar-la-promesa |
| ~~Si llegaste hasta acá…~~ | pregunta-al-espectador |
| ~~Pero no fue el final~~ | giro |
| ~~Y entonces sucedió algo inesperado~~ | giro |
| ~~Lo que descubrieron dejó a todos sin palabras~~ | revelacion |
| ~~Esto apenas es el comienzo~~ | renovar-la-promesa |
| ~~Pero hay un problema~~ | giro |
| ~~La respuesta te va a sorprender~~ | renovar-la-promesa |
| ~~Lo que nadie te cuenta~~ | renovar-la-promesa |
| ~~Dejame ser honesto con vos~~ | honestidad |
| ~~Sé lo que estás pensando~~ | anticipar-la-objecion |
| ~~Aquí viene el dato clave~~ | renovar-la-promesa |
| ~~Parece sacado de una película~~ | subir-la-apuesta |
| ~~Spoiler: no~~ | giro |

## Cierres

| tipo | qué es | datos | cómo | error |
|---|---|---|---|---|
| **Círculo (plantar y pagar)** | Volver a la escena, la frase o el objeto del gancho, que ahora significa otra cosa. | 8 de 22 outliers en inglés cierran en círculo; en español 12 de 24 plantan un cabo suelto temprano y lo pagan (al final o a mitad). | Elegí desde el esqueleto qué elemento del gancho vuelve. Repetí la imagen con una palabra cambiada que muestre lo que aprendimos. | Volver al inicio solo para resumir: el círculo tiene que resignificar, no repetir. |
| **Pregunta polarizante o dilema** | Dejar al espectador como juez: '¿traidor o chivo expiatorio?', '¿firmarías la orden?'. | La pregunta al público es el cierre más común: 16 de 24 en español y 8 de 22 en inglés terminan con una pregunta (dilemas puros en una minoría). | Que las dos respuestas sean defendibles y que el video haya dado argumentos para ambas. Respuesta de una o dos palabras. | Preguntas genéricas ('¿qué opinás?') o polémica sobre grupos protegidos (riesgo de anuncios y de normas). |
| **Gancho al próximo video** | Teaser concreto de otro video del canal, como continuación natural. | 7 de 24 en español y 3 de 22 en inglés derivan a un video concreto (series, 'el caso opuesto', 'la otra familia'). | Nombrá el próximo tema con su propio mini gancho ('el próximo es el caso al revés: un animal que nadie quiere salvar'). | 'Mirá este otro video' sin razón para hacerlo. |
| **Moraleja o reflexión** | Una idea que el espectador se lleva: lo que el caso dice de algo más grande. | 8 de 24 en español y 7 de 22 en inglés cierran con reflexión o tesis. | Una sola frase, concreta, que salga de un detalle del video (un objeto, un gesto). Mejor una imagen que una enseñanza. | La moraleja forzada de IA ('y así, nos recuerda que…'). Ver anti_ia. |
| **Llamado a la acción (CTA)** | Pedir suscripción, comentario o una acción concreta. | En inglés 19 de 22 tienen un beat de CTA; en español solo 7 de 24 lo marcan como bloque propio (la mayoría lo funde con la pregunta final). | Atalo a la promesa del canal ('si te interesa lo que nadie explica de X, suscribite') o a una tarea concreta (revisar tus gastos, contar tu recuerdo). | CTA largo de 'like, comentá, compartí, campanita' que espanta justo antes de la pantalla final. |
| **Recapitulación útil** | Repaso ultrarrápido (una frase por punto) o una herramienta para usar después. | 5 de 24 en español y 6 de 22 en inglés recapitulan, casi siempre en listas y explicativos. | Una línea por ítem, con ritmo, o convertí lo aprendido en algo aplicable ('la próxima vez que mires un mapa, buscá esto'). | El resumen escolar ('en resumen, hoy vimos…'). |

Combinación más común en los outliers: círculo o moraleja breve + pregunta concreta + CTA corto atado a la promesa del canal.
