# Políticas de YouTube para guionistas

> **Esto es una ayuda para revisar el guion, no una garantía. YouTube decide caso por caso, las políticas cambian y también cuentan las imágenes, la miniatura, el título, la descripción y las etiquetas. Ante la duda, leé la fuente oficial.**

**Verificado:** 2026-10-23 en las páginas oficiales de support.google.com/youtube (enlaces abajo).

## 1. Contenido apto para anunciantes

Cada video queda en uno de tres niveles: anuncios completos, anuncios limitados o sin anuncios. Se evalúa el video, el título, la miniatura, la descripción y las etiquetas. El contexto (educativo, documental, periodístico, artístico) puede subir el nivel.

**Dónde importa más:** Título y miniatura tienen su propio peso: lo que en el video pasa con contexto, en la miniatura o el título puede limitar o quitar anuncios. En el gancho (primeros segundos) se concentra la evaluación de lo gráfico: por ejemplo, violencia gráfica de videojuegos en los primeros 7 segundos o en la miniatura queda sin anuncios. Con las malas palabras fuertes, lo que más pesa es el título, la miniatura y que sean frecuentes en todo el video; YouTube ajustó en 2025 cómo cuentan al inicio del video, así que conviene revisar la página oficial antes de arrancar con una.

Fuente: https://support.google.com/youtube/answer/6162278 · Cambio de lenguaje inapropiado (29 jul 2025), cobertura de prensa: https://ppc.land/youtube-removes-strong-profanity-restrictions-from-first-7-seconds/

| categoría | limita anuncios | sin anuncios | cómo revisarlo en el guion |
|---|---|---|---|
| **Lenguaje inapropiado** | Malas palabras moderadas en título o miniatura; malas palabras frecuentes en todo el video. | Malas palabras fuertes en título o miniatura; insultos discriminatorios o lenguaje de odio en cualquier parte. | Buscá insultos y groserías; si el canal las usa, que sean ocasionales y nunca en título, miniatura ni texto en pantalla del gancho. |
| **Violencia** | Cadáveres con heridas en contexto educativo, detalles gráficos al narrar tragedias, heridas graves dramatizadas. | Violencia muy gráfica sin contexto, glorificación o incitación. | En crímenes y guerras, narrá el hecho sin describir heridas en detalle. Evitá adjetivos sangrientos en el gancho. |
| **Contenido para adultos** | Arte clásico con desnudez explícita en la miniatura; temas sexuales con enfoque educativo. | Desnudez, actos sexuales aunque sean implícitos, miniaturas sexuales, industria sexual. | Si hablás de una obra con desnudos, que la miniatura no los muestre; en el guion, lenguaje descriptivo y no sexualizado. |
| **Contenido impactante** | Imágenes de fluidos o restos mostrados para impactar con algo de contexto; accidentes fuertes. | Contenido cuyo propósito es impactar sin contexto. | Cada imagen fuerte tiene que tener una razón explicada en el guion; no las uses solo para enganchar. |
| **Actos dañinos y contenido poco confiable** | Actividades de alto riesgo, retos peligrosos en contexto educativo o periodístico. | Glorificar actos peligrosos, desinformación dañina de salud (ej. antivacunas), afirmaciones falsas sobre elecciones, contradecir el consenso sobre el clima. | No presentes como hecho lo que contradice a autoridades sanitarias o científicas; desmentir desinformación sí está permitido. |
| **Contenido de odio, denigrante e incendiario** | Contenido ofensivo con fin educativo o documental; avergonzar o insultar a personas o grupos. | Odio o acoso a grupos protegidos, ataques personales maliciosos, difamación, negar tragedias. | Criticá acciones, no grupos. Si acusás a alguien de algo, que esté documentado (usá 'presunto', 'según…'). |
| **Drogas recreativas** | Contenido centrado en consumo de drogas ilegales sin promoverlo; tráfico narrado con violencia no gráfica. | Promover o glorificar el consumo, instrucciones de compra o fabricación, glorificar o reclutar para carteles. | Narcos y carteles: enfoque documental, sin épica ni instrucciones. Las historias de recuperación y los operativos policiales tienen anuncios completos. |
| **Armas de fuego** | Uso de armas fuera de entornos controlados. | Fabricar o modificar armas, facilitar su venta, menores usando armas sin supervisión. | En historia militar, contá el hecho sin explicar cómo fabricar o modificar armas. |
| **Temas controversiales** | Abuso infantil, abuso sexual, autolesiones, suicidio, trastornos alimentarios, violencia doméstica, aborto: tratamiento documental o educativo como tema principal; miniaturas gráficas. | Descripciones gráficas o detalladas; promover estos temas. | Mencioná sin describir métodos ni detalles. En suicidio y autolesiones, evitá el cómo y sumá recursos de ayuda. |
| **Eventos sensibles y tragedias** | Puede impedirse la monetización en algunos casos; noticias y documentales pueden quedar habilitados. | Lucrar o explotar una tragedia, incluido usar palabras clave de la tragedia como cebo. | No uses una tragedia reciente como gancho ni en el título si el video no es sobre ella; tono respetuoso con las víctimas. |
| **Facilitar conductas deshonestas** | - | Instrucciones para hackear, falsificar documentos, hacer trampa en exámenes, rastrear personas a escondidas. | En casos de estafas o hackeos, explicá qué pasó, no cómo replicarlo. |
| **Tabaco** | Promoción de tabaco, vapeadores y productos relacionados. | Según el caso. | Hablar del tabaco en historia o salud está bien; no recomiendes marcas ni productos. |
| **Contenido para niños y familias** | Temas adultos, sustos o violencia con estética infantil. | Fomentar conductas negativas en contenido para chicos. | Si el canal usa animación tipo dibujito, cuidado con temas oscuros: el sistema puede leerlo como dirigido a niños. |

## 2. Contenido no auténtico (ex 'repetitivo') — Programa de Socios

- **Qué dice:** Desde el 15 de julio de 2025 la política de 'contenido repetitivo' se llama 'contenido no auténtico' y aclara que incluye contenido repetitivo o producido en masa; YouTube dice que nunca fue monetizable. No se monetiza: contenido que parece hecho con plantilla, videos que se sienten iguales entre sí, contenido generado con IA con plantillas genéricas que da impresión de producción en masa sin aporte original del creador, personajes en la misma situación con el mismo final una y otra vez. Sí se permite: misma intro y cierre si el cuerpo cambia, series donde cada video tiene su historia o enfoque, usar IA como herramienta (por ejemplo para editar el guion o generar fondos) si el resultado muestra la visión creativa del creador. La revisión es a nivel canal.
- **Riesgo para faceless:** ALTO. Es la política que más afecta a canales sin cara con guion de IA y voz sintética: si todos tus videos tienen la misma estructura, las mismas frases-puente y el mismo tono genérico, el canal entero puede quedar fuera del Programa de Socios. Por eso esta herramienta nunca uniforma: cada canal con su huella de voz.
- **Cómo revisarlo en el guion:** 1) ¿Este guion aporta algo que no está en las fuentes (ángulo, opinión, investigación, síntesis propia)? 2) ¿Se parece a tus 3 últimos guiones en estructura, gancho y frases? Rotá estructuras y tipos de gancho. 3) ¿Pasó la lista negra anti-IA? 4) ¿Suena a vos (huella de voz) o a cualquiera?
- **Fuente:** https://support.google.com/youtube/answer/1311392 (verificado 2026-10-23)

## 3. Contenido reutilizado — Programa de Socios

- **Qué dice:** No se monetiza contenido tomado de otra fuente sin cambios sustanciales ni comentario original, ni 'contenido que consiste exclusivamente en lecturas de materiales que no creaste' (textos de sitios web, noticias). Tener permiso del autor original no exime. Se permiten reacciones con comentario, reseñas críticas y material editado con historia y comentario propios.
- **Riesgo para faceless:** ALTO si el guion es la lectura de un artículo, de Wikipedia o de la transcripción de otro video, aunque sea con voz propia o IA.
- **Cómo revisarlo en el guion:** Compará el guion con tus fuentes: ninguna frase o párrafo copiado; estructura y orden propios; agregá análisis, conexiones y opinión. Usá las transcripciones de competidores solo para detectar lo que todos dicen (y evitarlo), nunca como base para reescribir.
- **Fuente:** https://support.google.com/youtube/answer/1311392 (verificado 2026-10-23)

## 4. Divulgación de contenido alterado o sintético (casilla 'uso de IA')

- **Qué dice:** Hay que declararlo al subir (en YouTube Studio) cuando el contenido realista fue generado o alterado significativamente con IA y puede confundirse con real: hacer que una persona real diga o haga algo que no hizo, alterar imágenes de un hecho o lugar real, generar una escena realista que no ocurrió, o música generada con IA como foco del video. NO hace falta declarar: contenido claramente irreal (fantasía, animación evidente), retoques menores (filtros, color, desenfoque, limpieza de audio) ni asistencia de producción: usar IA para crear o mejorar el guion, el esquema, la miniatura, el título, infografías, subtítulos o ideas; tampoco clonar tu propia voz para la locución. Declararlo no limita el alcance ni la monetización por sí solo. No declararlo de forma reiterada puede traer etiqueta manual, eliminación o suspensión del Programa de Socios.
- **Riesgo para faceless:** MEDIO. Escribir el guion con IA o usar tu voz clonada no requiere aviso. Sí lo requieren las recreaciones realistas: una escena histórica fotorrealista hecha con IA presentada como real, un personaje real 'diciendo' algo, imágenes realistas de un hecho que no pasó.
- **Cómo revisarlo en el guion:** Marcá en el guion cada escena que vas a generar con IA. Si es realista y muestra personas, lugares o hechos reales de forma que alguien pueda creerla auténtica, marcá la casilla al subir (o aclaralo en el guion: 'recreación').
- **Fuente:** https://support.google.com/youtube/answer/14328491 (verificado 2026-10-23)

## 5. Desinformación médica

- **Qué dice:** No se permite contenido que contradiga a las autoridades sanitarias locales o a la OMS sobre prevención y transmisión de enfermedades, seguridad y eficacia de vacunas aprobadas, o tratamientos (por ejemplo promover sustancias dañinas, decir que un tratamiento aprobado nunca funciona, prometer curas garantizadas, desalentar la atención médica). Excepciones con contexto educativo, documental, científico o artístico (debates, desmentir, contar resultados de estudios, experiencias personales), salvo que se promueva la desinformación. Primera vez: advertencia; después, faltas (strikes) y posible cierre.
- **Riesgo para faceless:** ALTO en nichos de salud, bienestar, psicología, 'remedios naturales' y curiosidades médicas. Nunca presentes al narrador (y menos a un personaje o voz de IA) como médico, abogado o asesor financiero si no lo es.
- **Cómo revisarlo en el guion:** Cada afirmación de salud con fuente oficial o estudio; nada de 'cura', 'elimina', 'los médicos no quieren que sepas'. No presentes al narrador como médico o experto si no lo es. Cerrá con 'consultá a un profesional' cuando corresponda.
- **Fuente:** https://support.google.com/youtube/answer/13813322 (verificado 2026-10-23)

## 6. Spam, prácticas engañosas y clickbait malicioso

- **Qué dice:** Se prohíbe el contenido o metadato que engaña para conseguir interacción. 'Clickbait malicioso': títulos, miniaturas o descripciones que engañan para que hagan clic en un video que no entrega lo prometido (ejemplo oficial: un título que promete un partido completo y muestra un fragmento). También manipulación de interacción, spam de comentarios y estafas. Pedir like, comentario o suscripción está permitido. Consecuencias: eliminación, advertencia o falta; tres faltas en 90 días pueden cerrar el canal.
- **Riesgo para faceless:** MEDIO. Los ganchos de 'secreto', 'nadie sabe' o 'imágenes nunca vistas' son legítimos solo si el video los cumple.
- **Cómo revisarlo en el guion:** Leé el título y la miniatura y preguntate: ¿el guion entrega exactamente eso? ¿En qué minuto? Si prometés 'el detalle que nadie vio', que aparezca y sea real.
- **Fuente:** https://support.google.com/youtube/answer/2801973 (verificado 2026-10-23)

## 7. Derechos de autor, uso legítimo y transcripciones ajenas

- **Qué dice:** El uso legítimo (fair use, en EE. UU.) se decide caso por caso con cuatro factores: propósito (transformar suma), naturaleza de la obra, cantidad usada y efecto en el mercado del original. Mitos oficiales: dar crédito no lo vuelve legítimo, poner 'no se pretende infringir' no sirve, agregar algo propio no lo garantiza. Content ID puede reclamar aunque el uso sea breve. YouTube no decide el uso legítimo: lo deciden los tribunales.
- **Riesgo para faceless:** ALTO si reescribís o leés la transcripción de otro canal (además del reclamo, es contenido reutilizado). También clips, música e imágenes ajenas.
- **Cómo revisarlo en el guion:** El guion se escribe desde fuentes primarias y con tu estructura; las transcripciones de competidores sirven para el 'mapa del nicho', no se reescriben. Citas: breves, con fuente y con comentario. No es asesoramiento legal.
- **Fuente:** https://support.google.com/youtube/answer/9783148 (verificado 2026-10-23)

## Semáforo de revisión

- **Rojo:** promesa del título/miniatura que el guion no cumple · consejos de salud contra autoridades sanitarias · guion basado en la transcripción o el artículo de otro · descripción gráfica de violencia, suicidio o abuso · escena realista de IA sin declarar.
- **Amarillo:** malas palabras frecuentes · tragedia reciente en el gancho · acusaciones sin 'presunto' · guion muy parecido a los anteriores del canal · 3+ rasgos anti-IA.
- **Verde:** contexto educativo/documental claro, fuentes nombradas, aporte propio, título honesto.

La web usa `palabras_sensibles` de biblioteca.json para marcar términos (amarillo/rojo); es una alerta, no un veredicto.
