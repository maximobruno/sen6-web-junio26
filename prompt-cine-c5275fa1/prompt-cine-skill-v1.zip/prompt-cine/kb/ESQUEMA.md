# Esquema de fichas (base de conocimiento de Prompt Cine)

Cada archivo `kb/*.json` es un ARRAY de fichas. Una ficha:

```json
{
  "id": "pelicula-mad-max-fury-road",
  "tipo": "pelicula",
  "nombre": "Mad Max: Fury Road",
  "alias": ["mad max", "madmax", "fury road", "mad max furia en el camino"],
  "autor": "George Miller",
  "anio": 2015,
  "resumen": "Una o dos frases en español sobre qué define su imagen.",
  "encuadre": [{"en": "centered wide shot, subject dead-center of frame", "es": "plano general centrado"}],
  "angulo":   [{"en": "low angle", "es": "contrapicado"}],
  "foco":     [{"en": "deep focus, crisp detail across the frame", "es": "foco profundo"}],
  "luz":      [{"en": "harsh midday desert sun, hard shadows", "es": "sol duro de mediodía"}],
  "color":    [{"en": "saturated orange and teal, crushed blacks", "es": "naranja y verde azulado saturado"}],
  "ambiente": [{"en": "dust storms, rusted war rigs, chrome and scrap metal", "es": "tormentas de polvo, chatarra"}],
  "tecnica":  {"camara": "Arri Alexa Plus / Alexa M", "lente": "Panavision Primo, spherical", "formato": "digital, 2.39:1", "emulsion": ""},
  "relacionados": ["director-george-miller", "dp-john-seale"]
}
```

Reglas:
- `tipo` ∈ pelicula, serie, videoclip, director, dp, fotografo, pintor, camara, lente, emulsion, encuadre, angulo, foco, luz, color, estetica.
- `id` = `<tipo>-<slug-ascii-con-guiones>`; único.
- `alias`: todas las formas en que alguien escribiría la referencia en español o inglés, en minúsculas, sin y con espacios ("madmax", "mad max"), apellidos solos ("kubrick"), títulos en España y Latinoamérica.
- Los campos de prompt (`encuadre`, `angulo`, `foco`, `luz`, `color`, `ambiente`) tienen de 2 a 4 opciones, en inglés de prompt de imagen (concretas, técnicas, sin frases vagas tipo "cinematic look"), con su traducción breve en `es`. Deja `[]` si no aplica (p. ej. una lente no tiene `ambiente`).
- `tecnica`: solo datos que sepas con seguridad; si no estás seguro, cadena vacía. NUNCA inventes cámaras o lentes.
- Fotos sin movimiento: nada de movimientos de cámara (dolly, push-in, travelling).
