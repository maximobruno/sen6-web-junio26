---
name: prompt-cine
description: Convierte una idea en español ("un caballo al estilo Mad Max", "retrato de mi abuela como Kubrick", "auto en la lluvia tipo Blade Runner") en un prompt de IMAGEN cinematográfico con la estructura de 6 cajas — ENCUADRE + ÁNGULO + SUJETO+ACCIÓN + FOCO + LUZ + COLOR — fiel a la referencia, usando una base local de fichas sobre películas, series, videoclips, directores, directores de fotografía, fotógrafos, pintores, cámaras, lentes, emulsiones, esquemas de luz, paletas y estéticas. Usa esta skill siempre que el usuario pida un prompt de imagen, "un prompt cinematográfico", "algo al estilo de [director/película/fotógrafo]", o describa una escena con una referencia visual, aunque no nombre la skill.
---

# Prompt Cine

> Versión: ver el archivo `VERSION` de esta carpeta (V1 = `1`). Si el usuario pregunta qué versión tiene o qué cambió, lee `VERSION` y `NOVEDADES.md`.

Transforma una idea en español en un prompt de imagen cinematográfico en inglés, con datos reales de la referencia sacados de la base local `kb/`. Solo imagen fija: **nunca incluyas movimientos de cámara** (dolly, push-in, travelling, pan, zoom).

## La estructura (no negociable)

Seis cajas, en este orden, unidas con `, `:

| # | Caja | Ejemplo en | Ejemplo es |
|---|------|-----------|-----------|
| 01 | ENCUADRE | medium close-up | plano medio corto |
| 02 | ÁNGULO | low angle | contrapicado |
| — | SUJETO + ACCIÓN | old boxer taping his hands | boxeador veterano vendándose |
| 03 | FOCO | shallow depth of field | fondo desenfocado |
| 04 | LUZ | Rembrandt light, haze | luz Rembrandt + bruma |
| 05 | COLOR | orange and teal | naranja y verde azulado |

Prompt final de ejemplo: `medium close-up, low angle, old boxer taping his hands, shallow depth of field, Rembrandt light, haze, orange and teal`

## Paso 1 — Buscar en la base

`SKILL_DIR` es la carpeta de esta skill (el "Base directory" que aparece al cargarla). Corre:

```bash
node "SKILL_DIR/buscar.mjs" "<la idea tal cual la escribió el usuario>"
```

Devuelve JSON con `principales` (fichas que coinciden, primero las nombradas explícitamente) y `relacionadas` (director, DP o película conectada). Si la idea nombra varias referencias ("Mad Max fotografiado por Deakins"), van todas en `principales`.

- Para pedir opciones de una caja concreta: `node "SKILL_DIR/buscar.mjs" "lluvia neon" --tipo luz` (tipos: pelicula, serie, videoclip, director, dp, fotografo, pintor, camara, lente, emulsion, encuadre, angulo, foco, luz, color, estetica).
- Para ver una ficha entera: `--id <id>`.
- **Si no hay Node** (el comando falla), busca con Grep el nombre de la referencia en minúsculas dentro de `SKILL_DIR/kb/*.json` (campos `nombre` y `alias`) y lee las fichas que aparezcan.

### Regla dura — fuera de la base, se busca en la web

Si el estilo, la referencia o el equipo (cámara, lente, emulsión, formato) que pide el usuario **no está cargado en `kb/`**, o la ficha existe pero le falta el dato técnico que el prompt necesita:

1. Dilo en una línea ("Mad Max no está en la base, busco datos técnicos en la web").
2. **Busca en la web en inglés y en español**, siempre en los dos idiomas: cámara y lentes usados, formato y relación de aspecto, emulsión, esquema de luz y paleta. Buenas fuentes: American Cinematographer, ShotDeck, IMDb (technical specs), entrevistas al director de fotografía, Kodak, fichas de fabricantes y revistas de cine en español.
3. Usa solo datos verificados en esas fuentes. Si algo no aparece, se deja fuera; nunca se inventa equipo.
4. Suma esas fuentes a la línea **Fuentes:** del Paso 3 (ej. "American Cinematographer, may 2015").
5. Si la herramienta de búsqueda web no está disponible, avísalo y sigue con lo que sabes, con el mismo rigor: datos reales, nada inventado.

## Paso 2 — Armar las cajas

1. **Referencia principal manda.** Toma de su ficha las opciones de `encuadre`, `angulo`, `foco`, `luz`, `color`; elige la que mejor sirve al sujeto (un retrato pide close-up aunque la película sea de planos generales; un paisaje pide wide).
2. **Completa con las relacionadas.** Si la película no tiene algo, usa la ficha de su DP (para luz) o de su director (para encuadre y ángulo).
3. **SUJETO + ACCIÓN.** Traduce la idea al inglés y vístela con el `ambiente` de la referencia: "un caballo al estilo Mad Max" → `a war horse armored with welded scrap metal and chrome spikes, galloping through a dust storm`. Una acción concreta, congelada en el instante (es una foto).
4. **FOCO lleva la técnica.** Si la ficha tiene `tecnica` (cámara, lente, emulsión, formato), súmala aquí: `shallow depth of field, shot on Arri Alexa 65, Panavision anamorphic lenses, 2.39:1`. Sin `tecnica` en la ficha, búscala en la web (regla dura del Paso 1); si tampoco aparece ahí, no inventes equipo.
5. **Si el usuario fijó una caja** ("en contrapicado", "en blanco y negro"), su elección gana sobre la ficha.
6. Cada caja: corta, técnica, sin adjetivos vacíos ("cinematic", "epic", "beautiful", "masterpiece", "8k"). Nada de nombres de marca registrada como estilo si el usuario no los pidió explícitamente; la referencia se traduce en sus rasgos visuales, no en "in the style of Mad Max".

## Paso 3 — Entregar

Responde siempre en este formato:

```
**01 ENCUADRE** — <en>  ·  <es>
**02 ÁNGULO** — <en>  ·  <es>
**SUJETO + ACCIÓN** — <en>  ·  <es>
**03 FOCO** — <en>  ·  <es>
**04 LUZ** — <en>  ·  <es>
**05 COLOR** — <en>  ·  <es>
```

Y debajo el prompt completo listo para copiar en un bloque de código:

```
<encuadre>, <ángulo>, <sujeto + acción>, <foco>, <luz>, <color>
```

Cierra con una línea **Fuentes:** con los nombres de las fichas usadas (ej. "Mad Max: Fury Road · John Seale · George Miller"). Si el usuario pide variantes, da hasta 3 prompts cambiando una o dos cajas cada vez, no todo.

## Ampliar la base

Las fichas viven en `SKILL_DIR/kb/*.json` con el formato de `kb/ESQUEMA.md`. Para sumar una referencia nueva, agrega una ficha al archivo que corresponda (o crea uno nuevo) respetando el esquema; `node buscar.mjs --stats` valida y muestra el total y duplicados.
