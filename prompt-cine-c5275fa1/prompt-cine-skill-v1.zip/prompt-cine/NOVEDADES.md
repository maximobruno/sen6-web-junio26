# Novedades de Prompt Cine

Cada versión nueva se anuncia a los alumnos. Para actualizar: borrá la carpeta `prompt-cine` vieja y poné la nueva en el mismo lugar.

## V1 — 20 oct 2026
- Primera versión.
- Estructura de 6 cajas: encuadre, ángulo, sujeto + acción, foco, luz y color. Solo imagen fija, sin movimientos de cámara.
- Base de 771 fichas: 173 películas, 21 series, 10 videoclips, 96 directores, 62 directores de fotografía, 82 fotógrafos, 25 pintores, 43 cámaras, 40 lentes, 33 emulsiones y 186 términos de encuadre, ángulo, foco, luz, color y estética.
- Si la referencia no está en la base, busca los datos técnicos en la web (en inglés y en español) y cita las fuentes.
