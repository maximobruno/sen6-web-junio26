#!/usr/bin/env node
// Buscador local de la base de Prompt Cine: alias exactos + BM25 + fichas relacionadas.
// Uso: node buscar.mjs "un caballo al estilo madmax" [--top 6] [--tipo luz] [--json]
//      node buscar.mjs --id pelicula-mad-max-fury-road
//      node buscar.mjs --stats
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'kb');
const CAMPOS = ['encuadre', 'angulo', 'foco', 'luz', 'color', 'ambiente'];
const VACIAS = new Set(('de la el los las un una unos unas al del y o en con por para estilo style like a an the of and in with como tipo look onda rollo que se su sus mi me quiero hace hacer foto imagen prompt version inspirado inspired cinematic cinematografico').split(' '));

const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const tokens = s => norm(s).split(' ').filter(t => t.length > 1 && !VACIAS.has(t));

function cargar() {
  const fichas = [];
  for (const f of fs.readdirSync(DIR).filter(f => f.endsWith('.json')).sort()) {
    let arr;
    try { arr = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); }
    catch (e) { console.error(`! ${f}: JSON inválido (${e.message})`); continue; }
    for (const x of arr) if (x && x.id) fichas.push({ ...x, _archivo: f });
  }
  return fichas;
}

function texto(x) {
  const partes = [x.nombre, x.autor, x.resumen, x.tipo, ...(x.alias || [])];
  for (const c of CAMPOS) for (const o of x[c] || []) partes.push(o.en, o.es);
  if (x.tecnica) partes.push(...Object.values(x.tecnica));
  return partes.join(' ');
}

function indexar(fichas) {
  const docs = fichas.map(x => {
    const tf = new Map();
    for (const t of tokens(texto(x))) tf.set(t, (tf.get(t) || 0) + 1);
    // el nombre y los alias pesan triple
    for (const t of tokens([x.nombre, ...(x.alias || [])].join(' '))) tf.set(t, (tf.get(t) || 0) + 3);
    let len = 0; for (const v of tf.values()) len += v;
    return { x, tf, len };
  });
  const df = new Map();
  for (const d of docs) for (const t of d.tf.keys()) df.set(t, (df.get(t) || 0) + 1);
  const avg = docs.reduce((s, d) => s + d.len, 0) / Math.max(docs.length, 1);
  return { docs, df, avg, N: docs.length };
}

function bm25(idx, qt, d) {
  const k1 = 1.4, b = 0.75;
  let s = 0;
  for (const t of qt) {
    const f = d.tf.get(t); if (!f) continue;
    const n = idx.df.get(t);
    const idf = Math.log(1 + (idx.N - n + 0.5) / (n + 0.5));
    s += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * d.len / idx.avg));
  }
  return s;
}

// Coincidencia de alias: la consulta normalizada (con y sin espacios) contiene el alias completo.
function aliasHit(x, qn, qPegada) {
  let mejor = 0;
  for (const a of [x.nombre, ...(x.alias || [])]) {
    const an = norm(a); if (an.length < 3) continue;
    const dentro = (' ' + qn + ' ').includes(' ' + an + ' ') || (an.length >= 5 && qPegada.includes(an.replace(/ /g, '')));
    if (dentro) mejor = Math.max(mejor, 10 + an.length);
  }
  return mejor;
}

export function buscar(consulta, { top = 6, tipo } = {}) {
  const fichas = cargar();
  const porId = new Map(fichas.map(x => [x.id, x]));
  const idx = indexar(fichas);
  const qn = norm(consulta), qPegada = qn.replace(/ /g, ''), qt = tokens(consulta);
  const puntuadas = idx.docs
    .filter(d => !tipo || d.x.tipo === tipo)
    .map(d => ({ x: d.x, alias: aliasHit(d.x, qn, qPegada), bm: bm25(idx, qt, d) }))
    .map(r => ({ ...r, score: r.alias * 3 + r.bm }))
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score);

  // Referencias = las que matchean por alias; si no hay, las mejores por BM25.
  const refs = puntuadas.filter(r => r.alias > 0);
  const principales = (refs.length ? refs : puntuadas).slice(0, top);
  const ids = new Set(principales.map(r => r.x.id));
  const relacionadas = [];
  for (const r of principales.slice(0, 3)) for (const id of r.x.relacionados || []) {
    if (!ids.has(id) && porId.has(id)) { ids.add(id); relacionadas.push(porId.get(id)); }
  }
  return {
    referencias_por_nombre: refs.length > 0,
    principales: principales.map(r => ({ score: +r.score.toFixed(2), ...limpia(r.x) })),
    relacionadas: relacionadas.slice(0, 4).map(limpia),
  };
}

const limpia = x => { const { _archivo, ...resto } = x; return resto; };

// --- CLI ---
// realpath en los dos lados: la skill suele instalarse como symlink y sin esto el CLI no corre (sale mudo).
const real = p => { try { return fs.realpathSync(p); } catch { return path.resolve(p); } };
if (process.argv[1] && real(fileURLToPath(import.meta.url)) === real(process.argv[1])) {
  const args = process.argv.slice(2);
  const opt = n => { const i = args.indexOf(n); return i >= 0 ? args.splice(i, 2)[1] : undefined; };
  if (args.includes('--stats')) {
    const fichas = cargar(), porTipo = {}, ids = new Map();
    for (const x of fichas) { porTipo[x.tipo] = (porTipo[x.tipo] || 0) + 1; ids.set(x.id, (ids.get(x.id) || 0) + 1); }
    const dup = [...ids].filter(([, n]) => n > 1).map(([id]) => id);
    console.log(JSON.stringify({ total: fichas.length, porTipo, duplicados: dup }, null, 2));
    process.exit(0);
  }
  const id = opt('--id');
  if (id) { const x = cargar().find(f => f.id === id); console.log(x ? JSON.stringify(limpia(x), null, 2) : 'no existe'); process.exit(0); }
  const top = +(opt('--top') || 6), tipo = opt('--tipo');
  const q = args.filter(a => !a.startsWith('--')).join(' ');
  if (!q) { console.error('Uso: node buscar.mjs "idea" [--top N] [--tipo luz]'); process.exit(1); }
  console.log(JSON.stringify(buscar(q, { top, tipo }), null, 2));
}
