---
name: faceless-plano-continuo
description: Produce un video faceless documental hecho 100 % con código (Remotion), en UN solo plano continuo de cámara sobre un gran mundo dibujado (mapa, escritorio, ciudad, cielo, pizarra), sincronizado palabra por palabra con una locución. Usala cuando el usuario pida "un video faceless", "animar mi guion", "un documental con código", "video estilo plano continuo", "hacé el video con esta locución", o quiera convertir un guion + audio en un MP4 sin generadores de video con IA — aunque no nombre la skill.
---

# Faceless en plano continuo (SEN6)

Convertís una locución en un video donde **todo está dibujado con código** y la cámara **nunca corta**: se desliza por un mundo grande, empuja sobre los detalles, se aleja para viajar y vuelve a entrar. Nada de generadores de video con IA ni stock.

Hablale al usuario en español, claro y sin jerga. Es principiante: explicá cada paso en una línea antes de hacerlo.

## 0. Antes de empezar: pedí los insumos

Preguntá (de a una cosa, con opciones) y no avances sin estas respuestas:

1. **Locución** (mp3/wav). Si no la tiene, ofrecé generarla con ElevenLabs o una voz local; si tampoco, pedile el guion y avisá que la duración final depende del audio.
2. **Formato**: 16:9 (1920×1080, YouTube) o 9:16 (1080×1920, Reels/Shorts). 30 fps.
3. **Mundo**: ¿sobre qué superficie transcurre? Carta náutica, escritorio de investigador, ciudad de noche, cielo/constelaciones, pizarra, línea de tiempo… Proponé el que mejor cuente la historia.
4. **Referencias de estilo**: una carpeta con capturas (Pinterest, láminas, otros videos). Copiá su clima: paleta, tipografía, textura.
5. **Fotos y documentos reales** de personas, lugares y objetos. Si no tiene, ofrecé buscarlos en Wikimedia Commons (dominio público o CC) y anotá el crédito de cada uno.
6. **Música**: Mixkit (libre, sin atribución) salvo que traiga la suya.

Trabajá en una carpeta del proyecto con esta estructura:
```
proyecto/
  locucion/        audio original
  fuentes/         fotos y documentos reales + creditos.md
  referencias/     capturas de estilo
  work/            transcripción, mezcla, temporales
  beats.md         la tabla de beats
  remotion/        el video
```

## 1. Tiempos por palabra (Whisper)

Transcribí la locución con tiempos por palabra (faster-whisper, modelo `small` o `medium`, `language="es"`, `word_timestamps=True`, `vad_filter=True`). Guardá `work/transcript.json`.

Después escribí `tiempos.py`: una función `A("frase exacta", word=n)` que busca la frase en las palabras normalizadas (sin tildes ni signos) **desde la última coincidencia en adelante** y devuelve el segundo de la palabra n. Con eso generá `remotion/src/t.json`: un diccionario `{ancla: segundo}` con todos los momentos del video, más `fin`. Ver `referencias/tiempos.py`.

- Si Whisper se come una palabra, anclá en una frase vecina que sí esté.
- Validá que los tiempos crezcan; si una frase repetida agarra la ocurrencia equivocada, usá una frase más larga.

## 2. Tabla de beats (OBLIGATORIA antes de construir)

Escribí `beats.md` con una fila por idea de la locución:

| # | Tiempo | Narración (resumen) | Protagonista en pantalla | Texto en pantalla |

Reglas para llenarla (ver `referencias/reglas.md`):
- Un solo protagonista por línea (una foto, una palabra o un documento). Todo lo demás se atenúa.
- Cada frase aparece una sola vez: o en un documento real o tipeada, nunca las dos.
- Texto grande o nada. Nada de etiquetas chicas, cintas, sellos o notas decorativas que no cuenten la historia.

**Mostrale la tabla al usuario y esperá su OK.** Preguntá lo que no esté claro.

## 3. El mundo

Un solo lienzo enorme (por ejemplo 6500×3600 unidades) dibujado en SVG dentro de Remotion. Cada escena vive **en el lugar del mundo donde pasa la historia** (Génova está en Génova). Elementos:
- Fondo con textura (papel, pizarra, asfalto) generada una vez con Python (numpy + Pillow) a `public/`.
- Piezas dibujadas como componentes reutilizables (`piezas.tsx`): barcos, edificios, íconos, sellos, flechas, rutas punteadas. Mismo trazo y paleta que las referencias.
- Fotos reales como láminas físicas que **caen** sobre el mundo: marco, sombra, leve rotación, aparecen con un rebote corto.
- Textos protagonistas con revelado por máscara (wipe) y halo del color del fondo para que se lean sobre cualquier cosa.

Cada elemento tiene su ventana de vida: entra en su ancla y **sale del todo** después de su beat (`fuera(t, b) = 1 - ease((t - b) / .6)`). Si no sale, se pisa con los planos generales.

## 4. La cámara (un solo plano)

Usá el patrón de `referencias/camara.ts`:
- Lista de paradas `KEYS = [tiempo, x, y, zoom, rigidez]`, una por beat. Zoom alto = cerca; zoom bajo = plano general para viajar.
- Las posiciones se precalculan con un **resorte críticamente amortiguado** (nunca frena en seco, nunca rebota) y el zoom se interpola en logaritmo.
- **Deriva**: en cada parada la cámara ya avanza un 7 % hacia la siguiente, así nunca queda quieta.
- **Cámara en mano**: suma de 3 senos lentos en x, y y una rotación mínima.
- **Golpes**: en los beats de impacto (sello, fecha) una sacudida que decae en 0,35 s.
- **Motion blur**: blur de CSS proporcional a la velocidad de la cámara, solo en los viajes rápidos.
- Encima de todo: textura multiplicada, grano animado (8 cuadros), glow suave y viñeta.

## 5. Revisar antes del render

1. Renderizá **stills** de cada beat a escala 0.5 (`renderStill` en un script `stills.mjs`) y miralos en grilla. Buscá: textos encimados, protagonistas que no se leen en un celular, restos del beat anterior, cosas fuera de cuadro (en 9:16 respetá la zona segura de Reels).
2. Renderizá secuencias cortas de los viajes de cámara y verificá que no salten ni frenen.
3. Mostrale la grilla al usuario. Corregí y repetí. Es mucho más barato que re-renderizar.

## 6. Render y sonido

- Render **mudo**: `npx remotion render src/index.ts <Comp> out/video_raw.mp4 --muted --video-bitrate=14M`. Si dura más de 3 minutos, en segundo plano, y ofrecé un tablero de progreso.
- Mezcla en Python: voz + música de Mixkit a −15 dB debajo de la voz (fundido de entrada 3 s y de salida 2,5 s) + efectos cortos en los beats (golpe en los sellos, papel en las fotos que caen, whoosh en los viajes largos). Limitador y `loudnorm` a **−14 LUFS**.
- Unir con ffmpeg: `ffmpeg -i video_raw.mp4 -i mezcla.wav -c:v copy -c:a aac -b:a 192k -shortest final.mp4`.
- La duración del video tiene que coincidir con la locución.

## 7. Entregar

- Un solo MP4 final a la vista; versiones previas en `archivo/`.
- `fuentes/creditos.md` con el crédito y la licencia de cada imagen real (las CC BY-SA piden atribución en la descripción).
- Al final, anotá en `bitacora.md` qué falló y cómo se arregló: es lo que mejora el próximo video.

## Errores que ya sabemos que pasan

Ver `referencias/bitacora-colon.md` (caso real). Los más comunes: textos viejos que no salen y se pisan; anclas corridas porque Whisper se comió una palabra; la cámara final que se aleja de más; fotos con fondo de color que hay que recortar; música 20 dB abajo de la voz que no se oye.
