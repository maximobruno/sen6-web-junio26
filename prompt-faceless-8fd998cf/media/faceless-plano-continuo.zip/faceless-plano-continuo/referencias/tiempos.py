"""Anclas: frase -> segundo exacto en la locución. Escribe remotion/src/t.json
Uso: python3 tiempos.py   (lee work/transcript.json: [{"words":[{"w","s","e"}]}])"""
import json, re, unicodedata
W = [w for s in json.load(open("work/transcript.json")) for w in s["words"]]
def norm(w): return re.sub(r"[^a-z0-9ñ]", "", unicodedata.normalize("NFKD", w.lower()).encode("ascii", "ignore").decode())
N = [norm(w["w"]) for w in W]
last = [0]
def A(frase, word=0, end=False):
    """Segundo en que se dice la palabra `word` de `frase` (o su final con end=True).
    Busca desde la última coincidencia: escribí las anclas en el orden del guion."""
    q = [norm(x) for x in frase.split()]
    for i in range(last[0], len(N) - len(q) + 1):
        if N[i:i + len(q)] == q:
            last[0] = i
            j = i + (len(q) - 1 if end else word)
            return round(W[j]["e"] if end else W[j]["s"], 2)
    raise SystemExit("no encontré: " + frase + "  → usá una frase vecina que Whisper sí haya escrito")

T = dict(
    inicio=0.0,
    # una línea por momento visual, en el orden del guion. Ejemplos del caso Colón:
    tierra=A("Tierra se llamaba"),        # el título golpea al decir "Tierra"
    luz=A("una luz", 1),                  # la lucecita titila en "luz"
    asia=A("buscaba Asia", 1),            # ASIA gigante en "Asia"
    y1476=A("mil cuatrocientos setenta y seis"),
)
T["fin"] = round(W[-1]["e"], 2)
v = list(T.values())
assert all(a <= b for a, b in zip(v, v[1:])), "hay anclas fuera de orden"
json.dump(T, open("remotion/src/t.json", "w"), indent=1)
print(len(T), "anclas · fin", T["fin"])
