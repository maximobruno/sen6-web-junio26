Quiero un video de motion cinematográfico hecho completamente con código. Sin generadores de video con IA y sin material de stock. Cada cuadro tiene que estar dibujado con código (sirve canvas de HTML) y renderizado a MP4.

INSUMOS (adjuntos):
- Guion / locución: [adjuntá el audio] — tiempos de cada línea: [pegá cada línea con su segundo de inicio, o pedile a Claude que los saque del audio]
- Fotos reales de las personas, lugares u objetos: [adjuntas]
- Referencias de estilo: [adjuntas — muestran el look que quiero, copiá su clima]
- Formato: [ej. 9:16, 1080x1920, 30 fps] — la duración tiene que coincidir exactamente con la locución.

EL ESTILO:
- Todo el video es UN solo movimiento de cámara continuo sobre un gran mundo: un mapa, un escritorio, una pizarra, lo que mejor le quede a la historia. Nada corta y no cambian diapositivas. La cámara se desliza, empuja sobre los detalles, se aleja para viajar y vuelve a entrar.
- El movimiento tiene que sentirse suave y filmado. Cada arranque y cada freno llevan ease in y out. La cámara nunca se detiene en seco: en las pausas sigue derivando despacio hacia donde va a ir. Sumá cámara en mano sutil, motion blur en los movimientos rápidos, grano de película, un glow suave y viñeta.
- Las fotos y documentos reales caen sobre el mundo como objetos físicos (copias, papeles, recortes), en el lugar donde pasa la historia.

REGLAS DE NARRACIÓN Y LECTURA (lo más importante):
1. Una idea por línea de locución. Cada línea tiene UN protagonista en pantalla (una foto, una palabra o un documento) y todo lo demás se atenúa.
2. Cada frase aparece en pantalla una sola vez, nunca repetida. Si el narrador la dice, o se ve en un documento real o se tipea en pantalla, nunca las dos cosas.
3. Nada de texto de relleno. El cuerpo de los documentos son líneas grises suaves que se leen como papel, no palabras que la gente intente leer.
4. Tipografía grande y legible: las palabras protagonistas muy grandes y las etiquetas nunca chicas. Si no se lee en un celular en un segundo, es muy chica o hay demasiado.
5. Menos es más. Dejá afuera el desorden decorativo (cinta, sellos, notas, etiquetas de más) que no sea parte de la historia.
6. Los momentos visuales caen exactamente en la palabra dicha: un círculo que se dibuja cuando se dice la palabra, un sello que golpea en el beat.

PROCESO:
- Antes de construir, escribí una tabla de beats: tiempo → narración → el protagonista en pantalla → texto en pantalla. Mostrámela y preguntame todo lo que no esté claro.
- Tomate tu tiempo. La calidad importa más que la velocidad. Priorizá diseño, movimiento suave y claridad antes que agregar cosas.
- Antes del render final, revisá tu propio trabajo: mirá stills de cada beat y secuencias de cuadros de los movimientos de cámara. Corregí lo amontonado, difícil de leer, superpuesto, o lo que salte o frene de golpe.
- Entregá el MP4 final con mi locución sincronizada, en el formato exacto de arriba.
