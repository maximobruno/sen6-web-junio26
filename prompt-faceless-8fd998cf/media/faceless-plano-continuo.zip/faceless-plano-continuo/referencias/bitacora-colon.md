# Bitácora del caso Colón (demo de 5:25, noviembre 2026)

Qué falló y cómo se arregló. Leela antes de empezar: son errores que se repiten.

| Problema | Causa | Arreglo |
|---|---|---|
| La parte 2 de la locución no se generó | Faltaban créditos de ElevenLabs | Se hizo un demo solo con la parte 1. Calculá los créditos antes de generar. |
| Textos viejos encimados ("un error de cálculo" sobre Europa) | Los protagonistas no salían después de su beat | Función `fuera()`: cada texto se desvanece del todo 0,6 s después de su beat; lo que queda de fondo baja a 0,12. |
| Las costas no aparecían | La simplificación de polígonos cerrados devolvía 0 puntos | Partir cada anillo en dos mitades antes de simplificar. |
| La tierra se confundía con el mar | Mismo tono de papel | Relleno de tierra más oscuro (#c9a96e) + líneas de ondas en la costa. |
| Las rutas punteadas dibujaban un punto antes de tiempo | Condición `p > 0` mal puesta | Retornar nada cuando `p <= 0`. |
| Anclas corridas | Whisper se comió "San Vicente" | Anclar en una frase vecina ("al Cabo de"). |
| La foto de las Capitulaciones tenía fondo azul | Escaneo del archivo | Recorte automático en `preparar.py`. |
| Wikimedia devolvía error 429 | Demasiadas descargas seguidas | User-Agent propio + reintentos con pausa. |
| El plano final se alejaba de más | Última parada con zoom muy bajo | Zoom final 0,8 y rigidez 0,6 (lento). |
| La música no se oía | Quedó 20 dB debajo de la voz | Música a −15 dB, segundo tema +4 dB, después limitador y −14 LUFS. |

**Lo que funcionó:** un solo `t.json` compartido entre el video y la mezcla de sonido garantiza que imagen, efectos y voz caigan juntos.
