// Cámara de plano continuo para Remotion (patrón del caso Colón).
// El mundo es un <svg> enorme; la cámara solo cambia su viewBox cuadro a cuadro.
import T from "./t.json";
export const FPS = 30;
export const DURACION = Math.ceil((T.fin + 1.8) * FPS);
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));

// [tiempo, x, y, zoom, rigidez]. zoom 2-3 = primer plano · 0.3-0.5 = plano general para viajar.
// rigidez: 0.6 lento y pesado · 1.2 normal · 2.2 rápido (golpes).
type K = [number, number, number, number, number?];
export const KEYS: K[] = [
  [0, 1560, 1790, 2.3],
  [T.tierra - .3, 1560, 1650, 3.0, 2.2],   // empuja sobre el barco antes del grito
  [T.asia, 2500, 1600, .36, 1.0],          // se aleja: todo el océano
  // ... una parada por beat
];

// Resorte críticamente amortiguado, precalculado. Nunca frena en seco, nunca rebota.
export const CAM = (() => {
  const out: { x: number; y: number; z: number }[] = [];
  let x = KEYS[0][1], y = KEYS[0][2], lz = Math.log(KEYS[0][3]);
  let vx = 0, vy = 0, vz = 0;
  const sub = 4, dt = 1 / FPS / sub;
  for (let f = 0; f < DURACION + 2; f++) {
    const t = f / FPS;
    let i = 0; while (i + 1 < KEYS.length && KEYS[i + 1][0] <= t) i++;
    const k = KEYS[i], nx = KEYS[Math.min(i + 1, KEYS.length - 1)];
    const span = Math.max(.5, nx[0] - k[0]);
    const d = i + 1 < KEYS.length ? .07 * clamp((t - k[0]) / span) : 0; // DERIVA hacia la próxima parada
    const tx = k[1] + (nx[1] - k[1]) * d, ty = k[2] + (nx[2] - k[2]) * d;
    const tz = Math.log(k[3]) + (Math.log(nx[3]) - Math.log(k[3])) * d;      // zoom en logaritmo
    const w = (k[4] ?? 1.2) * 2.2;
    for (let s = 0; s < sub; s++) {
      vx += (w * w * (tx - x) - 2 * w * vx) * dt; x += vx * dt;
      vy += (w * w * (ty - y) - 2 * w * vy) * dt; y += vy * dt;
      vz += (w * w * (tz - lz) - 2 * w * vz) * dt; lz += vz * dt;
    }
    out.push({ x, y, z: Math.exp(lz) });
  }
  return out;
})();

// Momentos de impacto: la cámara recibe un golpe que decae en 0,35 s.
export const GOLPES: number[] = [T.tierra];

// Devuelve viewBox, rotación y blur para el cuadro f. ANCHO/ALTO del formato (1920x1080 o 1080x1920).
export function camara(f: number, ANCHO = 1920, ALTO = 1080) {
  const t = f / FPS, c = CAM[f], c1 = CAM[Math.max(0, f - 1)];
  // cámara en mano: tres senos lentos y desfasados
  let sx = 3 * Math.sin(t * .7) + 2 * Math.sin(t * 1.9 + 1) + 1.2 * Math.sin(t * 3.3 + 2);
  let sy = 2.4 * Math.sin(t * .9 + .4) + 1.6 * Math.sin(t * 2.3) + 1 * Math.sin(t * 3.7 + 1);
  for (const g of GOLPES) {
    const d = t - g;
    if (d > 0 && d < .35) { const a = 9 * (1 - d / .35); sx += a * Math.sin(d * 90); sy += a * Math.cos(d * 70); }
  }
  const rot = .12 * Math.sin(t * .5) + .06 * Math.sin(t * 1.3);
  // motion blur: solo cuando la cámara viaja rápido (traslación + zoom)
  const vel = Math.hypot(c.x - c1.x, c.y - c1.y) * c.z * FPS + Math.abs(Math.log(c.z / c1.z)) * FPS * 900;
  const blur = clamp((vel - 250) / 900) * 5;
  const w = ANCHO / c.z, h = ALTO / c.z;
  const viewBox = `${c.x - w / 2 - sx / c.z} ${c.y - h / 2 - sy / c.z} ${w} ${h}`;
  return { viewBox, rot, blur, t };
}

// Uso en el componente:
// const { viewBox, rot, blur, t } = camara(useCurrentFrame());
// <AbsoluteFill style={{ filter: blur > .2 ? `blur(${blur.toFixed(2)}px)` : undefined, transform: `rotate(${rot}deg) scale(1.01)` }}>
//   <svg width={1920} height={1080} viewBox={viewBox} preserveAspectRatio="xMidYMid slice"><Mundo t={t} /></svg>
// </AbsoluteFill>
// + capas encima: textura (mix-blend multiply), viñeta (radial-gradient), glow (screen), grano{f%8}.png (overlay .16)
