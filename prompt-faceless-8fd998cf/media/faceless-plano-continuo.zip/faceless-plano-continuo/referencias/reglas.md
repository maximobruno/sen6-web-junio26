# Reglas de narración y lectura

1. **Una idea por línea, un protagonista.** Cada línea de locución tiene UNA cosa en foco: una foto, una palabra o un documento. Todo lo demás se atenúa (opacidad 0,12–0,15) o sale.
2. **Cada frase aparece una sola vez.** Si el narrador la dice, o se ve en un documento real o se tipea en pantalla, nunca las dos.
3. **Nada de texto de relleno.** El cuerpo de los documentos son líneas grises suaves que se leen como papel, no palabras.
4. **Tipografía grande.** Si no se lee en un celular en un segundo, sobra o está chico. Nunca etiquetas chicas.
5. **Menos es más.** Afuera la cinta, los sellos, las notas y las etiquetas que no cuentan la historia.
6. **En la palabra exacta.** El círculo se dibuja cuando se dice la palabra; el sello golpea en el beat. Todo anclado con `A("frase")`.
7. **Lo que entra, sale.** Cada texto protagonista desaparece del todo después de su beat.

# Reglas de cámara

- UN solo movimiento continuo. Sin cortes, sin cambios de diapositiva.
- Todo arranque y freno con ease in/out (resorte críticamente amortiguado).
- En las pausas la cámara sigue derivando hacia donde va a ir.
- Cámara en mano sutil, motion blur solo en los viajes rápidos, grano, glow suave y viñeta.
- Las fotos reales caen sobre el mundo como objetos físicos, en el lugar donde pasa la historia.

# Checklist antes del render final

- [ ] La tabla de beats está aprobada por el usuario.
- [ ] Cada beat tiene un solo protagonista y se lee en el celular.
- [ ] Ningún texto queda encimado con el del beat siguiente.
- [ ] Los viajes de cámara no saltan ni frenan en seco (mirar secuencias, no solo stills).
- [ ] En 9:16, todo dentro de la zona segura (x 60–1020, y 250–1460).
- [ ] Las fotos reales tienen su crédito en fuentes/creditos.md.
- [ ] La música se oye pero no tapa la voz; el final da −14 LUFS.
- [ ] La duración coincide con la locución.
