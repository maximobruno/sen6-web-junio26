// Prueba de animación 100 % código (kit v2): Lajos corre con la bolsa de billetes; cámara de seguimiento con parallax.
import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { Escena, Persona2, Billete2, P } from "./kit2";
const Casa: React.FC<{ x: number; w: number; h: number; c: string; co: string; base: number }> = ({ x, w, h, c, co, base }) => (
  <g transform={`translate(${x},${base - h})`}>
    <rect width={w} height={h} fill={c} /><rect x={w * 0.72} width={w * 0.28} height={h} fill={co} />
    <rect x={-10} y={-24} width={w + 20} height={34} fill={co} />
    {[0, 1, 2].map((r) => [0, 1].map((k) => <g key={r + "-" + k} transform={`translate(${w * (0.16 + k * 0.42)},${60 + r * 170})`}>
      <rect width={w * 0.26} height={120} fill={P.marco} /><rect x={10} y={10} width={w * 0.26 - 20} height={100} fill={P.vidrio} /></g>))}
    <rect x={w * 0.36} y={h - 190} width={w * 0.28} height={190} fill={P.marco} />
  </g>
);
export const Corre2: React.FC = () => {
  const f = useCurrentFrame();
  const v = 18; // velocidad del fondo cercano (px/frame)
  const ph = f * 0.42, sw = Math.sin(ph), bob = -Math.abs(Math.cos(ph)) * 22;
  const casasLejos = [P.lavanda, P.malva, "#C9B9D6", P.lavanda, P.malva, "#C9B9D6", P.lavanda, P.malva];
  const casasCerca = [P.ciruela, P.teal, P.madera, "#7E6BA8", P.teal, P.ciruela, P.madera, "#7E6BA8"];
  return (
    <AbsoluteFill>
      <Escena fondo="#CFC6E6">
        <rect width={1920} height={700} fill="#D8D0EC" />
        {/* lejos: se mueven a 1/3 de velocidad */}
        <g transform={`translate(${-((f * v / 3) % 2400)},0)`}>{[...casasLejos, ...casasLejos].map((c, i) => <Casa key={i} x={i * 300} w={280} h={520 + (i % 3) * 60} c={c} co="#A79CC4" base={760} />)}</g>
        {/* vereda y calle */}
        <rect y={760} width={1920} height={320} fill="#BDB3A6" />
        <g transform={`translate(${-((f * v) % 240)},0)`}>{Array.from({ length: 12 }).map((_, i) => <rect key={i} x={i * 240} y={900} width={150} height={14} rx={7} fill="#A89E92" />)}</g>
        {/* cerca: velocidad completa */}
        <g transform={`translate(${-((f * v) % 3200)},0)`}>{[...casasCerca, ...casasCerca].slice(0, 12).map((c, i) => <Casa key={i} x={i * 520 - 200} w={380} h={560} c={c} co="#00000022" base={780} />)}</g>
        {/* billetes que vuelan detrás */}
        {Array.from({ length: 6 }).map((_, i) => { const t = (f + i * 23) % 70; return <Billete2 key={i} x={860 - t * 9 - i * 30} y={560 + Math.sin((f + i * 30) / 9) * 40 + t * 2} w={110} rot={(f * 6 + i * 50) % 360} />; })}
        {/* Lajos corriendo (perfil 3/4 hacia la derecha), sombra en el piso */}
        <ellipse cx={960} cy={1062} rx={170 - Math.abs(Math.cos(ph)) * 30} ry={22} fill="#00000022" />
        <g transform={`translate(0,${bob})`}>
          <Persona2 x={960} y={1060} s={0.8} traje="chaleco" pelo="gorra" bigote parpadea
            pose={{ torso: 8, cab: 4, pI: sw * 34, pD: -sw * 34, rI: Math.max(0, -sw) * 50 + 8, rD: Math.max(0, sw) * 50 + 8,
              bI: -sw * 38 + 10, aI: 40, bD: 150, aD: 40, boca: "abierta" }}
            enMano={<g transform="translate(-20,-40)"><ellipse cx={-40} cy={20} rx={190} ry={150} fill="#B9925E" /><ellipse cx={10} cy={40} rx={130} ry={110} fill="#A47F4E" />
              <Billete2 x={-90} y={-110} w={170} rot={-20} /><Billete2 x={20} y={-130} w={160} rot={15} /><Billete2 x={-10} y={-90} w={150} rot={-5} /></g>} />
        </g>
      </Escena>
    </AbsoluteFill>
  );
};
