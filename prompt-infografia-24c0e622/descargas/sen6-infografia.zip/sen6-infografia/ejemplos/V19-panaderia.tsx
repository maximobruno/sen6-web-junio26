// V19 · "Y con ese billete, a las pocas semanas, no te alcanzaba ni para el pan."
// Panadería: el panadero niega con la cabeza y el dedo; Lajos ofrece el billete y baja el brazo, triste. Cámara fija.
import React from "react";
import { useCurrentFrame } from "remotion";
import { Escena, Persona2, Billete2, Ventana, P, ease } from "../kit2";
import { EnCabeza, EnTorso, Pan } from "./formasB";

const Estante: React.FC<{ y: number; x?: number; w?: number }> = ({ y, x = 40, w = 860 }) => (
  <g><rect x={x} y={y} width={w} height={26} fill={P.madera} /><rect x={x} y={y + 26} width={w} height={12} fill={P.maderaOsc} /></g>
);

export const V19: React.FC<{ d: number }> = ({ d }) => {
  const f = useCurrentFrame();
  const B = { x: 560, y: 1160, s: 0.95 };
  const L = { x: 1480, y: 1240, s: 0.95 };
  const niega = f > 18 && f < 100 ? Math.sin((f - 18) * 0.38) * 9 : 0;
  const baja = ease(f, 60, 88);
  const ofrece = ease(f, 0, 14, 0.85, 1);
  return (
    <Escena fondo="#D9C6DD">
      {/* pared y estantes con panes */}
      <rect width={1920} height={1080} fill="#D9C6DD" />
      <rect x={0} y={150} width={940} height={640} fill="#C9B3CF" />
      {[300, 470, 640].map((y, r) => <g key={y}>
        <Estante y={y} />
        {Array.from({ length: 5 }).map((_, i) => <Pan key={i} x={120 + i * 170 + (r % 2) * 40} y={y - (r === 1 ? 46 : 34)} w={r === 1 ? 130 : 160} redondo={r === 1} />)}
      </g>)}
      <Ventana x={1220} y={150} w={480} h={380} />
      {/* cartel chico */}
      <rect x={1060} y={60} width={420} height={80} rx={10} fill={P.ciruela} />
      <text x={1270} y={116} textAnchor="middle" fontFamily="Poppins, Arial, sans-serif" fontWeight={700} fontSize={44} fill={P.crema} letterSpacing={4}>PANADERÍA</text>
      {/* panadero */}
      <Persona2 x={B.x} y={B.y} s={B.s} traje="chaleco" pelo="pelado"
        pose={{ cab: niega, bD: 150, aD: 30, bI: 20, aI: 60, boca: f > 18 && f < 100 ? (Math.sin(f * 0.7) > 0 ? "abierta" : "cerrada") : "cerrada", cejas: -4 }}
        enMano={<g transform={`rotate(${Math.sin(f * 0.55) * 20} 0 0)`}><rect x={-34} y={-128} width={30} height={92} rx={15} fill={P.piel} /><circle cx={30} cy={-30} r={22} fill={P.pielOsc} /></g>} />
      <EnTorso x={B.x} y={B.y} s={B.s}>
        <rect x={-60} y={-560} width={20} height={80} fill="#EDEAE3" /><rect x={40} y={-560} width={20} height={80} fill="#EDEAE3" />
        <path d="M-95,-500 L95,-500 L120,-160 L-120,-160 Z" fill="#FFFFFF" />
        <path d="M40,-500 L95,-500 L120,-160 L60,-160 Z" fill="#E6E2DA" />
      </EnTorso>
      <EnCabeza x={B.x} y={B.y} s={B.s} cab={niega}>
        {/* bigote grande */}
        <path d="M-120,70 Q-90,30 0,52 Q90,30 120,70 Q130,40 100,36 Q60,8 0,38 Q-60,8 -100,36 Q-130,40 -120,70 Z" fill={P.pelo} />
        {/* gorro de panadero */}
        <rect x={-140} y={-210} width={280} height={84} rx={10} fill="#FFFFFF" />
        <rect x={60} y={-210} width={80} height={84} fill="#E6E2DA" />
        <circle cx={-90} cy={-250} r={84} fill="#FFFFFF" /><circle cx={92} cy={-250} r={84} fill="#EDEAE3" /><circle cx={0} cy={-292} r={100} fill="#FFFFFF" />
      </EnCabeza>
      {/* mostrador */}
      <rect x={-20} y={790} width={1180} height={300} fill={P.madera} />
      <rect x={-20} y={780} width={1200} height={40} fill="#C98468" />
      {[60, 430, 800].map((x) => <rect key={x} x={x} y={860} width={300} height={190} rx={8} fill={P.maderaOsc} />)}
      <ellipse cx={980} cy={772} rx={110} ry={20} fill="#B98A55" />
      <Pan x={950} y={752} w={120} redondo /><Pan x={1010} y={748} w={110} redondo />
      {/* Lajos ofrece el billete y lo baja triste */}
      <Persona2 x={L.x} y={L.y} s={L.s} flip traje="chaleco" pelo="gorra" bigote
        pose={{ bI: (95 - 85 * baja) * ofrece, aI: 10 + 20 * baja, bD: -6, aD: 8, cab: 7 * baja, torso: 3 * baja,
          boca: baja > 0.3 ? "cerrada" : (f < 40 && Math.sin(f * 0.8) > 0 ? "abierta" : "cerrada"), cejas: baja > 0.3 ? -6 * baja : 4 }}
        enManoI={<Billete2 x={0} y={-30} w={230} rot={Math.sin(f / 6) * 4 * (1 - baja) + 90 * baja} />} />
    </Escena>
  );
};
