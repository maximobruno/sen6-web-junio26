// Despiece de Lajos (kit2): armado → se separa en piezas con sus articulaciones → cada pieza gira → se vuelve a armar y saluda.
import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate } from "remotion";
import { Escena, Persona2, P, ease } from "./kit2";
const ETQ: [string, number, number, number][] = [["CABEZA", 1110, 290, 0], ["HOMBRO", 1250, 548, 4], ["CODO", 1250, 726, 8], ["CADERA", 610, 852, 12], ["RODILLA", 610, 930, 16]];
export const Despiece: React.FC = () => {
  const f = useCurrentFrame();
  const k = ease(f, 30, 75) - ease(f, 185, 225);
  const g = interpolate(f, [80, 180], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const w = Math.sin(f / 9) * (f > 80 && f < 185 ? 1 : 0);
  const saludo = f > 225 ? Math.sin((f - 225) / 5) : 0;
  return (
    <AbsoluteFill>
      <Escena fondo={P.lavanda}>
        <rect width={1920} height={1080} fill="#C3C0E0" />
        <rect x={0} y={920} width={1920} height={160} fill="#A9A5CF" />
        <Persona2 x={960} y={900} s={0.62} traje="chaleco" pelo="gorra" bigote despiece={k}
          pose={{ cab: w * 14, bD: -6 + w * 40 + (f > 225 ? 150 + saludo * 15 : 0), aD: 10 + w * 50 + (f > 225 ? 30 : 0), bI: 6 - w * 35, aI: 8 + Math.max(0, w) * 60,
            pI: w * 22, pD: -w * 22, rI: Math.max(0, -w) * 40, rD: Math.max(0, w) * 40, boca: f > 225 ? "sonrisa" : undefined }} habla={f > 80 && f < 185} />
      </Escena>
      {ETQ.map(([t, x, y, dl], i) => { const o = interpolate(f, [80 + dl, 95 + dl, 180, 190], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return <div key={i} style={{ position: "absolute", left: x, top: y, opacity: o, transform: `translateX(${(1 - o) * 20}px)`, background: "#191919", color: "#E8D8BA", fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 30, letterSpacing: "0.14em", padding: "8px 16px" }}>{t}</div>; })}
      <div style={{ position: "absolute", left: 70, top: 60, opacity: g > 0 && f < 190 ? 1 : 0, color: "#191919", fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 28, letterSpacing: "0.14em" }}>CADA PIEZA GIRA SOBRE SU ARTICULACIÓN</div>
    </AbsoluteFill>
  );
};
