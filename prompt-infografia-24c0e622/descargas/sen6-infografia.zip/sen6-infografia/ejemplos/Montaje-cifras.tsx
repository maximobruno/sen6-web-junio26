// Montaje de las versiones con IA (A: Kling directo · B: capas). Clips por plano + cifras en código + voz y música.
import React from "react";
import { AbsoluteFill, Audio, OffthreadVideo, Sequence, staticFile, useCurrentFrame, interpolate } from "remotion";
import { Cifra } from "./kit";
export const F = 30, LEAD = 0.5;
// inicio de cada plano en segundos de la voz
export const INI = [0, 5.0, 9.9, 13.3, 19.1, 22.8, 27.1, 34.2, 38.6, 41.3, 46.8, 52.6, 56.6, 61.2, 66.6, 71.0, 75.6, 80.5, 84.2, 88.4, 94.6, 98.4, 101.9];
const DUR = [5, 5, 3, 6, 5, 5, 7, 5, 3, 5, 6, 4, 5, 6, 4, 5, 5, 4, 4, 6, 4, 4]; // duración real de cada clip
const PLUM = "#903358", TEAL = "#4FB3AD", SLATE = "#5E7676";
export const CIFRAS: { t: number; f: number; texto: string; sub?: string; color?: string; y?: number; tam?: number }[] = [
  { t: 7.0, f: 10.4, texto: "CADA 15 HORAS", sub: "LOS PRECIOS SE DUPLICABAN", color: PLUM },
  { t: 11.4, f: 13.8, texto: "−50 %", sub: "TU SUELDO", color: PLUM },
  { t: 15.8, f: 19.6, texto: "RÉCORD MUNDIAL", sub: "LA PEOR INFLACIÓN DE LA HISTORIA", color: PLUM },
  { t: 19.8, f: 23.3, texto: "JULIO 1946", color: SLATE, tam: 70 },
  { t: 23.6, f: 27.6, texto: "41.900.000.000.000.000 %", sub: "EN UN SOLO MES", color: PLUM, y: 300, tam: 84 },
  { t: 49.2, f: 53.1, texto: "ADÓPENGŐ", sub: "LA MONEDA PARA IMPUESTOS", color: TEAL },
  { t: 53.1, f: 54.8, texto: "ENERO: 1 PENGŐ", color: SLATE, y: 540 },
  { t: 54.8, f: 57.1, texto: "JULIO: 2.000 TRILLONES", color: PLUM, y: 540, tam: 80 },
  { t: 62.4, f: 67.1, texto: "VARIAS VECES POR DÍA", sub: "CAMBIABAN LOS PRECIOS", color: PLUM },
  { t: 77.2, f: 81.0, texto: "100.000.000 B.-PENGŐ", sub: "11 DE JULIO DE 1946", color: TEAL },
  { t: 81.0, f: 84.7, texto: "100.000.000.000.000.000.000", sub: "UN 1 CON 20 CEROS", color: PLUM, tam: 80 },
  { t: 92.0, f: 95.1, texto: "1 FORINT", sub: "LA MONEDA NUEVA", color: TEAL },
  { t: 95.9, f: 98.9, texto: "1 = 4 × 10²⁹", sub: "PENGŐ POR FORINT", color: PLUM },
];
export const totalKling = Math.round((INI[INI.length - 1] + LEAD) * F) + 15;
export const Kling: React.FC<{ carpeta: string; pref: string }> = ({ carpeta, pref }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      {DUR.map((d, i) => {
        const a = i === 0 ? 0 : Math.round((INI[i] + LEAD) * F), b = Math.round((INI[i + 1] + LEAD) * F), slot = b - a;
        const rate = Math.min(1, (d * F) / slot);
        return <Sequence key={i} from={a} durationInFrames={slot}><OffthreadVideo src={staticFile(`${carpeta}/${pref}${String(i + 1).padStart(2, "0")}.mp4`)} muted playbackRate={rate} style={{ width: "100%", height: "100%", objectFit: "cover" }} /></Sequence>;
      })}
      {CIFRAS.map((c, i) => { const a = Math.round((c.t + LEAD) * F), b = Math.round((c.f + LEAD) * F);
        return <Sequence key={"c" + i} from={a} durationInFrames={b - a}><Cifra texto={c.texto} sub={c.sub} at={0} color={c.color} y={c.y ?? 150} tam={c.tam ?? 92} /></Sequence>; })}
      {CIFRAS.map((c, i) => <Sequence key={"p" + i} from={Math.round((c.t + LEAD) * F)}><Audio src={staticFile("pop.mp3")} volume={0.35} /></Sequence>)}
      <Sequence from={Math.round(LEAD * F)}><Audio src={staticFile("voz.wav")} /></Sequence>
      <Audio src={staticFile("musica.mp3")} volume={(fr) => 0.14 * interpolate(fr, [0, 30, totalKling - 90, totalKling], [0, 1, 1, 0], { extrapolateRight: "clamp" })} />
      <AbsoluteFill style={{ background: "#000", opacity: interpolate(f, [totalKling - 15, totalKling], [0, 1], { extrapolateLeft: "clamp" }) }} />
    </AbsoluteFill>
  );
};
