// V04 · Mapa real de Europa central (Natural Earth 50m, fronteras de 1946 agrupadas). Hungría se levanta con la bandera.
import React from "react";
import { useCurrentFrame } from "remotion";
import { Escena, P, ease } from "../kit2";
import { PAISES, HUN_BOX } from "./mapa";
const COL: Record<string, string> = {
  SOV: "#C9BEDA", POL: "#E7D9C7", DEU: "#D7B0A9", CSK: "#B6B4D8", AUT: "#F2E6CF", HUN: "#BAA7BF", ROU: "#B9D5D1", YUG: "#E7D9C7",
  BGR: "#D7B0A9", ALB: "#B6B4D8", GRC: "#F2E6CF", ITA: "#B9D5D1", CHE: "#C9BEDA", FRA: "#E7D9C7", TUR: "#BAA7BF",
};
const otro = ["#E7D9C7", "#C9BEDA", "#B9D5D1", "#D7B0A9", "#F2E6CF", "#B6B4D8"];
export const V04: React.FC<{ d: number }> = ({ d }) => {
  const f = useCurrentFrame();
  const cx = (HUN_BOX.x0 + HUN_BOX.x1) / 2, cy = (HUN_BOX.y0 + HUN_BOX.y1) / 2;
  const s = 0.95 + (1.75 - 0.95) * ease(f, 0, d);
  const lift = ease(f, 30, 60) * 22, glow = ease(f, 35, 70) * (0.75 + 0.25 * Math.sin(f / 7));
  const brillo = ((f - 70) % 70) / 70; // barrido de brillo
  const hun = PAISES.HUN;
  return (
    <Escena fondo="#7FC4BE">
      <defs>
        <clipPath id="hunclip"><path d={hun} /></clipPath>
        <filter id="halo" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="14" /></filter>
      </defs>
      <g transform={`translate(960,600) scale(${s}) translate(${-cx},${-cy})`}>
        <rect x={-500} y={-500} width={3400} height={3200} fill="#7FC4BE" />
        {Object.entries(PAISES).filter(([k]) => k !== "HUN").map(([k, dd], i) => (
          <path key={k} d={dd} fill={COL[k] ?? otro[i % otro.length]} stroke={COL[k] ?? otro[i % otro.length]} strokeWidth={2} strokeLinejoin="round" />
        ))}
        {/* bordes suaves entre países */}
        {Object.entries(PAISES).filter(([k]) => k !== "HUN").map(([k, dd]) => <path key={"b" + k} d={dd} fill="none" stroke="#FFFFFF" strokeOpacity={0.55} strokeWidth={2.2 / s} />)}
        {/* hueco donde estaba Hungría */}
        <path d={hun} fill="#8E7A92" />
        {/* halo */}
        <path d={hun} fill="#FFFFFF" opacity={glow * 0.8} filter="url(#halo)" transform={`translate(0,${-lift})`} />
        {/* sombra + Hungría levantada con la bandera */}
        <path d={hun} fill="#5A4A5E" opacity={0.35 * (lift / 22)} transform={`translate(${lift * 0.4},${lift * 0.35})`} />
        <g transform={`translate(0,${-lift})`}>
          <g clipPath="url(#hunclip)">
            <rect x={HUN_BOX.x0 - 10} y={HUN_BOX.y0 - 10} width={HUN_BOX.x1 - HUN_BOX.x0 + 20} height={(HUN_BOX.y1 - HUN_BOX.y0) / 3 + 10} fill="#CE2939" />
            <rect x={HUN_BOX.x0 - 10} y={HUN_BOX.y0 + (HUN_BOX.y1 - HUN_BOX.y0) / 3} width={HUN_BOX.x1 - HUN_BOX.x0 + 20} height={(HUN_BOX.y1 - HUN_BOX.y0) / 3} fill="#FFFFFF" />
            <rect x={HUN_BOX.x0 - 10} y={HUN_BOX.y0 + 2 * (HUN_BOX.y1 - HUN_BOX.y0) / 3} width={HUN_BOX.x1 - HUN_BOX.x0 + 20} height={(HUN_BOX.y1 - HUN_BOX.y0) / 3 + 10} fill="#477050" />
            {f > 70 && <rect x={HUN_BOX.x0 - 200 + brillo * (HUN_BOX.x1 - HUN_BOX.x0 + 400)} y={HUN_BOX.y0 - 50} width={60} height={HUN_BOX.y1 - HUN_BOX.y0 + 100} fill="#FFFFFF" opacity={0.35} transform={`skewX(-20)`} />}
          </g>
        </g>
      </g>
    </Escena>
  );
};
