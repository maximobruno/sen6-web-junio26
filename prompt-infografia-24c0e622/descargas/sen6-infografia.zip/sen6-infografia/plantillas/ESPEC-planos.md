# Especificación · réplica v2 100 % en código (estilo "tosco" del canal de infografía)

Proyecto: `~/Desktop/PROYECTOS/clase-infografia/replica/ed` (Remotion 4, 1920×1080, 30 fps). Solo creás tus archivos `src/v2/Vxx.tsx`. NO toques `src/kit2.tsx`, `src/Root.tsx`, `src/Kling.tsx` ni escenas de otros números.

## Mirá antes de empezar (con Read)
- Estilo real del canal: `/Users/mac/Downloads/Capturas/Captura de pantalla 2026-11-11 a la(s) 15.42.11.png` (periodista) y `/Users/mac/Downloads/Capturas/Captura de pantalla 2026-11-11 a la(s) 15.01.49.png` (living con tele).
- Lo que ya está aprobado con el kit: `ed/out/prueba2.png` y `ed/out/corre2.mp4` (sacá 3 cuadros con ffmpeg) y su código `src/Corre2.tsx` (ejemplo completo de escena con parallax y personaje animado).
- La imagen de referencia de cada plano (composición/idea, NO hay que copiarla en detalle): `~/Desktop/PROYECTOS/clase-infografia/kling/img/pNN.png`.
- El kit: `src/kit2.tsx` (leelo entero).

## Estilo (regla dura)
- SIN contornos. Cada forma en color plano + una sombra = la misma forma o franja más oscura. Formas "toscas": rectángulos redondeados, círculos, manchas. Manos = círculos. Ojos = rayitas. Fondos simples y planos (paredes con un panel más claro/oscuro, ventanas marco marrón + vidrio azul, pisos de un color, edificios rectangulares con ventanas).
- Paleta del canal (en `P`): lavanda, malva, ciruela, menta, teal, crema, madera, más pared/marco/vidrio/piel del kit. Billetes = `Billete2` (menta).
- Movimiento como After Effects cut-out: piezas rígidas que giran sobre su articulación (hombro, codo, cadera, rodilla, cabeza), parpadeo, boca que habla; cámara con zoom in/out o paneo suave (`Cam`) y parallax entre capas (fondo lento, personaje/primer plano más rápido). Nada de deformaciones. Siempre algo se mueve.
- NO escribas cifras ni textos grandes: las cifras ya van en una capa aparte por encima (arriba al centro, y≈80–260). Dejá libre esa franja superior cuando la escena tenga cifra (ver tabla). Carteles chicos sin texto o con texto mínimo (p. ej. "PANADERÍA") están OK.

## Personajes (siempre los mismos)
- **Lajos**: `<Persona2 traje="chaleco" pelo="gorra" bigote .../>` (gorra plana gris, chaleco marrón, camisa celeste, bigote).
- **Funcionario**: `<Persona2 traje="saco" pelo="pelado" corbata .../>` + anteojos redondos (dibujalos: dos círculos sin relleno con trazo `#2E2A2A` de 8 px sobre los ojos; es el único "contorno" permitido porque son anteojos).
- **Panadero**: saco = delantal blanco (podés pasar `traje="chaleco"` y dibujar encima un delantal blanco) + gorro de panadero blanco + bigote grande.
- **Barrendero**: overol teal (dibujá encima), gorra.
- **Chico de hoy (plano 1)**: buzo teal con capucha (dibujala), pelo `rulos`.
- Escala típica: plano medio s≈0.9–1.1 con los pies fuera de cuadro (y > 1080); plano general s≈0.5–0.7.

## Contrato
```tsx
import React from "react";
import { useCurrentFrame } from "remotion";
import { Escena, Cam, Persona2, Billete2, Ventana, P, ease } from "../kit2";
export const V07: React.FC<{ d: number }> = ({ d }) => { ... }
```
`d` = duración en frames (ver tabla). Usá `useCurrentFrame()` y `ease()`.

## Verificación obligatoria
Agregá tu escena al registro: NO toques Root; en cambio corré los stills con la composición genérica `V2` así:
`npx remotion still src/index.ts V2 out/Vxx_<f>.png --frame=<f> --props='{"id":"Vxx"}' --log=error` (desde `ed`). Mirá 3 cuadros por escena (inicio, medio, final) con Read y corregí: nada cortado por error, personaje completo y reconocible, franja superior libre si hay cifra, que se lea de un vistazo. `npx tsc --noEmit -p .` sin errores en tus archivos.

## Planos (texto de la voz y qué se ve; d en frames)
| # | d | Voz | Qué se ve | Cámara | Cifra arriba |
|---|---|---|---|---|---|
| V01 | 165 | Si creés que la inflación es que el café te cueste un poco más cada mes, todavía no viste nada. | Café moderno: mostrador madera, cafetera, pizarrón negro con precio chico; chico de hoy con vaso en una mano, la otra se abre y se encoge de hombros al final | zoom in lento | — |
| V02 | 147 | En 1946 hubo un país donde los precios se duplicaban cada quince horas. | Vidriera de almacén 1946 con etiquetas que se dan vuelta, reloj grande con agujas girando rápido; Lajos mirando preocupado, gira la cabeza | fija con leve zoom | sí |
| V03 | 102 | Mientras dormías, tu sueldo perdía la mitad de su valor. | Noche: Lajos acostado durmiendo (rotalo 90°), frazada que respira, mesa de luz con billetera que se achica a la mitad | zoom in | sí |
| V04 | 174 | Ese país fue Hungría, y lo que pasó ahí sigue siendo la peor inflación jamás registrada. | Mapa simple de bloques pastel (Europa central), Hungría con franjas rojo-blanco-verde que se levanta y brilla | push-in | sí |
| V05 | 111 | Para que te des una idea: en julio de 1946... | Lajos en la mesa de cocina lee el diario, se sorprende (boca grito, cejas arriba), taza de té | zoom in | sí (chica) |
| V06 | 129 | ...la inflación de un solo mes fue de cuarenta y un mil novecientos billones por ciento. | Plaza con edificios, cartel gigante en blanco sobre patas; Lajos chiquito abajo mirando hacia arriba con la boca abierta | tilt up (de abajo hacia el cartel) | sí, sobre el cartel |
| V07 | 213 | ¿Cómo se llega ahí? La Segunda Guerra Mundial había dejado al país en ruinas: fábricas, puentes y vías destruidos. | Ciudad en ruinas junto a un río: fábricas con chimeneas rotas, puente caído al agua, vías torcidas, humo gris que sube (círculos que crecen y se desvanecen) | paneo a la derecha con parallax | — |
| V08 | 132 | No había casi nada para vender, y el gobierno tenía cuentas enormes para pagar. | Almacén con estantes vacíos y una lata; el funcionario sostiene una pila de papeles altísima que se tambalea | fija | — |
| V09 | 81 | Así que hizo lo más fácil: imprimir dinero. | Imprenta con rodillos que giran y billetes que salen volando y se apilan; funcionario aprieta botón rojo | push-in | — |
| V10 | 165 | Cuanto más imprimía, menos valía cada billete. Y cuanto menos valía, más tenía que imprimir. | Balanza dorada: pila de billetes que crece de un lado, un pan del otro, equilibrada | fija | — |
| V11 | 174 | Para cobrar impuestos, el gobierno inventó una segunda moneda, el adópengő, que se ajustaba todos los días. | Ventanilla de impuestos; funcionario muestra dos billetes (menta y celeste), Lajos se rasca la cabeza | zoom in | sí |
| V12 | 120 | En enero valía un pengő. En julio, dos mil trillones. | Calendario de pared con hojas que se arrancan y vuelan rápido | fija | sí, al centro (y≈540): dejá el centro despejado |
| V13 | 138 | La gente cobraba el sueldo y salía corriendo a gastarlo antes de que se derritiera. | **Ya existe: usá `src/Corre2.tsx` como base** (Lajos corriendo con la bolsa, parallax) adaptado a d | travelling | — |
| V14 | 162 | Los precios de los negocios cambiaban varias veces por día, y los billetes viejos terminaban en el piso. | Vidriera con toldo a rayas magenta/crema, tendero en un banquito cambiando etiquetas, billetes en la vereda | fija | sí |
| V15 | 132 | Hay fotos de barrenderos juntándolos de la calle, como si fueran hojas secas. | Barrendero barriendo una pila de billetes, árbol pelado con hojas naranjas que caen, billetes que vuelan | paneo izquierda | — |
| V16 | 138 | Los billetes empezaron a tener tantos ceros que ya no entraban en el papel. | Lajos sostiene un billete larguísimo que se estira y sale de cuadro | zoom out | — |
| V17 | 147 | El once de julio salió el billete más grande de la historia: cien millones de b-pengő. | Billete gigante parado como una pared con medallón y retrato simple; Lajos chiquito al lado mirando arriba | zoom out | sí |
| V18 | 111 | Cien trillones de pengő. Un uno con veinte ceros. | Primer plano del billete gigante (medallón con retrato simple, guardas), mano de Lajos que lo toca | zoom in | sí |
| V19 | 126 | Y con ese billete, a las pocas semanas, no te alcanzaba ni para el pan. | Panadería: panadero detrás del mostrador niega con la cabeza y el dedo; Lajos ofrece el billete y baja el brazo triste; panes en estantes | fija | — |
| V20 | 186 | El primero de agosto, Hungría tiró todo a la basura y empezó de cero con una moneda nueva: el forint. | Funcionario tira fajos al tacho de basura; aparece una moneda dorada grande con rayos que sube con rebote; él sonríe | push-in | sí |
| V21 | 114 | ¿El cambio? Un forint por cuatrocientos mil cuatrillones de pengő. | Balanza enorme: monedita dorada de un lado y una montaña de billetes que sale de cuadro del otro, equilibrada | tilt up | sí |
| V22 | 105 | Y lo más increíble es lo que pasó después. | Lajos de frente mirando a cámara, levanta una ceja y sonríe de costado; fondo lavanda liso | zoom in lento; fundido a negro los últimos 15 frames | — |
