# Genera mapa.ts (trazados SVG de países reales) para escenas de mapa en Remotion.
# Datos: Natural Earth 50m (dominio público). Uso:
#   uv run --with shapely python mapa_generar.py --lon 2 38 --lat 36 57.5 --agrupar "CZE,SVK=CSK" "SVN,HRV,BIH,SRB,MNE,MKD,KOS=YUG" --salida src/mapa.ts
# --agrupar une países con fronteras históricas (ej. Checoslovaquia, Yugoslavia, URSS) para que no se vean las fronteras de hoy.
import argparse, json, math, os, urllib.request
from shapely.geometry import shape, Polygon, box
from shapely.ops import unary_union

URL = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson"
ap = argparse.ArgumentParser()
ap.add_argument("--lon", nargs=2, type=float, required=True)
ap.add_argument("--lat", nargs=2, type=float, required=True)
ap.add_argument("--agrupar", nargs="*", default=[])
ap.add_argument("--ancho", type=int, default=2400)
ap.add_argument("--salida", default="mapa.ts")
a = ap.parse_args()
if not os.path.exists("paises50.geojson"):
    urllib.request.urlretrieve(URL, "paises50.geojson")
d = json.load(open("paises50.geojson"))
G = {}
for g in a.agrupar:
    lista, nombre = g.split("=")
    for c in lista.split(","): G[c.strip()] = nombre.strip()
LON0, LON1 = a.lon; LAT0, LAT1 = a.lat
merc = lambda la: math.log(math.tan(math.pi / 4 + math.radians(la) / 2))
W = a.ancho; k = W / (LON1 - LON0); H = (merc(LAT1) - merc(LAT0)) * math.degrees(1) * k
P = lambda lon, lat: ((lon - LON0) * k, (merc(LAT1) - merc(lat)) * math.degrees(1) * k)
clip = box(LON0 - 6, LAT0 - 6, LON1 + 6, LAT1 + 6)
grp = {}
for f in d["features"]:
    cod = f["properties"].get("ADM0_A3"); geo = shape(f["geometry"]).buffer(0)
    if geo.intersects(clip): grp.setdefault(G.get(cod, cod), []).append(geo.intersection(clip))
def trazo(geo):
    polys = [geo] if isinstance(geo, Polygon) else list(getattr(geo, "geoms", []))
    out = []
    for p in polys:
        if not isinstance(p, Polygon) or p.area < 0.003: continue
        for anillo in [p.exterior] + list(p.interiors):
            out.append("M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in (P(*c) for c in anillo.coords)) + "Z")
    return " ".join(out)
res = {}
for g, lst in grp.items():
    u = unary_union([x.buffer(0.02) for x in lst]).buffer(-0.02) if len(lst) > 1 else lst[0]
    t = trazo(u)
    if t: res[g] = t
cajas = {}
for g, lst in grp.items():
    b = unary_union(lst).bounds; x0, y1 = P(b[0], b[1]); x1, y0 = P(b[2], b[3]); cajas[g] = [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)]
ts = "// Natural Earth 50m (dominio público).\n"
ts += f"export const MAPA_W = {W}, MAPA_H = {round(H)};\n"
ts += "export const CAJAS: Record<string, number[]> = " + json.dumps(cajas) + ";\n"
ts += "export const PAISES: Record<string, string> = " + json.dumps(res) + ";\n"
open(a.salida, "w").write(ts)
print(f"{len(res)} países → {a.salida}")
