#!/usr/bin/env python3
"""Genera la locución con la voz clonada de Max (Qwen3-TTS Base) frase por frase.
Salida: voz/voz.wav (normalizada) y voz/tiempos.json [{p, i, texto, ini, fin}] para sincronizar escenas."""
import json, os, re, subprocess, sys
# Poné tu muestra de voz en voz-referencia/ref.wav (10-15 s) y su texto exacto en voz-referencia/ref.txt
Q = os.environ.get("VOZ_REF_DIR", "voz-referencia"); D = "voz2"
REF_TXT = open(f"{Q}/ref.txt").read().strip()
parrafos = [l.strip() for l in open("guion.txt", encoding="utf-8") if l.strip()]
def frases(p): return [f.strip() for f in re.split(r"(?<=[.?!])\s+", p) if f.strip()]
def dur(f): return float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",f],capture_output=True,text=True).stdout)
lista, tiempos, t = [], [], 0.0
for pi, p in enumerate(parrafos):
    fs = frases(p)
    for fi, fr in enumerate(fs):
        base = f"{D}/p{pi:02d}_{fi:02d}"; out = base + ".wav"
        crudo = f"{D}/crudo_{pi:02d}_{fi:02d}_000.wav"
        if not os.path.exists(crudo):
            subprocess.run([os.path.expanduser("~/.local/bin/mlx_audio.tts.generate"), "--model", "mlx-community/Qwen3-TTS-12Hz-1.7B-Base-8bit",
                "--text", fr, "--ref_audio", f"{Q}/ref.wav", "--ref_text", REF_TXT, "--lang_code", "es",
                "--output_path", D, "--file_prefix", f"crudo_{pi:02d}_{fi:02d}", "--audio_format", "wav"], capture_output=True)
        pausa = 0.6 if fi == len(fs) - 1 else 0.25
        subprocess.run(["ffmpeg","-y","-loglevel","error","-i",f"{D}/crudo_{pi:02d}_{fi:02d}_000.wav","-af",
                "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,atempo=0.9,apad=pad_dur=%s" % pausa,
            "-ar","44100","-ac","1",out], check=True)
        d = dur(out); habla = d - (0.6 if fi == len(fs) - 1 else 0.25)
        tiempos.append({"p": pi, "i": fi, "texto": fr, "ini": round(t, 3), "fin": round(t + habla, 3)}); t += d
        lista.append(f"file '{os.path.basename(out)}'")
        print(f"{pi:02d}.{fi:02d} {t:7.1f}s", flush=True)
open(f"{D}/lista.txt","w").write("\n".join(lista) + "\n")
subprocess.run(["ffmpeg","-y","-loglevel","error","-f","concat","-safe","0","-i",f"{D}/lista.txt","-af","loudnorm=I=-16:TP=-1.5","-ar","44100","-ac","1",f"{D}/voz.wav"], check=True)
json.dump(tiempos, open(f"{D}/tiempos.json","w"), ensure_ascii=False, indent=1)
print("TOTAL", round(t, 1))
