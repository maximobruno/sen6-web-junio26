// Kit v2 · estilo real del canal de infografía (tomado de capturas reales):
// SIN contorno, dos tonos por forma (sombra = misma forma más oscura), manos = círculos (mitón),
// brazos = rectángulos redondeados gruesos, ojos = rayitas, pelo/barba = manchas de círculos, fondos planos.
import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from "remotion";

export const P = {
  pared: "#DCCDB4", paredOsc: "#C2B49C", paredCl: "#E6DAC5", marco: "#6E5551", vidrio: "#2F6A88", vidrioCl: "#3E7C9A",
  piel: "#F5D3B3", pielOsc: "#E8B790", pielSomb: "#DFA986", pelo: "#4A2C22", peloOsc: "#3A2119",
  saco: "#3A4342", sacoCl: "#4A5554", sacoOsc: "#2E3635", camisa: "#BFD8E6", camisaCl: "#DCEBF3", corbata: "#B04A4A",
  chaleco: "#7E4E34", chalecoOsc: "#673E29", gorra: "#7C7A78", gorraOsc: "#666462", pantalon: "#8A8885", pantalonOsc: "#74726F",
  boca: "#8E3A44", dientes: "#FFFFFF", lengua: "#E07A7E", ojo: "#7E4A5A", zapato: "#2E2A2A",
  lavanda: "#B6B4D8", malva: "#BAA7BF", ciruela: "#9C4C6C", menta: "#84E4DF", teal: "#4FB3AD", crema: "#F8F2D9", madera: "#B86E58", maderaOsc: "#9A5946",
  billete: "#A8DCC4", billeteOsc: "#7FC0A6",
};
export const ease = (f: number, a: number, b: number, from = 0, to = 1) =>
  interpolate(f, [a, b], [from, to], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.inOut(Easing.sin) });

// Fondo SVG 1920x1080 con grano sutil (puntitos) como en el canal
export const Escena: React.FC<{ children: React.ReactNode; fondo?: string }> = ({ children, fondo = P.pared }) => (
  <AbsoluteFill style={{ background: fondo }}>
    <svg viewBox="0 0 1920 1080" width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <filter id="grano"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" /><feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.05 0" /></filter>
      </defs>
      {children}
      <rect width="1920" height="1080" filter="url(#grano)" />
    </svg>
  </AbsoluteFill>
);

// Cámara: zoom / paneo suaves (y parallax si se anidan capas con distinta intensidad)
export const Cam: React.FC<{ children: React.ReactNode; z?: [number, number]; x?: [number, number]; y?: [number, number]; dur: number; ox?: number; oy?: number }> =
  ({ children, z = [1, 1.05], x = [0, 0], y = [0, 0], dur, ox = 960, oy = 540 }) => {
    const f = useCurrentFrame(); const k = ease(f, 0, dur);
    const s = z[0] + (z[1] - z[0]) * k, tx = x[0] + (x[1] - x[0]) * k, ty = y[0] + (y[1] - y[0]) * k;
    return <g transform={`translate(${ox + tx},${oy + ty}) scale(${s}) translate(${-ox},${-oy})`}>{children}</g>;
  };

// Ventana del canal: marco marrón, vidrio azul en dos hojas, alféizar crema
export const Ventana: React.FC<{ x: number; y: number; w?: number; h?: number }> = ({ x, y, w = 600, h = 520 }) => (
  <g transform={`translate(${x},${y})`}>
    <rect x={-40} y={-30} width={w + 80} height={h + 60} fill={P.paredCl} />
    <rect x={0} y={0} width={w} height={h} fill={P.marco} />
    <rect x={w * 0.11} y={h * 0.0} width={w * 0.33} height={h * 0.86} fill={P.vidrio} />
    <rect x={w * 0.56} y={h * 0.0} width={w * 0.33} height={h * 0.86} fill={P.vidrio} />
    <rect x={-40} y={h + 30} width={w + 80} height={38} fill={P.paredOsc} />
  </g>
);

// Forma con sombra: dibuja la forma y encima una franja más oscura del lado derecho (cel shading)
const Sombreado: React.FC<{ d: string; base: string; somb: string; clipId: string; lado?: "der" | "izq"; ancho?: number }> = ({ d, base, somb, clipId, lado = "der", ancho = 0.35 }) => (
  <g>
    <defs><clipPath id={clipId}><path d={d} /></clipPath></defs>
    <path d={d} fill={base} />
    <g clipPath={`url(#${clipId})`}>
      <rect x={lado === "der" ? 1000 * (1 - ancho) - 500 : -500} y={-2000} width={1000 * ancho} height={4000} fill={somb} transform="skewX(-8)" />
    </g>
  </g>
);

export type Pose2 = {
  bI?: number; bD?: number; aI?: number; aD?: number; // hombro / codo en grados (0 = colgando)
  pI?: number; pD?: number; rI?: number; rD?: number; // cadera / rodilla
  cab?: number; boca?: "cerrada" | "abierta" | "grito" | "sonrisa" | "o"; ojos?: "rayita" | "cerrados" | "abiertos"; cejas?: number;
  torso?: number;
};
let uid = 0;
// Personaje estilo canal. Origen = pies (y), centro (x). Altura ~ 760 px a s=1 (cabeza grande, cuerpo robusto).
export const Persona2: React.FC<{
  x: number; y: number; s?: number; flip?: boolean; pose?: Pose2; habla?: boolean; parpadea?: boolean;
  traje?: "saco" | "chaleco"; pelo?: "rulos" | "gorra" | "pelado"; barba?: boolean; bigote?: boolean; corbata?: boolean;
  piel?: string; pielOsc?: string; enMano?: React.ReactNode; enManoI?: React.ReactNode; sinPiernas?: boolean; despiece?: number;
}> = ({ x, y, s = 1, flip, pose = {}, habla, parpadea = true, traje = "saco", pelo = "rulos", barba, bigote, corbata, piel = P.piel, pielOsc = P.pielOsc, enMano, enManoI, sinPiernas, despiece = 0 }) => {
  const k = despiece; const J = (cx: number, cy: number) => (k > 0 ? <circle cx={cx} cy={cy} r={20} fill="#D06224" opacity={Math.min(1, k * 1.5)} /> : null);
  const f = useCurrentFrame();
  const id = React.useMemo(() => `p${uid++}`, []);
  const tela = traje === "saco" ? P.saco : P.chaleco, telaCl = traje === "saco" ? P.sacoCl : P.chaleco, telaOsc = traje === "saco" ? P.sacoOsc : P.chalecoOsc;
  const manga = traje === "saco" ? P.saco : P.camisaCl, mangaOsc = traje === "saco" ? P.sacoOsc : P.camisa;
  const resp = Math.sin(f / 22) * 3;
  const boca = pose.boca ?? (habla ? ((Math.sin(f * 0.8) + Math.sin(f * 1.9)) > 0.1 ? "abierta" : "cerrada") : "cerrada");
  const cerr = parpadea && (f % 110) < 4;
  const Brazo = ({ hombro, codo, lado, item }: { hombro: number; codo: number; lado: 1 | -1; item?: React.ReactNode }) => (
    <g transform={`translate(${lado * 150 + lado * 230 * k},${-470 - 40 * k}) rotate(${-hombro * lado})`}>
      <rect x={-46} y={-30} width={92} height={210} rx={46} fill={manga} />
      <rect x={lado === 1 ? 10 : -46} y={-30} width={36} height={210} rx={18} fill={mangaOsc} opacity={0.55} />
      <g transform={`translate(0,${170 + 110 * k}) rotate(${-codo * lado})`}>
        <rect x={-44} y={-30} width={88} height={190} rx={44} fill={manga} />
        <circle cx={0} cy={190} r={62} fill={piel} />
        <circle cx={lado * 14} cy={196} r={46} fill={pielOsc} opacity={0.35} />
        {item ? <g transform={`translate(0,190) rotate(${(hombro + codo) * lado})`}>{item}</g> : null}
        {J(0, 0)}
      </g>
      {J(0, 0)}
    </g>
  );
  const Pierna = ({ cad, rod, lado }: { cad: number; rod: number; lado: 1 | -1 }) => (
    <g transform={`translate(${lado * 62 + lado * 90 * k},${-170 + 150 * k}) rotate(${cad})`}>
      <rect x={-46} y={-20} width={92} height={110} rx={40} fill={P.pantalon} />
      <g transform={`translate(0,${82 + 90 * k}) rotate(${rod})`}>
        <rect x={-42} y={-12} width={84} height={100} rx={36} fill={P.pantalonOsc} />
        <path d="M-48,82 Q-50,60 -20,60 L52,62 Q86,66 86,90 L86,98 L-48,98 Z" fill={P.zapato} />
        {J(0, 0)}
      </g>
      {J(0, 0)}
    </g>
  );
  return (
    <g transform={`translate(${x},${y}) scale(${flip ? -s : s},${s})`}>
      {!sinPiernas && <><Pierna cad={pose.pI ?? 0} rod={pose.rI ?? 0} lado={-1} /><Pierna cad={pose.pD ?? 0} rod={pose.rD ?? 0} lado={1} /></>}
      <g transform={`translate(0,${resp}) rotate(${pose.torso ?? 0} 0 -200)`}>
        <Brazo hombro={pose.bI ?? 6} codo={pose.aI ?? 8} lado={1} item={enManoI} />
        {/* torso robusto con hombros redondeados */}
        <Sombreado clipId={id + "t"} d="M-190,-160 L-190,-430 Q-190,-520 -110,-530 L110,-530 Q190,-520 190,-430 L190,-160 Z" base={tela} somb={telaOsc} />
        {/* camisa en V + solapas */}
        <path d="M-70,-530 L0,-400 L70,-530 Z" fill={P.camisa} />
        <path d="M-58,-530 L0,-420 L58,-530 Z" fill={P.camisaCl} />
        {corbata && <path d="M0,-470 L-22,-436 L0,-300 L22,-436 Z" fill={P.corbata} />}
        <path d="M-110,-530 L-40,-390 L-70,-370 L-130,-470 Z" fill={telaCl} opacity={0.6} />
        <path d="M110,-530 L40,-390 L70,-370 L130,-470 Z" fill={telaOsc} opacity={0.8} />
        {/* cuello */}
        <rect x={-58} y={-600} width={116} height={90} fill={pielOsc} />
        {/* cabeza: rectángulo alto con mentón redondeado */}
        <g transform={`translate(0,${-700 - 230 * k}) rotate(${pose.cab ?? 0} 0 80)`}>
          <path d="M-140,-150 L140,-150 L132,60 Q130,150 0,150 Q-130,150 -132,60 Z" fill={piel} />
          <path d="M70,-150 L140,-150 L132,60 Q130,150 60,150 Z" fill={pielOsc} opacity={0.35} />
          <ellipse cx={-145} cy={-10} rx={26} ry={42} fill={pielOsc} />
          {/* ojos rayita */}
          {(() => { const o = pose.ojos ?? "rayita"; const c = cerr || o === "cerrados";
            if (o === "abiertos" && !c) return <g fill={P.ojo}><ellipse cx={-62} cy={-20} rx={10} ry={14} /><ellipse cx={62} cy={-20} rx={10} ry={14} /></g>;
            return <g fill={P.ojo}><rect x={-80} y={c ? -18 : -24} width={34} height={c ? 5 : 9} rx={4} /><rect x={48} y={c ? -18 : -24} width={34} height={c ? 5 : 9} rx={4} /></g>; })()}
          {pose.cejas ? <g fill={P.peloOsc}><rect x={-86} y={-58 - pose.cejas} width={46} height={10} rx={5} /><rect x={42} y={-58 - pose.cejas} width={46} height={10} rx={5} /></g> : null}
          {/* barba / bigote */}
          {barba && <ellipse cx={0} cy={98} rx={118} ry={98} fill={P.pelo} />}
          {bigote && <path d="M-70,62 Q0,30 70,62 Q36,80 0,70 Q-36,80 -70,62 Z" fill={P.pelo} />}
          {/* boca */}
          {boca === "abierta" && <g><ellipse cx={0} cy={100} rx={40} ry={34} fill={P.boca} /><ellipse cx={0} cy={80} rx={30} ry={9} fill={P.dientes} /><ellipse cx={0} cy={118} rx={24} ry={10} fill={P.lengua} /></g>}
          {boca === "grito" && <g><ellipse cx={0} cy={104} rx={50} ry={46} fill={P.boca} /><ellipse cx={0} cy={74} rx={38} ry={10} fill={P.dientes} /><ellipse cx={0} cy={128} rx={30} ry={13} fill={P.lengua} /></g>}
          {boca === "o" && <ellipse cx={0} cy={100} rx={22} ry={28} fill={P.boca} />}
          {boca === "sonrisa" && <path d="M-46,86 Q0,136 46,86 Z" fill={P.boca} />}
          {boca === "cerrada" && <rect x={-34} y={94} width={68} height={10} rx={5} fill={P.boca} />}
          {/* pelo */}
          {pelo === "rulos" && <g><circle cx={-110} cy={-150} r={62} fill={P.peloOsc} /><circle cx={-40} cy={-190} r={80} fill={P.pelo} /><circle cx={60} cy={-196} r={70} fill={P.peloOsc} /><circle cx={130} cy={-140} r={52} fill={P.pelo} /><rect x={-150} y={-170} width={300} height={70} rx={30} fill={P.pelo} /><rect x={-150} y={-120} width={40} height={90} rx={18} fill={P.peloOsc} /></g>}
          {pelo === "gorra" && <g><rect x={-148} y={-150} width={296} height={46} fill={P.pelo} /><path d="M-172,-112 Q-168,-236 6,-240 Q178,-232 176,-118 Z" fill={P.gorra} /><path d="M60,-236 Q178,-228 176,-118 L80,-118 Z" fill={P.gorraOsc} /><path d="M-150,-122 Q0,-96 160,-124 L164,-102 Q0,-66 -152,-100 Z" fill={P.gorraOsc} /></g>}
        </g>
        <Brazo hombro={pose.bD ?? -6} codo={pose.aD ?? 8} lado={-1} item={enMano} />
      </g>
    </g>
  );
};

export const Microfono: React.FC = () => (
  <g transform="translate(0,-30)">
    <rect x={-22} y={0} width={44} height={150} rx={10} fill="#2F3540" />
    <rect x={-48} y={-50} width={96} height={64} rx={12} fill="#D9DEE3" /><circle cx={0} cy={-18} r={13} fill={P.teal} />
    <path d="M-44,-60 Q-44,-150 0,-150 Q44,-150 44,-60 Z" fill="#93A3AE" /><rect x={-48} y={-66} width={96} height={14} rx={6} fill="#C9D3DA" />
  </g>
);

export const Billete2: React.FC<{ x: number; y: number; w?: number; rot?: number }> = ({ x, y, w = 260, rot = 0 }) => (
  <g transform={`translate(${x},${y}) rotate(${rot})`}>
    <rect x={-w / 2} y={-w * 0.23} width={w} height={w * 0.46} rx={10} fill={P.billete} />
    <rect x={-w / 2 + 14} y={-w * 0.23 + 14} width={w - 28} height={w * 0.46 - 28} rx={6} fill="none" stroke={P.billeteOsc} strokeWidth={6} />
    <circle cx={0} cy={0} r={w * 0.13} fill={P.billeteOsc} />
  </g>
);
