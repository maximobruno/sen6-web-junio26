// Kit de la réplica estilo "infografía animada": vector plano, contorno negro, personajes simples. TODO en código (SVG).
import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { loadFont } from "@remotion/google-fonts/Montserrat";
export const { fontFamily: MONT } = loadFont("normal", { weights: ["700", "800", "900"] });

export const C = {
  linea: "#1E1B1A",
  teal: "#9FD9D3", tealOsc: "#6FBFB7", lila: "#B8A6DE", rosa: "#F6C1CF", crema: "#F4E9D2", cielo: "#BFE3F2", arena: "#EAD7A8",
  piel1: "#F2C6A0", piel2: "#D9A074", piel3: "#A86D47",
  rojo: "#D63A3A", verde: "#3E9A57", blanco: "#FFFFFF", gris: "#8E8E93", grisCl: "#D9D9DE",
  billete: "#B9D8A6", billeteOsc: "#7FAE6A", oro: "#F2B33D", azul: "#3C6FB6", marron: "#8A5A3B", humo: "#9A9AA2",
};
export const LW = 6; // grosor de contorno base

// ---------- utilidades de tiempo ----------
export const useT = () => useCurrentFrame();
export const ease = (f: number, a: number, b: number, from = 0, to = 1, e = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [from, to], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: e });
export const pop = (f: number, at: number, fps = 30) => spring({ frame: f - at, fps, config: { damping: 11, stiffness: 160, mass: 0.7 } });

// ---------- cámara: paneo/zoom sobre la escena ----------
export const Camara: React.FC<{ children: React.ReactNode; desde?: [number, number, number]; hasta?: [number, number, number]; dur: number; temblor?: number }> =
  ({ children, desde = [0, 0, 1], hasta = [0, 0, 1.06], dur, temblor = 0 }) => {
    const f = useCurrentFrame();
    const k = ease(f, 0, dur, 0, 1, Easing.inOut(Easing.sin));
    const x = desde[0] + (hasta[0] - desde[0]) * k, y = desde[1] + (hasta[1] - desde[1]) * k, s = desde[2] + (hasta[2] - desde[2]) * k;
    const tx = temblor ? Math.sin(f * 1.7) * temblor : 0, ty = temblor ? Math.cos(f * 2.3) * temblor : 0;
    return <AbsoluteFill style={{ transform: `translate(${-x + tx}px, ${-y + ty}px) scale(${s})`, transformOrigin: "50% 50%" }}>{children}</AbsoluteFill>;
  };

// Lienzo SVG 1920x1080
export const Lienzo: React.FC<{ fondo?: string; children: React.ReactNode }> = ({ fondo = C.teal, children }) => (
  <AbsoluteFill style={{ background: fondo }}>
    <svg viewBox="0 0 1920 1080" width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>{children}</svg>
  </AbsoluteFill>
);

// Piso simple
export const Piso: React.FC<{ y?: number; color?: string }> = ({ y = 860, color = C.tealOsc }) => (
  <rect x={-200} y={y} width={2320} height={600} fill={color} />
);

// ---------- PERSONAJE ----------
export type Pose = {
  bI?: number; bD?: number;          // ángulo brazo izq / der (grados, 0 = colgando, + hacia adelante/arriba)
  aI?: number; aD?: number;          // codo (antebrazo relativo)
  pI?: number; pD?: number;          // piernas
  cab?: number;                       // inclinación de cabeza
  boca?: "cerrada" | "abierta" | "sonrisa" | "triste" | "o" | "grito";
  ojos?: "punto" | "cerrados" | "grandes" | "enojo" | "triste";
  cejas?: "normal" | "arriba" | "enojo" | "triste";
  sudor?: boolean;
};
export const Persona: React.FC<{
  x: number; y: number; s?: number; flip?: boolean; pose?: Pose; piel?: string; remera?: string; pantalon?: string; pelo?: string;
  peinado?: "corto" | "calvo" | "largo" | "gorra"; habla?: boolean; camina?: number; frame?: number; bigote?: boolean; corbata?: string; delantal?: string;
  enMano?: React.ReactNode; // se dibuja en la mano derecha (coords locales de la mano)
}> = ({ x, y, s = 1, flip, pose = {}, piel = C.piel1, remera = C.azul, pantalon = "#3A3F55", pelo = "#3B2A20", peinado = "corto", habla, camina = 0, frame, bigote, corbata, delantal, enMano }) => {
  const cf = useCurrentFrame(); const fr = frame ?? cf;
  const ph = camina ? fr * 0.32 * camina : 0;
  const sw = camina ? Math.sin(ph) : 0;
  const bob = camina ? Math.abs(Math.cos(ph)) * -10 : Math.sin(fr / 18) * 2; // respiración
  const pI = (pose.pI ?? 0) + sw * 28, pD = (pose.pD ?? 0) - sw * 28;
  const bI = (pose.bI ?? 8) - sw * 30, bD = (pose.bD ?? -8) + sw * 30;
  const blink = (fr % 97) < 4 && (pose.ojos ?? "punto") === "punto";
  const bocaAb = habla ? (Math.sin(fr * 0.9) + Math.sin(fr * 1.7)) > 0.2 : false;
  const boca = pose.boca ?? (bocaAb ? "abierta" : "cerrada");
  const st = { stroke: C.linea, strokeWidth: LW, strokeLinejoin: "round" as const, strokeLinecap: "round" as const };
  const Brazo = ({ ang, codo, lado }: { ang: number; codo: number; lado: 1 | -1 }) => (
    <g transform={`translate(${lado * 50},-272) rotate(${-ang * lado})`}>
      <rect x={-13} y={-6} width={26} height={62} rx={13} fill={remera} {...st} />
      <g transform={`translate(0,52) rotate(${-codo * lado})`}>
        <rect x={-12} y={-6} width={24} height={56} rx={12} fill={piel} {...st} />
        <circle cx={0} cy={56} r={15} fill={piel} {...st} />
        {lado === -1 && enMano ? <g transform={`translate(0,58) rotate(${(ang + codo) * lado})`}>{enMano}</g> : null}
      </g>
    </g>
  );
  const Pierna = ({ ang, lado }: { ang: number; lado: 1 | -1 }) => (
    <g transform={`translate(${lado * 22},-150) rotate(${ang})`}>
      <rect x={-16} y={-4} width={32} height={140} rx={14} fill={pantalon} {...st} />
      <ellipse cx={lado * 8 + 6} cy={142} rx={26} ry={13} fill={C.linea} />
    </g>
  );
  return (
    <g transform={`translate(${x},${y + bob * s}) scale(${flip ? -s : s},${s})`}>
      <Pierna ang={pI} lado={1} />
      <Pierna ang={pD} lado={-1} />
      <Brazo ang={bI} codo={pose.aI ?? 10} lado={1} />
      {/* torso */}
      <path d="M-52,-290 Q-58,-160 -46,-145 L46,-145 Q58,-160 52,-290 Q0,-302 -52,-290 Z" fill={remera} {...st} />
      {delantal ? <path d="M-34,-250 L34,-250 L38,-148 L-38,-148 Z" fill={delantal} {...st} /> : null}
      {corbata ? <path d="M0,-288 L-11,-272 L0,-200 L11,-272 Z" fill={corbata} {...st} /> : null}
      {/* cabeza */}
      <g transform={`translate(0,-350) rotate(${pose.cab ?? 0})`}>
        <rect x={-14} y={44} width={28} height={20} fill={piel} stroke={C.linea} strokeWidth={LW} />
        <ellipse cx={0} cy={0} rx={56} ry={62} fill={piel} {...st} />
        {peinado === "corto" && <path d="M-56,-6 Q-60,-70 0,-66 Q58,-70 56,-8 Q40,-40 0,-38 Q-36,-42 -56,-6 Z" fill={pelo} {...st} />}
        {peinado === "largo" && <path d="M-58,30 Q-66,-74 0,-68 Q66,-74 58,30 L46,32 Q46,-34 0,-36 Q-46,-34 -46,32 Z" fill={pelo} {...st} />}
        {peinado === "gorra" && <g><path d="M-58,-14 Q-56,-76 0,-72 Q56,-76 58,-14 Z" fill={C.rojo} {...st} /><path d="M20,-18 L92,-12 Q90,0 56,-4 Z" fill={C.rojo} {...st} /></g>}
        {/* ojos */}
        {(() => {
          const o = pose.ojos ?? "punto";
          if (o === "cerrados" || blink) return <g {...st} fill="none"><path d="M-30,-2 Q-21,4 -12,-2" /><path d="M12,-2 Q21,4 30,-2" /></g>;
          const r = o === "grandes" ? 10 : 7;
          return <g fill={C.linea}>{o === "grandes" && <><circle cx={-21} cy={-4} r={16} fill="#fff" {...st} /><circle cx={21} cy={-4} r={16} fill="#fff" {...st} /></>}
            <circle cx={-21} cy={-4} r={r} /><circle cx={21} cy={-4} r={r} /></g>;
        })()}
        {/* cejas */}
        {(() => {
          const c = pose.cejas ?? "normal";
          const d = c === "arriba" ? -14 : 0;
          if (c === "enojo") return <g {...st}><path d="M-34,-26 L-10,-18" /><path d="M34,-26 L10,-18" /></g>;
          if (c === "triste") return <g {...st}><path d="M-34,-18 L-10,-26" /><path d="M34,-18 L10,-26" /></g>;
          return <g {...st}><path d={`M-33,${-22 + d} L-11,${-24 + d}`} /><path d={`M11,${-24 + d} L33,${-22 + d}`} /></g>;
        })()}
        {bigote && <path d="M-22,20 Q0,10 22,20 Q0,28 -22,20 Z" fill={pelo} {...st} />}
        {/* boca */}
        {boca === "cerrada" && <path d="M-14,30 L14,30" {...st} fill="none" />}
        {boca === "sonrisa" && <path d="M-18,24 Q0,42 18,24" {...st} fill="none" />}
        {boca === "triste" && <path d="M-16,36 Q0,22 16,36" {...st} fill="none" />}
        {boca === "abierta" && <ellipse cx={0} cy={30} rx={13} ry={9} fill="#7A2E2E" {...st} />}
        {boca === "o" && <ellipse cx={0} cy={32} rx={9} ry={12} fill="#7A2E2E" {...st} />}
        {boca === "grito" && <path d="M-20,22 Q0,16 20,22 Q22,50 0,52 Q-22,50 -20,22 Z" fill="#7A2E2E" {...st} />}
        {pose.sudor && <path d="M60,-30 Q70,-12 62,-4 Q52,-12 60,-30 Z" fill="#8FD3FF" {...st} />}
      </g>
      <Brazo ang={bD} codo={pose.aD ?? 10} lado={-1} />
    </g>
  );
};

// ---------- OBJETOS ----------
export const Billete: React.FC<{ x: number; y: number; w?: number; h?: number; rot?: number; texto?: string; color?: string; s?: number }> =
  ({ x, y, w = 260, h = 120, rot = 0, texto = "PENGŐ", color = C.billete, s = 1 }) => (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={10} fill={color} stroke={C.linea} strokeWidth={LW} />
      <rect x={-w / 2 + 14} y={-h / 2 + 14} width={w - 28} height={h - 28} rx={6} fill="none" stroke={C.billeteOsc} strokeWidth={4} />
      <circle cx={-w / 2 + 52} cy={0} r={h * 0.26} fill={C.billeteOsc} stroke={C.linea} strokeWidth={4} />
      <text x={w * 0.12} y={10} textAnchor="middle" fontFamily={MONT} fontWeight={900} fontSize={h * 0.24} fill={C.linea}>{texto}</text>
    </g>
  );

export const Taza: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-30,-40 L30,-40 L24,20 Q0,30 -24,20 Z" fill="#fff" stroke={C.linea} strokeWidth={LW} strokeLinejoin="round" />
    <path d="M28,-26 Q52,-24 48,-4 Q44,10 24,6" fill="none" stroke={C.linea} strokeWidth={LW} />
    <ellipse cx={0} cy={-40} rx={30} ry={8} fill={C.marron} stroke={C.linea} strokeWidth={4} />
  </g>
);

export const Etiqueta: React.FC<{ x: number; y: number; texto: string; s?: number; rot?: number; color?: string }> = ({ x, y, texto, s = 1, rot = -8, color = C.oro }) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
    <path d="M-80,-38 L60,-38 L92,0 L60,38 L-80,38 Z" fill={color} stroke={C.linea} strokeWidth={LW} strokeLinejoin="round" />
    <circle cx={62} cy={0} r={8} fill="#fff" stroke={C.linea} strokeWidth={4} />
    <text x={-12} y={14} textAnchor="middle" fontFamily={MONT} fontWeight={900} fontSize={40} fill={C.linea}>{texto}</text>
  </g>
);

// ---------- TARJETA DE CIFRA (estilo del canal: bloque de color + texto blanco con sombra dura) ----------
export const Cifra: React.FC<{ texto: string; sub?: string; at?: number; x?: number; y?: number; tam?: number; color?: string }> =
  ({ texto, sub, at = 0, x = 960, y = 170, tam = 92, color = C.rojo }) => {
    const f = useCurrentFrame(); const p = pop(f, at);
    if (f < at) return null;
    return (
      <div style={{ position: "absolute", left: x, top: y, transform: `translate(-50%,-50%) scale(${0.6 + 0.4 * p}) rotate(${(1 - p) * -6}deg)`, opacity: Math.min(1, p * 1.5), textAlign: "center" }}>
        <div style={{ display: "inline-block", background: color, border: `6px solid ${C.linea}`, borderRadius: 14, padding: "10px 34px 14px", boxShadow: `10px 10px 0 ${C.linea}` }}>
          <div style={{ fontFamily: MONT, fontWeight: 900, fontSize: tam, color: "#fff", letterSpacing: "-0.01em", lineHeight: 1, textShadow: `5px 5px 0 ${C.linea}`, whiteSpace: "nowrap" }}>{texto}</div>
          {sub ? <div style={{ fontFamily: MONT, fontWeight: 800, fontSize: tam * 0.32, color: "#fff", marginTop: 8, letterSpacing: "0.04em", textShadow: `3px 3px 0 ${C.linea}` }}>{sub}</div> : null}
        </div>
      </div>
    );
  };

// Humo / nube simple
export const Nube: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = C.humo }) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={color} stroke={C.linea} strokeWidth={LW}>
    <path d="M-90,20 Q-110,-30 -60,-36 Q-50,-80 0,-70 Q40,-96 70,-50 Q118,-50 104,4 Q100,30 60,30 L-60,30 Q-92,32 -90,20 Z" />
  </g>
);
