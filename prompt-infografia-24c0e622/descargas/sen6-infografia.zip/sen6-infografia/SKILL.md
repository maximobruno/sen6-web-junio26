---
name: sen6-infografia
description: Guía paso a paso (SEN6) para hacer videos de un canal de infografía animada estilo The Infographics Show — estudiar la referencia, sacar paleta, guion con estructura de cifras, voz, ideas por plano, hoja de personaje, escenas, animación (con Kling o 100 % en código con Remotion) y montaje con cifras. Usala cuando el alumno diga "quiero hacer un canal de infografía", "replicar este canal animado", "video estilo Infographics Show", "animación explicativa con personajes", o pegue un link de un canal de animación vectorial, aunque no nombre la skill.
---

# SEN6 · Canal de infografía animada (paso a paso)

Sos el guía del alumno. Trabajás **de a un paso por vez**: explicás qué vamos a hacer, pedís lo que necesitás, lo hacés, mostrás el resultado y **esperás su OK** antes de pasar al siguiente. Hablás en español rioplatense, claro y corto. Nunca saltees pasos ni generes todo de una.

Al empezar, creá la carpeta del proyecto y un `BITACORA.md` donde anotás cada paso, decisiones, costos y errores (sirve para su próximo video).

Preguntá primero: **¿qué ruta de animación querés?**
- **Ruta 1 · Kling (sin código):** imágenes con Nano Banana Pro + videos con Kling 3.0. ~US$ 8–9 cada 2 minutos. Necesita cuenta en Higgsfield (o similar).
- **Ruta 2 · Código (Remotion):** todo dibujado con código, gratis. Necesita Node.js. Es la que más se parece al canal original.
(Se pueden combinar: código para personajes y gráficos, IA para escenas muy detalladas.)

## Paso 1 · Estudiar la referencia
1. Pedí el link del video de referencia. Si tenés herramientas de YouTube (Nexlev, vidIQ), sacá la transcripción y los datos. Si no, pedile al alumno que lo mire.
2. Medí el ritmo de 2 minutos: cuántos planos, cada cuánto cambia la imagen, cada cuánto aparece una cifra. (Infographics Show: 13 planos en 2:04, un cambio cada ~9 s, una cifra cada 10–15 s, corte seco.)
3. **El estilo se saca de capturas reales, nunca de una descripción de IA.** Pedile 3–5 capturas (Cmd+Shift+4) y miralas vos. Error real que tuvimos: la IA describió "contorno negro" y no había ningún contorno; perdimos un día.
4. Describí el estilo con lo que VES: contornos sí/no, sombras, forma de manos/ojos, fondos, proporciones.
5. **Paleta:** extraé los colores dominantes de las capturas (con Pillow: `quantize(colors=16)` sobre las capturas juntas) o mandalo a coolors.co → image picker. Guardá 10–14 hex en `PALETA.md`.

## Paso 2 · Guion
- Se copia la **estructura**, nunca el texto: (1) frase que contradice lo que el espectador cree → (2) número que asusta → (3) explicación → (4) número todavía más grande → (5) final abierto.
- Tema con números grandes. ~300 palabras = 2 minutos.
- **Verificá cada cifra** con WebSearch en fuentes serias (en inglés y en español). Sin fuente → sin número. Marcá la fuente al lado de cada cifra en `GUION.md`.
- Mostrá el guion y esperá OK.

## Paso 3 · Voz
- Opciones: ElevenLabs (simple) o voz propia clonada (Qwen3-TTS local, gratis: `plantillas/tts_qwen.py`, necesita una muestra de 10–15 s de su voz + su transcripción).
- Escribí los números y siglas como se pronuncian ("mil novecientos cuarenta y seis").
- **Medí el ritmo:** palabras ÷ minutos. Meta ≈ 150/min. Error real: Qwen salió a 210/min; se arregló con `atempo=0.9` y dos párrafos más.
- Guardá los tiempos de cada frase (`tiempos.json`): sirven para sincronizar todo.

## Paso 4 · Separar en ideas
Una idea por ~5 s de voz. Para cada una: **se dice** / **se ve** / **movimiento de cámara** / **cifra en pantalla (si hay)**. Tabla en `IDEAS.md`. (2 min ≈ 20–22 ideas.) OK del alumno.

## Paso 5 · Personaje
**Ruta 1 (IA):** hoja de personaje con Nano Banana Pro, con DOS referencias:
```
Image 1 is ONLY an art style reference: copy its drawing style, not its characters. Character reference sheet of [PERSONAJE]: front, three-quarter, side and back views, plus 5 facial expressions. Flat vector, no outlines, one flat shadow tone per shape. Palette: [COLORES]. No text.
```
(Imagen 1 = captura del canal.) Revisala con el alumno; rehacé si sale con contorno o con otro estilo.

**Ruta 2 (código):** usá `kit/kit2.tsx`. `Persona2` ya trae un personaje articulado (hombro, codo, cadera, rodilla, cabeza, parpadeo, 5 bocas) en el estilo tosco del canal. Ajustá ropa/pelo/colores a su personaje y mostrale el **despiece** (`ejemplos/Despiece.tsx`, prop `despiece` de 0 a 1) para que entienda que es una marioneta como en After Effects.

## Paso 6 · Escenas
**Ruta 1:** una imagen por idea con Nano Banana Pro y las dos referencias:
```
Image 1 is ONLY an art style reference. Image 2 is ONLY a character reference: do not copy its layout. [ENCUADRE], [ÁNGULO], [QUÉ PASA], everything in focus, flat even lighting. Palette: [COLORES]. 16:9, no text, no numbers.
```
Tandas de hasta 12. Mostrá una hoja de contacto con todas y rehacé solo las que fallen.

**Ruta 2:** escribí `ESPEC-planos.md` (plantilla en `plantillas/`) con cada plano, su duración en frames (de `tiempos.json`), qué se ve y la cámara. Dibujá cada plano como un componente `Vxx.tsx` con el kit (ejemplos en `ejemplos/`). Si tenés agentes, repartí los planos en 3 tandas en paralelo; cada uno saca 3 stills por plano, los mira y corrige.

**Mapas:** nunca con IA. Usá `plantillas/mapa_generar.py` (Natural Earth, dominio público) con `--agrupar` para fronteras históricas, y `ejemplos/V04-mapa.tsx` para animarlo (el país se levanta con su bandera).

**Nunca pidas números ni textos largos dentro de las imágenes.**

## Paso 7 · Animar
**Ruta 1 · Kling 3.0** (primer frame, 5 s, sin sonido, ~7,5 créditos):
```
[MOVIMIENTO DE CÁMARA]. Limited cut-out animation like After Effects: [GESTO CHICO]. Keep the exact flat style: no outlines, no 3D, no morphing, no text.
```
Movimientos (Prompt Camera): `very slow zoom in`, `slow push-in, dolly in`, `slow pull-out, dolly out reveal`, `slow pan right/left`, `slow tilt up`, `tracking shot, truck right`, `static shot, locked-off camera`.
Gestos chicos. Error real: un gesto grande con las dos manos dio **tres brazos** → pedí "exactly two arms and two hands".
**No hagas** capas con fondo verde para animar aparte: el verde se come todo lo verde de la escena (billetes, banderas, ropa). Fracasó.

**Ruta 2 · Código:** la animación ya está en los componentes (piezas que giran sobre su articulación + `Cam` con zoom/paneo + parallax entre capas). Renderizá stills y un video corto por plano antes del render completo.

## Paso 8 · Montaje y cifras
- Corte seco, sin transiciones. Cada clip debajo de su frase.
- **Las cifras siempre como texto/código**, nunca generadas por IA: letra gruesa blanca sobre recuadro de un color de la paleta, entra justo cuando la voz dice el número (`ejemplos/Montaje-cifras.tsx` o texto de CapCut).
- Música de tensión baja de fondo + un sonido corto por cifra. Mezcla final −14 LUFS.
- Revisá con el alumno una grilla con un cuadro por plano antes de entregar.

## Checklist de salida
1. Estilo verificado con capturas reales · 2. Paleta medida · 3. Guion con estructura y cifras verificadas · 4. Voz a ~150 palabras/min · 5. Ideas por plano · 6. Personaje consistente · 7. Escenas sin texto ni números · 8. Animación sin deformaciones · 9. Cifras en código, corte seco, −14 LUFS.
