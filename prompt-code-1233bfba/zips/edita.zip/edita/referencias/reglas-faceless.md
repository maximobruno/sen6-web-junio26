# Reglas · Edita faceless (sin cara)

## 1. Punto de partida
Un **audio** (voz propia o con IA). La pantalla está vacía: todo lo que se ve lo crea la edición. Si todavía no hay guion, se puede pedir antes, pero **el guion lo revisa el alumno antes de grabar**: un error en el guion se vuelve un error en la voz, que es lo más caro de corregir.

## 2. Quién manda en pantalla
**Manda lo visual.** No hay una cara que sostenga la atención: la pantalla **nunca queda vacía ni quieta**. Cada escena se mueve (acercamiento lento, paneo) y cambia con la idea.
- Lo visual cambia **con cada idea, no con cada frase**: si tres frases hablan de lo mismo, un solo elemento que se completa (lista que suma ítems, línea de tiempo que avanza) en vez de tres imágenes sueltas.
- La imagen tiene que **coincidir con lo que se dice en ese segundo**. Si no hay imagen buena, mejor un gráfico con código (número, lista, ícono, línea de tiempo) que una imagen que no tiene nada que ver.
- Imágenes de IA: etiqueta "Imagen ilustrativa" (o la que diga la ficha) cuando puedan confundirse con fotos reales de un hecho.

## 3. Ritmo
- **Largo: una imagen nueva cada 3–6 s** según la ficha (curiosidades 3 s, explicaciones 4–5 s, relatos e historia 6 s). Encima, un elemento (título, número, lista) en los momentos clave.
- **Shorts/Reels: algo nuevo cada 3–5 s**, primer cambio antes de los 2 s.
- `revisar()` con `ritmo_max` = el máximo de la ficha marca los huecos.
- Transiciones: fundido por defecto; `empuje`, `zoom` o `flash` para cambios de bloque (no en cada escena: cansa).

## 4. Cortes
Los cortes de audio son invisibles: se puede cortar más sin miedo.
- "Cortar todos": `--umbral 0.3 --pad 0.06`. "Pausas cortas" (relatos, misterio): `--umbral 0.4 --pad 0.14` — las pausas dramáticas quedan en ~0,3 s.
- Voz con IA: suele venir sin silencios largos; con `--pad 0.14` alcanza.
- Igual que en personal: **re-transcribir el cortado** antes de anclar.

## 5. Herramienta
- **Escenas** (imágenes, capturas, clips + datos encima): Remotion, `Faceless.tsx` (`escenas` + `elementos` en `datos.json`; ejemplo `plantillas/build_faceless_ejemplo.py`).
- **Textos animados** (kinetic typography) o Mac con macOS < 15: HyperFrames, `plantillas/hyperframes/build.mjs` (`beats.json`; ejemplo `plantillas/build_hf_ejemplo.py`). Cambiar una palabra = tocar `beats.json`, `node build.mjs`, volver a renderizar.
- Mezcla: escenas en Remotion y algunos tramos de texto animado en HyperFrames se pueden unir con ffmpeg (mismo tamaño y fps), siempre con el render mudo.
- Videos largos (> 8 min): repartí bloques entre subagentes (cada uno arma el `build` de un tramo de la transcripción con las mismas reglas y el mismo tema) y uní los `elementos`/`escenas` en un solo `datos.json`.

## 6. Riesgos (revisar SIEMPRE antes del render)
- **Imagen que no coincide** con lo que se dice → stills en los cambios de escena, leyendo la transcripción al lado.
- **Imágenes repetidas** → una imagen no se repite en el mismo video salvo a propósito (callback) y con otro movimiento.
- **Datos inventados para llenar la pantalla** → prohibido presentarlos como reales: `ejemplo=True` (sello "EJEMPLO") o `fuente="…"`. Si el alumno no tiene el dato, preguntale.
- **Archivos que faltan** (`public/img/…`): el render se cae al final. Copiá todas las imágenes a `editor/public/img/` (o `hf/assets/img/`) antes de empezar y verificá que existan todas las rutas de `datos.json`.
- **Textos ilegibles** sobre imágenes claras: la plantilla oscurece arriba y abajo; si igual no se lee, `oscurecer: 2` en la escena o poné el texto en tarjeta.
- **Derechos**: nada de imágenes, música o clips de otros canales. Stock con licencia libre (Pexels, Pixabay, Mixkit) o generadas.
