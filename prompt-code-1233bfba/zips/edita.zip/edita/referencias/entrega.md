# Entrega y extras

## Un solo archivo final
- El final queda en la carpeta del video con un nombre claro: `<carpeta del video>/<nombre-del-video>.mp4`.
- Toda versión anterior (renders mudos viejos, finales previos) va a `<video>/out/archivo/` con fecha: `mv <x>.mp4 out/archivo/<x>_v1.mp4`. Nunca borres: archivá.
- Antes de entregar: grilla de 8 cuadros del final (`ffmpeg -i final.mp4 -vf "fps=8/<dur>,scale=480:-2,tile=4x2" -frames:v 1 out/final_grilla.jpg`), mirala, y verificá LUFS −14 y sincronía 0 ms (lo imprime `unir_audio.sh`).
- Preguntá antes de abrirle el archivo. Si dice que sí: Mac `open "<final>.mp4"`.
- Al terminar, anotá el video en `<canal>/historial_elementos.md`.

## Cambios después de verlo
- Pedile que junte TODOS los cambios en un solo mensaje, con minuto y segundo ("en 1:10 el texto aparece antes; que entre cuando digo 'presupuesto'").
- Corregí todo junto y renderizá una sola vez.
- Solo audio (música más baja, un efecto de más): rehacé `mezcla.py` y `unir_audio.sh` sobre el mismo render mudo. No hace falta re-renderizar.
- Solo el final (cortar en una frase): medí dónde termina la palabra (RMS cada 20 ms, cortá ~0,1 s después de que cae bajo −50 dB) y `ffmpeg -i final.mp4 -t <fin> -c:v copy -af "afade=t=out:st=<fin-0.12>:d=0.12" corto.mp4`. Si el corte cae entre dos cuadros clave, quitá `-c:v copy` (re-codifica, más lento).
- Si un cambio es chico y prefiere hacerlo él: CapCut (importa el `.mp4` final, mueve el corte, suma un sticker, exporta).

## Subtítulos editables para CapCut (.srt)
`npx -y hyperframes transcribe work/transcript_cortado.json --to srt -o <nombre>.srt`
En CapCut de escritorio: menú Subtítulos/Captions → importar → elegir el `.srt`. Quedan en una pista, con estilo editable ("aplicar a todos"). CapCut móvil no importa `.srt`; CapCut web sí.

## Título, descripción, capítulos, etiquetas, miniatura (ofrecelo siempre)
- **Título**: 5 opciones cortas (< 60 caracteres), con la promesa del video y el tono de la ficha. Sin clickbait que el video no cumpla.
- **Descripción**: 2–3 líneas que resuman la promesa + el CTA de la ficha (si tiene link, el del alumno) + capítulos.
- **Capítulos**: salen de los tiempos del `build.py` (los `capitulo`, `paso` o cambios de tema). Formato YouTube: el primero en `0:00`, mínimo 3, cada uno de 10 s o más, `m:ss Título`.
- **Etiquetas**: 10–15, separadas por coma, en total menos de 500 caracteres.
- **Idea de miniatura**: 2–3 ideas (qué se ve, 2–4 palabras de texto grande, colores de la ficha). En personal: la expresión más fuerte del video (proponé 3 segundos donde sacar el cuadro). En faceless: el objeto/escena clave.
- Guardá todo en `<video>/<nombre>_publicacion.txt`.
