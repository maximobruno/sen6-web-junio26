# Revisión de requisitos (la primera vez, y si algo falla)

Corré `bash <skill>/scripts/requisitos.sh` y explicale al alumno el resultado en criollo, línea por línea.

| Requisito | Para qué | Cómo se instala |
|---|---|---|
| **Node.js 22 o más nuevo** | hace correr Remotion y HyperFrames | Mac: `brew install node@22` (o el instalador LTS de nodejs.org) · Windows: `winget install OpenJS.NodeJS.LTS` |
| **FFmpeg** | las "tijeras": corta, une y convierte audio y video | Mac: `brew install ffmpeg` · Windows: `winget install ffmpeg` |
| **Google Chrome** | Remotion y HyperFrames "graban" el video con un Chrome invisible; capturas de páginas | google.com/chrome · Mac: `brew install --cask google-chrome` |
| **Python 3** (solo biblioteca estándar) | los scripts de cortes, anclas y mezcla | Mac: viene con las Command Line Tools (`xcode-select --install`; Homebrew las instala solo) · Windows: `winget install Python.Python.3.12` |
| **macOS 15 (Sequoia) o más nuevo** | lo exige Remotion en Mac | Si la Mac no se puede actualizar: usar **solo HyperFrames** (faceless con textos animados o imágenes; personal con el video de fondo en HyperFrames) |
| Skills oficiales de Remotion | le enseñan a Claude a usar Remotion bien | `npx -y skills@latest add remotion-dev/skills -g -y` |
| Plugin de HyperFrames | ídem para HyperFrames | `claude plugin marketplace add heygen-com/hyperframes` y `claude plugin install hyperframes@hyperframes` (después, sesión nueva o `/reload-plugins`). Alternativa: `npx hyperframes skills update` |
| Modelo de transcripción | Whisper local (se baja solo la primera vez, ~1,5 GB el `medium`) | automático con `transcribir.sh` |

## Reglas de seguridad
- **Contraseñas: nunca.** Si la terminal pide la contraseña de la computadora (Homebrew, instaladores), decile al alumno: "ahora la terminal te va a pedir la contraseña de tu compu: escribila vos ahí (no se ve mientras tipeás) y apretá Enter". Nunca la pidas ni la escribas en el chat.
- Antes de instalar algo, decí qué es, para qué sirve y cuánto pesa más o menos. Instalá de a uno y confirmá que quedó (`node -v`, `ffmpeg -version`).
- Si no hay Homebrew en Mac: se instala desde brew.sh con el comando oficial; el alumno pega el comando y escribe su contraseña él mismo.

## Licencias (explicalas una vez, corto)
- **Remotion no es gratis para todos.** Gratis para personas solas, organizaciones sin fines de lucro y **empresas de hasta 3 personas**, aunque el canal esté monetizado. **Desde 4 personas** hace falta la licencia de empresa (remotion.pro/license; hoy desde US$25 por mes por cada persona que edita). Preguntá: "¿cuántas personas trabajan en tu canal o empresa?".
- **HyperFrames** es de código abierto (Apache 2.0): gratis para todos, también empresas. Solo se paga si se usan servicios de HeyGen (voces, avatares, render en la nube).
- **Whisper / whisper.cpp, FFmpeg**: gratis, funcionan en la compu, no se sube nada a internet.
- **Mixkit** (música y efectos): gratis para YouTube con uso comercial; no se puede registrar en Content ID ni revender suelta; si llega un reclamo, escribir a team@mixkit.co. **Nunca la biblioteca de música de CapCut en videos monetizados.**
- **Claude Code** necesita un plan pago de Claude.

## Instalar dependencias del proyecto
- Remotion: `nuevo_editor.sh` hace `npm install` en `<video>/editor` (la primera vez ~1 GB y unos minutos). Si ya hay otro video del mismo canal con `editor/node_modules` de la misma versión, podés reusarlo: `EDITA_NODE_MODULES=<ruta>/node_modules bash nuevo_editor.sh …`.
- HyperFrames: no instala nada en el proyecto (`npx hyperframes …` lo baja solo).

## Windows
Los scripts `.sh` necesitan Git Bash (viene con Git para Windows: `winget install Git.Git`) o WSL. Si no hay ninguno, hacé los mismos pasos a mano con los comandos de ffmpeg/npx equivalentes en PowerShell; los `.py` corren igual.
