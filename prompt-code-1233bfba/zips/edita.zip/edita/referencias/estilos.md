# Catálogo de componentes y estilos

Todo toma colores y fuentes de `tema.json` (la ficha). La estética es fija por canal; **los elementos y las entradas rotan** entre videos (ver `historial_elementos.md` de la carpeta del canal).

## 1. Elementos de Remotion (`type` en `datos.json → elementos`)
Campos comunes: `s` (aparece), `e` (se va), `lado` (`auto` · `izq` · `der` · `arriba` · `abajo` · `centro` · `completo` · `abajo_esq` · `arriba_esq`), `entrada` (pisa la del video).
Tiempos internos (`at`, `…At`) siempre con `A("frase")`. Texto: `[palabra]` = color de acento, `{palabra}` = subrayado.

| type | Para qué | Campos |
|---|---|---|
| `titulo` | frase grande palabra por palabra; tachar una idea | `lineas: [{t, at?, tachar?, chico?}]`, `kicker?` |
| `numero` | cifra que cuenta (dinero, vistas, años) | `valor, desde?, prefijo?, sufijo?, decimales?, etiqueta?, ejemplo?, fuente?` |
| `lista` | pasos, ítems que se van sumando, tachados | `items: [{t, at, tachar?, icono?}], titulo?, numerada?` |
| `captura` | captura de pantalla o clip, con marco | `src` (en public/), `marco: navegador·celular·ninguno, url?, etiqueta?, zoom: in·out, foco?` |
| `cita` | frase textual de alguien | `texto, autor?` |
| `chips` | etiquetas que caen de a una (marcas, temas) | `chips: [{t, at}], titulo?, activo?` |
| `etiqueta` | zócalo: nombre de una persona, lugar, herramienta | `texto, sub?, icono?` (lado por defecto `abajo_esq`) |
| `barras` | comparar cantidades | `barras: [{t, v, at?, resaltar?}], titulo?, unidad?, ejemplo?` |
| `comparar` | antes/después, sí/no, A vs B | `a: {titulo, items[]}, b: {…}, bAt?, ganador?` |
| `paso` | "Paso 2 de 5" con número que se llena | `n, total?, titulo, sub?` |
| `capitulo` | pantalla de capítulo (tapa todo 2–3 s) | `n, titulo` |
| `linea` | línea de tiempo con fechas | `puntos: [{t, d?, at}], titulo?` |
| `alerta` | advertencia, error típico | `texto, sub?` |
| `icono` | símbolo grande + palabra (miniatura simbólica) | `icono, texto, sub?` |
| `progreso` | "2/5" persistente en la esquina | `actual, total, etiqueta?` |
| `suscribir` | botón + cursor + campanita | `clicAt?, campanaAt?` |
| `cta` | el llamado a la acción del canal (tema.cta) | `texto?, sub?` |

Íconos de trazo (sin emojis): check, x, candado, abierto, play, campana, estrella, reloj, grafico, dinero, flecha, alerta, persona, lupa, idea, corazon, rayo, mundo, camara, mano, libro.

**Agregar un componente nuevo** (para rotar): escribilo en `editor/src/Elementos.tsx` siguiendo el patrón (`const X: El = ({ b, a }) => …`, sumalo a `MAPA`), usando solo `C`, `FT`, `FX` y `Tarjeta` para que respete el tema. Anotalo en el historial.

## 2. Entradas (rotan entre videos: `entrada` en `datos.json`)
`resorte` (escala con rebote) · `barrido` (se revela de izquierda a derecha) · `giro` (gira en Y desde el costado) · `foco` (de desenfocado a nítido) · `persiana` (se revela de arriba a abajo) · `caida` (cae desde arriba con rebote).
"Sobrio" → `foco`, `barrido`, `persiana`. "Dinámico" → `resorte`, `giro`, `caida`.

## 3. Ventana del video (personal)
16:9: `FULL` · `DER` (video a la derecha, contenido a la izquierda) · `IZQ` · `ARRIBA` (ventana chica arriba, contenido abajo) · `ESQUINA` (video chico abajo a la derecha, panel ancho a la izquierda).
9:16: `FULL` · `ARRIBA` (video arriba, contenido abajo) · `ABAJO`.
Detrás de la ventana: el mismo video desenfocado y oscurecido + un brillo suave del color de acento. El encuadre centra la cara y nunca deja bordes negros.
Vida: golpe de zoom al arrancar, `acentos` (acercamiento ~2 s en frases clave), zoom alternado en cada `corte`.

## 4. Escenas (faceless, `escenas` en `datos.json`)
`{s, e, src, tipo: imagen·video·captura·color, mov: in·out·izq·der·arriba·abajo, trans: fundido·empuje·zoom·flash·corte, etiqueta?, oscurecer?, foco?}`
- `captura`: se muestra entera y legible sobre su propio fondo desenfocado (no se recorta el texto).
- `mov` alterná entre escenas seguidas (in → izq → out → arriba…), nunca el mismo dos veces seguidas.

## 5. Layouts de HyperFrames (`layout` en `beats.json`)
`frase` (`texto, kicker?, stagger?`) · `numero` (`valor, prefijo?, sufijo?, texto?, ejemplo?, fuente?`) · `lista` (`titulo?, items: [{t, at?}]`) · `cita` (`texto, autor?`) · `capitulo` (`texto, kicker?/n?`) · `comparar` (`a: {titulo, texto}, b: {…}, bAt?`) · `imagen` (`src` en assets/img, `texto?, textoAt?, mov?, etiqueta?`).
Rotación: cambiá el orden de los layouts, el `stagger`, y sumá layouts nuevos al objeto `L` de `build.mjs` (con su `html` y su `tl`).

## 6. Efectos de sonido por evento (biblioteca de `descargar_mixkit.sh`)
| Evento | Efecto | Nivel |
|---|---|---|
| Cambio de ventana / encuadre | `whoosh_fast` (alineado por pico) | −21 dB |
| Cambio de escena (faceless) | `sweep_short` / `whoosh_fast2` (empuje) | −27 dB |
| Entra título / frase | `whoosh_pop` | −21 dB |
| Entra tarjeta / lista | `sweep_small` | −22 dB |
| Aparece ítem, chip | `bubble_pop` | −24 dB |
| Número / dinero | `select` + `coin` | −19 / −24 dB |
| Captura | `shutter` | −18 dB |
| Clic / suscribir | `mouse_click` + `bell_notif` | −18 / −20 dB |
| Capítulo, paso, frase fuerte | `impact` | −18 a −20 dB |
| Error, alerta, tachado | `wrong` | −20 dB |
| Logro, cierre, CTA | `achievement` | −20 dB |
| Texto que se escribe | `typing_e` (con `M.typing`) | −26 dB |
Video largo: todo 2–3 dB más bajo y menos seguido. Nada de golpes en el segundo 0 (tapan la primera palabra).

## 7. Música por tono (archivos `sfx/musica_*.mp3`)
- Cercano / energético: `tech_house_vibes`, `gimme_groove`, `upbeat_644`, `energetic_1068`, `happy_839`
- Serio / profesional: `skyline`, `discover`, `digital_clouds`, `deep_urban`
- Misterioso / narrativo: `silk`, `vastness`, `echoes`, `silent_descent`, `piano_reflections`
- Didáctico: `coffee_or_tea`, `journey`, `drawing_sky`
Shorts: un tema. Largos: 3–6 temas encadenados (la lista `musica` del `mezcla.py`; se cruzan con fundido). Voz −16 LUFS, música −31 LUFS con ducking.

## 8. Capturas reales
- `capturar.sh <url> <png>`: Chrome sin ventana, sin iniciar sesión. Etiquetala "captura real" con la URL en el marco de navegador.
- Las capturas que manda el alumno (Cmd+Shift+4 en Mac, Windows+Shift+S en Windows) llegan a Descargas: copialas a `editor/public/cap/` apenas llegan.
- Una captura con texto chico o muy largo: recreala legible con el texto exacto y etiqueta "recreación".
