# Historial de elementos usados (para rotar)

> **Plantilla.** El historial real vive en la carpeta de cada canal: `<carpeta del canal>/historial_elementos.md`.
> Si no existe, copiá este archivo ahí la primera vez que edites un video de ese canal.

## La regla
**Misma estética, elementos que rotan.** Los colores, la tipografía y el estilo (sobrio/dinámico) son siempre los de la ficha: así el canal se reconoce. Pero los gráficos cambian de video a video: así la audiencia siempre encuentra algo nuevo.

Antes de diseñar el guion visual:
1. Leé las últimas 2 entradas de este historial.
2. Elegí otra `entrada` (resorte, barrido, giro, foco, persiana, caida) que la de los últimos 2 videos.
3. Elegí componentes que no se hayan usado en los últimos 2 videos, o una variante clara (otra forma, otra animación, otro lado de la pantalla). Si el catálogo no alcanza, creá un componente nuevo con el mismo tema (ver `estilos.md` §1).
4. Lo único que se repite son los obligatorios de la ficha (CTA, suscribir), con otra puesta en escena.

Al entregar, agregá una entrada arriba de todo con este formato:

```
## <fecha> · <largo | short> "<título del video>" (<16:9 | 9:16>, <duración>)
entrada: <nombre> · ventana/escenas: <modos usados> · elementos: <lista corta separada por " · ">
```

---

<!-- las entradas nuevas van debajo de esta línea, la más reciente primero -->
