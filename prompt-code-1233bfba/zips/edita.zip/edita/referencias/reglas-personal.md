# Reglas · Edita personal (cabeza parlante)

## 1. Punto de partida
Un **video grabado**. Lo más valioso es la cara, los gestos y la forma de hablar del alumno: la edición los acompaña, no los reemplaza. Grabó sin preocuparse por errores: si se equivocó, repitió la frase. Esas tomas repetidas se sacan.

## 2. Quién manda en pantalla
**Manda la persona.** La gente le mira la cara. Los gráficos acompañan al costado o arriba de la cabeza, aparecen y se van.
- **Nunca un elemento encima de la cara.** Si un gráfico necesita el centro: se cambia la ventana (`DER`, `IZQ`, `ARRIBA`, `ESQUINA`; en 9:16 `ARRIBA`/`ABAJO`) y el gráfico ocupa el lugar libre. `revisar()` avisa si algo va al centro con el video a pantalla completa.
- A pantalla completa la cara queda centrada: el lado libre es angosto (~650 px en 16:9). Ahí van cosas cortas (chips, un número, un ícono, un zócalo). Listas, capturas y comparaciones → ventana achicada.
- **Grabación horizontal convertida en Short/Reel (9:16):** a pantalla completa la cara ocupa casi todo el cuadro. Ahí solo entran cosas chicas (chips, zócalo, título corto) debajo del mentón; todo lo grande (número, lista, captura, ícono) va con la ventana `ARRIBA` o `ABAJO`. `revisar()` lo marca. Si graba pensando en Reels, que deje aire arriba de la cabeza.
- `capitulo` es la única pieza que tapa todo, porque es un corte de 2–3 s, no un gráfico encima.
- Medí la cara (`CARA`) en `work/cuadro.jpg` antes de diseñar. Si el alumno se mueve mucho, usá la posición promedio de `work/hoja.jpg`.

## 3. Ritmo
- **Largo (16:9): un gráfico nuevo cada 10–15 s** + **reencuadres**: la toma se acerca en frases clave (`acentos`) y cambia de tamaño en cada corte (`cortes`, zoom alternado 1,00/1,07) para esconder el salto.
- **Shorts/Reels (9:16): algo nuevo cada 3–5 s.** Gancho visual en los primeros 3 s. Zona segura: todo el texto dentro de x 60–940, y 250–1460 (revisá con la composición `Guia`).
- Cambios de ventana: cada 20–40 s en un largo. No más de un cambio cada 6 s (marea).
- Más gráficos no es mejor: si en 15 s habla de una sola idea, un elemento que se completa (lista que suma ítems) en vez de tres sueltos.

## 4. Cortes
- Silencios: `cortar_silencios.py --umbral 0.35 --pad 0.075` (ritmo YouTube). "Pausas cortas" → `--pad 0.15`. "No cortar" → `--sin-cortes`.
- Tomas repetidas: `tomas_repetidas.py` propone; vos leés el contexto y armás `work/excluir.json` cortando ENTRE palabras. Verificá los empalmes en la transcripción del cortado.
- Siempre **re-transcribir el cortado** (`work/transcript_cortado.json`). Sin eso los gráficos aparecen cada vez más temprano.
- En cada corte, cambio de tamaño de la toma (lo hace solo la plantilla con `cortes`).

## 5. Herramienta
**Remotion** (plantilla `plantillas/remotion`, componente `Personal.tsx`): video de fondo + ventana con resorte + reencuadres + elementos. HyperFrames solo si el alumno tiene macOS < 15 (en ese caso, armá el video de fondo con `<video>` muteado + los mismos layouts del `build.mjs`, y renderizá mudo igual).

## 6. Riesgos (revisar SIEMPRE antes del render)
- **Taparle la cara** → stills de cada elemento, mirando la cara.
- **Voz desfasada de los labios** → render MUDO + voz original aparte (`unir_audio.sh` verifica 0 ms).
- **Franjas negras** al achicar/acercar → la plantilla calcula el encuadre "cover"; si cambiás `GEO`, revisá un still a pantalla completa.
- **Colores lavados** de iPhone (HDR) → `preparar.sh` los convierte; si `work/info.txt` dice `arib-std-b67` o `smpte2084` y no había `avconvert`, avisá.
- **Fuera de la zona segura** en 9:16.
- **Datos inventados**: todo número de ejemplo lleva `ejemplo=True` (sello "EJEMPLO"); los reales, `fuente="…"`.
- **Audio roto en el celular** si la voz vino muy baja (−22 LUFS o menos): la mezcla deja margen a −3 dBFS y `unir_audio.sh` limita antes de normalizar. Verificá `Flat factor: 0`.
