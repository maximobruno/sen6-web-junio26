# Formulario de la ficha de edición

Se hace UNA sola vez por canal, antes del primer video. Sin ficha, Claude no edita.

## Cómo preguntar (reglas para Claude)
- **De a una pregunta** (como mucho un bloque de 2–3 preguntas cortas y relacionadas). Esperá la respuesta antes de seguir.
- Cada pregunta lleva: qué significa el término en palabras simples, **opciones numeradas** y un ejemplo. El alumno puede contestar solo con el número.
- Siempre hay una opción **"No sé / elegí vos"**: en ese caso usá el valor recomendado (marcado con ★) y avisalo.
- Voseo rioplatense, cálido y concreto. Nada de jerga sin explicar.
- Mostrá el avance: "Pregunta 4 de 16".
- Si una respuesta no encaja con otra anterior (p. ej. "mucho movimiento" + "sin ritmo"), preguntá cuál manda.
- Al final, mostrá un **resumen de la ficha** y pedí confirmación antes de guardar.
- Nunca pidas contraseñas, datos de tarjeta ni claves de nada.

Las preguntas con [P] van solo para marca personal, las [F] solo para faceless, el resto para los dos. Si tiene los dos tipos, hacé las comunes una vez y después las dos ramas.

---

## Bloque 1 · Tu canal

**1. ¿Qué tipo de canal tenés?**
> Marca personal = aparecés vos hablando a cámara (también se dice "cabeza parlante"). Faceless = "sin cara": no te mostrás; el video es tu voz (o una voz con IA) con imágenes, capturas y textos.
1. Marca personal (hablo a cámara)
2. Faceless (sin cara)
3. Los dos (tengo un canal de cada tipo, o mezclo)

**2. ¿De qué trata tu canal y para quién es?** (respuesta libre)
> Ejemplo: "Finanzas personales para gente de 25 a 35 que recién empieza a invertir". Sirve para elegir imágenes, ejemplos y el tono de los gráficos.

**3. ¿Qué formato hacés?**
> Largo horizontal = el video común de YouTube (16:9). Vertical = Shorts, Reels y TikTok (9:16).
1. Largos horizontales (16:9)
2. Shorts / Reels verticales (9:16)
3. Los dos ★

**4. ¿Cuánto duran tus videos, más o menos?**
1. Menos de 1 minuto (Shorts/Reels)
2. 5 a 10 minutos ★
3. 10 a 20 minutos
4. Más de 20 minutos
> Sirve para saber cuánto tarda cada render y si conviene dividir el trabajo en partes.

**5. ¿En qué idioma hablás y con qué tono?**
- Idioma: 1. Español ★ · 2. Inglés · 3. Otro (¿cuál?)
- Tono: 1. Cercano y canchero · 2. Serio y profesional · 3. Misterioso / narrativo · 4. Energético · 5. Didáctico, paso a paso
> El tono define la música, los efectos de sonido y qué tan "movido" es el diseño.

## Bloque 2 · [P] Marca personal (si respondió 1 o 3)

**6P. ¿Cómo es tu lugar de grabación?** (respuesta libre)
> Ejemplo: "un escritorio con una biblioteca atrás y una luz azul". Sirve para elegir colores que combinen con tu fondo.

**7P. ¿Dónde queda tu cara en el cuadro?**
> Lo mido yo con tu primer video; esto es solo para tener una idea.
1. En el centro ★
2. Un poco a la izquierda
3. Un poco a la derecha
4. Abajo, con mucho espacio libre arriba de la cabeza

**8P. ¿Cómo querés que aparezcan los gráficos sin taparte?**
1. **Ventana que se achica**: cuando hace falta lugar, tu video se hace más chico y se corre a un costado, y el gráfico ocupa el resto ★
2. **Al costado**: los gráficos aparecen en el lado libre del cuadro, sin achicar el video
3. **Arriba de la cabeza**: si grabás con mucho aire arriba, los gráficos van en esa franja
4. Una mezcla de las tres (elegí vos según cada momento)

**9P. ¿Querés reencuadres?**
> Reencuadre = la toma se acerca o se aleja un poco en las frases importantes y en cada corte, como si hubiera un camarógrafo. Esconde los saltos de los cortes.
1. Sí, en cada corte y en frases clave ★
2. Solo en frases clave
3. No

**10P. ¿Cómo grabás?** 1. iPhone · 2. Android · 3. Cámara · 4. Webcam
> Si es iPhone, convierto los colores del modo HDR para que no se vean lavados.

## Bloque 2 · [F] Faceless (si respondió 2 o 3)

**6F. ¿De dónde sale la voz?**
1. Mi voz grabada ★
2. Voz con IA (ElevenLabs, etc.)
3. Todavía no sé
> Si es con IA: avisame de qué herramienta, para ajustar el volumen y las pausas.

**7F. ¿Qué imágenes usás?** (podés elegir varias)
1. Imágenes generadas con IA
2. Capturas de pantalla (páginas, herramientas, notas)
3. Fotos y videos de stock (Pexels, Pixabay…)
4. Solo textos y gráficos hechos con código
> Las imágenes las conseguís vos (o te ayudo a pedirlas); yo las ordeno, las animo y las pego a la frase justa.

**8F. ¿Qué estilo visual querés?**
1. **Escenas** con imágenes y capturas que se mueven, con datos y textos encima (Remotion) ★
2. **Textos animados** (kinetic typography: las palabras aparecen y se mueven con la voz; HyperFrames)
3. Mezcla de las dos
> Ejemplo de 1: canales de historia o de noticias. Ejemplo de 2: canales de frases, motivación o explicaciones rápidas.

**9F. ¿Cada cuánto cambia la imagen?**
1. Cada 3 segundos (muy dinámico: entretenimiento, curiosidades)
2. Cada 4–5 segundos ★
3. Cada 6 segundos (relatos tranquilos, historia, misterio)

## Bloque 3 · Estética (los dos)

**11. Paleta de colores.** Mostrá las opciones con sus colores (si podés, como muestra visual):
1. **Medianoche** — fondo #0E1116, tarjetas #1B2029, texto #F4F1EA, acento #FF5A3C, acento 2 #FFC857 (oscuro con naranja: tecnología, negocios)
2. **Papel antiguo** — fondo #0D1114, tarjetas #1A2228, texto #EFE8D8, acento #E3A341, acento 2 #7FB7BE (historia, misterio, relatos)
3. **Menta limpia** — fondo #F6F7F2, tarjetas #FFFFFF, texto #14181F, acento #12B886, acento 2 #3B5BDB (claro: educación, salud, productividad)
4. **Neón** — fondo #0A0A12, tarjetas #161628, texto #F2F2FF, acento #7C5CFF, acento 2 #00E5FF (gaming, IA, futuro)
5. **Rojo editorial** — fondo #111111, tarjetas #1E1E1E, texto #FFFFFF, acento #E63946, acento 2 #F1FAEE (noticias, opinión, deportes)
6. **Arena cálida** — fondo #1C1714, tarjetas #2A221D, texto #F7EFE6, acento #D97745, acento 2 #A3B18A (estilo de vida, cocina, viajes)
7. **Mis colores** — pasame los códigos hex (#RRGGBB) de fondo, texto y acento (si tenés logo, sacamos los colores de ahí)
> Paleta = los 4–6 colores que se repiten en todos tus videos. El "acento" es el color que resalta lo importante.

**12. Tipografía** (todas gratis, de Google Fonts):
1. **Oswald + Inter** — títulos altos y angostos, muy de YouTube; texto limpio ★
2. **Montserrat** — redonda y moderna, sirve para todo
3. **Bebas Neue + Inter** — títulos en mayúsculas, impacto (ojo: Bebas solo tiene mayúsculas)
4. **Playfair Display + Source Sans 3** — elegante, con serifa (historia, arte, misterio)
5. **Space Grotesk** — técnica, de tecnología e IA
6. **Archivo Black + Archivo** — gruesa y pesada, para datos y titulares fuertes
7. **Otra** — decime el nombre exacto en fonts.google.com

**13. ¿Sobrio o con mucho movimiento?**
1. **Sobrio**: entradas suaves, pocos efectos, se lee tranquilo
2. **Dinámico**: entradas con rebote, giros, acercamientos más marcados ★
> No cambia la cantidad de gráficos (eso es el ritmo), cambia cómo se mueven.

## Bloque 4 · Ritmo, sonido y textos

**14. ¿Qué hago con los silencios?**
1. Cortar todos (ritmo rápido, típico de YouTube) ★ para personal
2. Dejar pausas cortas (más natural; ideal para relatos) ★ para faceless narrativo
3. No cortar nada
> Siempre saco las tomas repetidas (cuando te equivocás y repetís la frase), salvo que me digas que no.

**15. ¿Subtítulos quemados en el video?**
1. No, solo gráficos de apoyo ★ (si querés subtítulos editables, te doy un archivo .srt para CapCut)
2. Sí, palabra por palabra con tu color de acento (útil en Shorts/Reels que se miran sin sonido)

**16. ¿Música y efectos de sonido?**
1. Música de fondo suave + efectos en los momentos clave ★
2. Solo efectos
3. Solo música
4. Nada (solo mi voz)
> Uso Mixkit: gratis para YouTube, incluso monetizado. **Nunca** uses la biblioteca de música de CapCut en videos monetizados.

**17. Reglas que nunca se rompen** (elegí todas las que quieras y sumá las tuyas):
1. Ningún gráfico me tapa la cara [P] ★
2. Nunca una imagen quieta más de X segundos [F] ★
3. Sin emojis ★
4. Todo dato inventado lleva "EJEMPLO" en pantalla; los datos reales, con su fuente ★
5. No usar la marca / logo de otros canales
6. Otra: …

**18. ¿Tenés un llamado a la acción propio?** (opcional)
> CTA = lo que le pedís al espectador: "suscribite", "mirá el video que te dejo acá", "bajate la guía gratis del link". Decime el texto y en qué momento va (mitad / final).
- ¿Querés el botón "Suscribirme" animado con la campanita? 1. Sí, al principio y al final · 2. Sí, 3 veces repartidas ★ · 3. No

**19. ¿Dónde guardo todo?**
> Una carpeta para tu canal y, adentro, una carpeta por video. Ejemplo: `~/Videos/MiCanal/` ★
- Si no tenés una, la creo yo con ese nombre (pedí permiso antes de crearla).

---

## Qué se escribe al terminar

1. `<carpeta del canal>/ficha-edicion.md` con este formato:

```markdown
# Ficha de edición · <nombre del canal>
Actualizada: <fecha>

## Canal
- Tipo: personal | faceless | los dos
- Tema y público: …
- Formato: 16:9 | 9:16 | los dos · Duración típica: …
- Idioma y tono: …

## Personal            (solo si aplica)
- Estudio: …
- Cara en el cuadro: centro | izq | der | abajo con aire arriba  (medida: x=…, y=… en <video>)
- Gráficos: ventana que se achica | al costado | arriba de la cabeza | mezcla
- Reencuadres: en cortes y frases clave | solo frases | no
- Cámara: iPhone (HDR) | …

## Faceless            (solo si aplica)
- Voz: propia | IA (<herramienta>)
- Imágenes: IA | capturas | stock | solo gráficos
- Estilo: escenas (Remotion) | textos animados (HyperFrames) | mezcla
- Cambio de imagen: cada … s

## Estética
- Paleta: <nombre> (fondo …, tarjetas …, texto …, acento …, acento 2 …)
- Tipografía: títulos <familia peso> · texto <familia pesos>
- Movimiento: sobrio | dinámico
- Mayúsculas en títulos: sí | no

## Ritmo y sonido
- Silencios: cortar todos | pausas cortas | no cortar  (umbral …, pad …)
- Subtítulos quemados: sí | no
- Música/efectos: …

## Reglas que nunca se rompen
- …

## CTA
- Texto: … · Momento: … · Suscribirme animado: …

## Carpeta
- <ruta>

## Cambios pedidos
- <fecha>: <lo que pidió cambiar>
```

2. `<carpeta del canal>/tema.json` (lo leen las plantillas; partí de `plantillas/tema_ejemplo.json`):
   - `colores`: fondo, superficie (tarjetas), texto, suave (texto secundario), acento, acento2, ok (verde), error (rojo)
   - `fuentes.titulos` y `fuentes.texto`: `{ "familia": "Nombre exacto de Google Fonts", "pesos": [...] }`
   - `estilo`: "sobrio" | "dinamico" · `mayusculas`: true/false · `radio` (esquinas, px) · `emojis`: false
   - `cta`: `{ "texto", "sub" }` o `null` · `textos.suscribir`: el texto del botón en el idioma del canal
3. `<carpeta del canal>/historial_elementos.md` copiado de `referencias/historial_elementos.md`.

## Actualizar la ficha
Cuando diga "actualizá mi ficha: …" (o cambie de opinión en medio de un video): cambiá SOLO lo pedido en `ficha-edicion.md` y en `tema.json`, anotalo en "Cambios pedidos" con la fecha, y confirmale en una línea qué cambió. Si el cambio afecta un video en curso, preguntá si se aplica también a ese.
