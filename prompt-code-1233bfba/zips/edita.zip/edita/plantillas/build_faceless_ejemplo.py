# EJEMPLO de guion visual para un video FACELESS en Remotion (escenas con imágenes + elementos encima).
# Copialo a la carpeta del video como build.py, junto con anclas.py, y ejecutalo parado ahí: python3 build.py
# Las imágenes van en editor/public/img/. Escribe editor/src/datos.json.
# Las frases de este ejemplo son de una narración de prueba: reemplazalas por las de tu transcripción.
import json
from anclas import A, DUR, palabras, revisar

SUBTITULOS = False
FORMATO = "16:9"
ES = []   # escenas: la pantalla SIEMPRE tiene una imagen moviéndose; una nueva cada 3–6 s (o cuando cambia la idea)
E = []    # elementos encima de las escenas
def escena(s, src, mov="in", trans="fundido", **k): ES.append({"s": round(s, 3), "src": src, "mov": mov, "trans": trans, **k})
def add(**k): E.append(k); return k

escena(0, "img/01-faro.jpg", "in", etiqueta="Imagen ilustrativa")
escena(A("un barco") - 0.1, "img/02-barco.jpg", "izq")
escena(A("Iba a llevar") - 0.1, "img/03-escalera.jpg", "arriba", "empuje")
escena(A("En la mesa") - 0.1, "img/04-mesa.jpg", "in")
escena(A("en la percha") - 0.1, "img/05-abrigo.jpg", "out")
escena(A("Los tres hombres") - 0.1, "", trans="flash", tipo="color")
escena(A("Más de 100") - 0.1, "img/06-noche.jpg", "in")
for i, x in enumerate(ES): x["e"] = ES[i + 1]["s"] if i + 1 < len(ES) else DUR   # cada escena dura hasta la siguiente

add(type="etiqueta", s=A("islas Flannan"), e=A("Iba a llevar") - 0.1, texto="Islas Flannan", sub="Escocia · diciembre de 1900", icono="mundo")
add(type="icono", s=A("tres guardianes"), e=A("Pero nadie") - 0.1, lado="centro", icono="persona", texto="[3] guardianes")
add(type="titulo", s=A("Pero nadie"), e=A("En la mesa") - 0.05, lado="centro", lineas=[{"t": "Nadie salió a [recibirlo]"}])
add(type="lista", s=A("platos servidos") - 0.2, e=A("Los tres hombres") - 0.1, lado="izq", numerada=False, titulo="Lo que encontraron",
    items=[{"t": "Platos servidos", "at": A("platos servidos"), "icono": "check"},
           {"t": "Una silla en el suelo", "at": A("una silla"), "icono": "check"},
           {"t": "Un solo abrigo", "at": A("un solo abrigo"), "icono": "check"}])
add(type="titulo", s=A("Los tres hombres"), e=A("Más de 100") - 0.05, lado="centro",
    lineas=[{"t": "Desaparecieron"}, {"t": "[sin dejar rastro]", "at": A("sin dejar")}])
add(type="linea", s=A("Más de 100") - 0.05, e=DUR, lado="abajo", puntos=[{"t": "1900", "d": "el barco llega", "at": A("Más de 100")}, {"t": "Hoy", "d": "sin respuesta", "at": A("nadie sabe")}])

D = {"modo": "faceless", "formato": FORMATO, "fps": 30, "dur": DUR, "escenas": ES, "elementos": E, "entrada": "foco",
     "ritmo_max": 6, "subtitulos": SUBTITULOS, "palabras": palabras() if SUBTITULOS else []}
problemas = revisar(D)
json.dump(D, open("editor/src/datos.json", "w"), ensure_ascii=False, indent=1)
print("editor/src/datos.json listo" + (" (revisá los PROBLEMAS antes de renderizar)" if problemas else ""))
