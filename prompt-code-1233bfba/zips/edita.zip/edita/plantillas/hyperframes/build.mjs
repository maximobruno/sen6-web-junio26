// Textos animados (kinetic typography) en HyperFrames: beats.json + tema.json -> index.html
// Uso (parado en <video>/hf/):  node build.mjs  ->  npx hyperframes check  ->  npx hyperframes render --output out/video_mudo.mp4
// Un beat = { t, layout, ... }. Dura hasta el t del siguiente. Editar un texto o un tiempo = tocar beats.json y volver a correr.
// Marcas en los textos: [palabras] = color de acento · {palabras} = subrayado.
// Layouts: frase, numero, lista, cita, capitulo, comparar, imagen. El video sale MUDO: la voz y la música se unen después.
import fs from "node:fs";

const B = JSON.parse(fs.readFileSync("beats.json", "utf8"));
const T = JSON.parse(fs.readFileSync("tema.json", "utf8"));
const VERT = B.formato === "9:16";
const W = VERT ? 1080 : 1920, H = VERT ? 1920 : 1080;
const TOTAL = B.dur;
const c = T.colores, ft = T.fuentes;
const may = T.mayusculas ? "uppercase" : "none";
const S = VERT ? 0.82 : 1; // escala de tipografía en vertical

const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const rich = (s) => esc(s).replace(/\[([^\]]+)\]/g, '<span class="hl">$1</span>').replace(/\{([^}]+)\}/g, '<span class="ul">$1</span>');
// palabra por palabra para animar en cascada; un [tramo] de varias palabras queda resaltado en cada una
function words(s) {
  const out = [], re = /\[([^\]]+)\]|\{([^}]+)\}/g; let last = 0, m;
  const push = (chunk, k) => chunk.split(/\s+/).filter(Boolean).forEach((w) => out.push(`<span class="w">${k ? `<span class="${k}">${esc(w)}</span>` : esc(w)}</span>`));
  while ((m = re.exec(s))) { push(s.slice(last, m.index), null); push(m[1] ?? m[2], m[1] != null ? "hl" : "ul"); last = m.index + m[0].length; }
  push(s.slice(last), null); return out.join(" ");
}
const fit = (text, base, min, perChar) => Math.round(S * Math.max(min, base - Math.max(0, String(text).replace(/[[\]{}]/g, "").length - 24) * perChar));

const L = {};
L.frase = (b, id) => ({
  html: `<div class="lay center">${b.kicker ? `<div class="kick" id="${id}-k">${esc(b.kicker)}</div>` : ""}<h1 class="big" id="${id}-h" style="font-size:${fit(b.texto, 120, 60, 1.3)}px">${words(b.texto)}</h1></div>`,
  tl: (t) => `${b.kicker ? `tl.fromTo("#${id}-k",{y:16,autoAlpha:0},{y:0,autoAlpha:1,duration:.3,ease:"power3.out"},${t});` : ""}
  tl.fromTo("#${id}-h .w",{y:60,autoAlpha:0},{y:0,autoAlpha:1,duration:.42,stagger:${b.stagger ?? 0.06},ease:"power4.out"},${t + 0.05});`,
});
L.numero = (b, id) => ({
  html: `<div class="lay center"><div class="fig" id="${id}-n">${esc(b.prefijo ?? "")}<span id="${id}-v">${esc(b.valor)}</span>${esc(b.sufijo ?? "")}</div>
  <div class="rule" id="${id}-r"></div><div class="cap" id="${id}-c">${rich(b.texto ?? "")}${b.ejemplo ? ' <span class="ej">EJEMPLO</span>' : ""}</div>${b.fuente ? `<div class="src">Fuente: ${esc(b.fuente)}</div>` : ""}</div>`,
  tl: (t) => `tl.fromTo("#${id}-n",{scale:1.3,autoAlpha:0},{scale:1,autoAlpha:1,duration:.5,ease:"power4.out"},${t});
  (function(){const o={v:${b.desde ?? 0}};tl.to(o,{v:${Number(b.valor)},duration:1,ease:"power2.out",onUpdate:()=>{document.querySelector("#${id}-v").textContent=Math.round(o.v).toLocaleString("es-AR")}},${t});})();
  tl.fromTo("#${id}-r",{scaleX:0},{scaleX:1,duration:.5,ease:"power3.inOut"},${t + 0.2});
  tl.fromTo("#${id}-c",{y:24,autoAlpha:0},{y:0,autoAlpha:1,duration:.4,ease:"power3.out"},${t + 0.3});`,
});
L.lista = (b, id) => ({
  html: `<div class="lay left">${b.titulo ? `<div class="kick" id="${id}-k">${esc(b.titulo)}</div>` : ""}${(b.items || []).map((it, i) => `<div class="li" id="${id}-i${i}"><span class="n">${String(i + 1).padStart(2, "0")}</span><span>${rich(it.t ?? it)}</span></div>`).join("")}</div>`,
  tl: (t) => `${b.titulo ? `tl.fromTo("#${id}-k",{x:-24,autoAlpha:0},{x:0,autoAlpha:1,duration:.3},${t});` : ""}
  ${(b.items || []).map((it, i) => `tl.fromTo("#${id}-i${i}",{x:-50,autoAlpha:0},{x:0,autoAlpha:1,duration:.4,ease:"power4.out"},${(it.at ?? t + 0.15 + i * 0.3).toFixed(2)});`).join("\n  ")}`,
});
L.cita = (b, id) => ({
  html: `<div class="lay center"><div class="card" id="${id}-c"><div class="qm">“</div><div class="qt" style="font-size:${fit(b.texto, 72, 44, 0.5)}px">${rich(b.texto)}</div>${b.autor ? `<div class="src">— ${esc(b.autor)}</div>` : ""}</div></div>`,
  tl: (t) => `tl.fromTo("#${id}-c",{x:80,autoAlpha:0},{x:0,autoAlpha:1,duration:.5,ease:"power4.out"},${t});`,
});
L.capitulo = (b, id) => ({
  html: `<div class="lay center"><div class="fill" id="${id}-f"></div><div class="kick inv" id="${id}-k">${esc(b.kicker ?? `CAPÍTULO ${b.n ?? ""}`)}</div><h1 class="big inv" id="${id}-h" style="font-size:${fit(b.texto, 120, 60, 1.3)}px">${words(b.texto)}</h1></div>`,
  tl: (t) => `tl.fromTo("#${id}-f",{scaleY:0},{scaleY:1,duration:.45,ease:"power4.inOut",transformOrigin:"50% 100%"},${t});
  tl.fromTo("#${id}-k",{autoAlpha:0,y:14},{autoAlpha:1,y:0,duration:.3},${t + 0.3});
  tl.fromTo("#${id}-h .w",{y:70,autoAlpha:0},{y:0,autoAlpha:1,duration:.42,stagger:.05,ease:"power4.out"},${t + 0.35});`,
});
L.comparar = (b, id) => ({
  html: `<div class="lay split"><div class="col" id="${id}-a"><div class="kick">${esc(b.a.titulo)}</div><div class="ct">${rich(b.a.texto)}</div></div><div class="div" id="${id}-d"></div><div class="col" id="${id}-b"><div class="kick hlk">${esc(b.b.titulo)}</div><div class="ct">${rich(b.b.texto)}</div></div></div>`,
  tl: (t) => `tl.fromTo("#${id}-a",{x:-60,autoAlpha:0},{x:0,autoAlpha:1,duration:.45,ease:"power4.out"},${t});
  tl.fromTo("#${id}-d",{scaleY:0},{scaleY:1,duration:.4},${t + 0.15});
  tl.fromTo("#${id}-b",{x:60,autoAlpha:0},{x:0,autoAlpha:1,duration:.45,ease:"power4.out"},${b.bAt ?? t + 0.6});`,
});
// imagen a sangre con acercamiento lento y un texto opcional abajo (las imágenes van en assets/img/)
L.imagen = (b, id, d) => ({
  html: `<div class="lay full"><img class="ph" id="${id}-p" src="${esc(b.src)}" alt=""><div class="shade"></div>${b.texto ? `<div class="ptxt" id="${id}-t">${words(b.texto)}</div>` : ""}${b.etiqueta ? `<div class="tag">${esc(b.etiqueta)}</div>` : ""}</div>`,
  tl: (t) => `tl.fromTo("#${id}-p",{scale:${b.mov === "out" ? 1.15 : 1}},{scale:${b.mov === "out" ? 1 : 1.15},duration:${d.toFixed(2)},ease:"none"},${t});
  ${b.texto ? `tl.fromTo("#${id}-t .w",{y:40,autoAlpha:0},{y:0,autoAlpha:1,duration:.4,stagger:.05,ease:"power4.out"},${(b.textoAt ?? t + 0.3).toFixed(2)});` : ""}`,
});

let clips = "", tls = "";
B.beats.forEach((b, i) => {
  const id = `b${i}`, t = b.t;
  const next = i + 1 < B.beats.length ? B.beats[i + 1].t : TOTAL;
  const d = Math.max(0.5, +(next - t).toFixed(2));
  const mk = L[b.layout]; if (!mk) throw new Error(`layout desconocido: ${b.layout} (beat ${i})`);
  const { html, tl } = mk(b, id, d);
  clips += `\n      <div class="clip" id="${id}" data-start="${t}" data-duration="${d}" data-track-index="2">${html}</div>`;
  tls += tl(t) + "\n";
});

const css = `${fs.existsSync("fuentes.css") ? fs.readFileSync("fuentes.css", "utf8") : ""}
* { margin:0; padding:0; box-sizing:border-box; }
html, body { width:${W}px; height:${H}px; overflow:hidden; background:${c.fondo}; }
body { font-family:"${ft.texto.familia}", sans-serif; color:${c.texto}; -webkit-font-smoothing:antialiased; }
.bg { position:absolute; inset:0; background: radial-gradient(${W * 0.7}px ${H * 0.7}px at 25% 30%, ${c.acento}1f, transparent 60%), radial-gradient(${W * 0.6}px ${H * 0.6}px at 85% 90%, ${c.acento2}14, transparent 60%), ${c.fondo}; }
.grain { position:absolute; inset:-50%; background-image: radial-gradient(rgba(255,255,255,.05) 1px, transparent 1px); background-size: 6px 6px; opacity:.5; }
.lay { position:absolute; inset:0; display:flex; flex-direction:column; justify-content:center; padding:${VERT ? "260px 90px 520px" : "0 180px"}; }
.center { align-items:center; text-align:center; } .left { align-items:flex-start; } .full { padding:0; }
.big { font-family:"${ft.titulos.familia}", sans-serif; font-weight:${Math.max(...ft.titulos.pesos)}; line-height:1.04; text-transform:${may}; letter-spacing:-.01em; }
.w { display:inline-block; }
.hl { color:${c.acento}; } .ul { text-decoration: underline; text-decoration-color:${c.acento}; text-decoration-thickness:.08em; text-underline-offset:.12em; }
.kick { font-weight:${Math.max(...ft.texto.pesos)}; font-size:${Math.round(28 * S)}px; letter-spacing:.2em; text-transform:uppercase; color:${c.acento}; margin-bottom:26px; }
.kick.hlk { color:${c.acento2}; }
.fig { font-family:"${ft.titulos.familia}", sans-serif; font-weight:${Math.max(...ft.titulos.pesos)}; font-size:${Math.round(240 * S)}px; line-height:1; color:${c.acento}; font-variant-numeric: tabular-nums; }
.rule { width:220px; height:6px; background:${c.acento}; margin:28px 0; }
.cap { font-size:${Math.round(52 * S)}px; font-weight:${Math.max(...ft.texto.pesos)}; max-width:1300px; }
.src { font-size:${Math.round(24 * S)}px; color:${c.suave}; margin-top:18px; }
.ej { font-size:20px; letter-spacing:2px; background:${c.acento2}; color:${c.fondo}; padding:4px 10px; border-radius:6px; vertical-align:middle; }
.li { display:flex; gap:28px; align-items:baseline; font-size:${Math.round(58 * S)}px; font-weight:${Math.max(...ft.texto.pesos)}; padding:14px 0; border-bottom:1px solid ${c.suave}33; width:100%; }
.li .n { font-family:"${ft.titulos.familia}", sans-serif; color:${c.acento}; font-size:.8em; }
.card { background:${c.superficie}; border-left:10px solid ${c.acento}; border-radius:${T.radio ?? 16}px; padding:50px 60px; max-width:1400px; text-align:left; }
.qm { font-family:"${ft.titulos.familia}", serif; font-size:140px; line-height:.6; color:${c.acento}; height:56px; }
.qt { font-weight:${Math.max(...ft.texto.pesos)}; line-height:1.25; }
.fill { position:absolute; inset:0; background:${c.acento}; }
.inv { color:${c.fondo}; position:relative; } .inv .hl { color:${c.texto}; }
.split { flex-direction:${VERT ? "column" : "row"}; align-items:center; gap:60px; }
.col { flex:1; } .ct { font-family:"${ft.titulos.familia}", sans-serif; font-weight:${Math.max(...ft.titulos.pesos)}; font-size:${Math.round(76 * S)}px; line-height:1.08; text-transform:${may}; }
.div { width:${VERT ? "60%" : "6px"}; height:${VERT ? "6px" : "60%"}; background:${c.acento}; }
.ph { position:absolute; inset:0; width:100%; height:100%; object-fit:cover; }
.shade { position:absolute; inset:0; background:linear-gradient(180deg, rgba(0,0,0,.25), rgba(0,0,0,0) 35%, rgba(0,0,0,0) 55%, rgba(0,0,0,.7)); }
.ptxt { position:absolute; left:${VERT ? 90 : 160}px; right:${VERT ? 160 : 160}px; bottom:${VERT ? 520 : 110}px; font-family:"${ft.titulos.familia}", sans-serif; font-weight:${Math.max(...ft.titulos.pesos)}; font-size:${Math.round(84 * S)}px; line-height:1.05; text-transform:${may}; text-shadow:0 4px 24px rgba(0,0,0,.6); }
.tag { position:absolute; right:${VERT ? 160 : 40}px; top:${VERT ? 260 : 36}px; font-size:20px; font-weight:700; background:rgba(0,0,0,.55); padding:6px 14px; border-radius:20px; }
.pbar { position:absolute; left:0; bottom:0; height:8px; width:100%; background:${c.suave}22; } .pbar i { display:block; height:100%; width:100%; background:${c.acento}; transform-origin:0 50%; }
`;

const html = `<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=${W}, height=${H}" />
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
    <style>${css}</style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="${TOTAL}" data-width="${W}" data-height="${H}">
      <div class="bg" id="fondo" data-track-index="0"><div class="grain" id="grano"></div></div>
${clips}
      ${B.barra !== false ? `<div class="pbar" id="barra" data-track-index="9"><i id="pb"></i></div>` : ""}
    </div>
    <script>
      window.__timelines = window.__timelines || {};
      const tl = gsap.timeline({ paused: true });
      tl.fromTo("#grano", {x:0, y:0}, {x:-40, y:30, duration:${TOTAL}, ease:"none"}, 0);
      ${B.barra !== false ? `tl.fromTo("#pb", {scaleX:0}, {scaleX:1, duration:${TOTAL}, ease:"none"}, 0);` : ""}
${tls}
      window.__timelines["main"] = tl;
    </script>
  </body>
</html>
`;
fs.writeFileSync("index.html", html);
console.log(`index.html: ${B.beats.length} beats, ${TOTAL}s, ${W}x${H}`);
