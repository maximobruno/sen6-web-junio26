# EJEMPLO: guion de textos animados (HyperFrames) anclado a la voz. Escribe hf/beats.json; después: cd hf && node build.mjs
# Copialo como build_hf.py a la carpeta del video, junto con anclas.py. Las imágenes van en hf/assets/img/.
import json
from anclas import A, DUR, revisar

FORMATO = "16:9"
BT = []
def beat(t, layout, **k): BT.append({"t": round(max(0, t), 2), "layout": layout, **k})

beat(0, "frase", kicker="Escocia · 1900", texto="Un barco llegó a las [islas Flannan]")
beat(A("Iba a llevar") - 0.1, "imagen", src="assets/img/03-escalera.jpg", texto="Tres guardianes del [faro]", textoAt=A("tres guardianes"))
beat(A("Pero nadie") - 0.1, "frase", texto="Nadie salió a [recibirlo]")
beat(A("En la mesa") - 0.1, "lista", titulo="Lo que encontraron",
     items=[{"t": "Platos servidos", "at": A("platos servidos")}, {"t": "Una silla en el suelo", "at": A("una silla")}, {"t": "Un [solo] abrigo", "at": A("un solo abrigo")}])
beat(A("Los tres hombres") - 0.1, "capitulo", kicker="SIN RASTRO", texto="Desaparecieron")
beat(A("Más de 100") - 0.1, "numero", valor=100, prefijo="+", sufijo=" años", texto="y nadie sabe {qué pasó esa noche}")

# misma revisión de ritmo que Remotion (cada beat cuenta como algo nuevo)
revisar({"modo": "faceless", "elementos": [], "acentos": [b["t"] for b in BT], "ritmo_max": 6})
json.dump({"formato": FORMATO, "dur": DUR, "beats": BT}, open("hf/beats.json", "w"), ensure_ascii=False, indent=1)
print(f"hf/beats.json: {len(BT)} beats")
