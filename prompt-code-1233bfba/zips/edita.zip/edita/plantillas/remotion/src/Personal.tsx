// Canal personal (cabeza parlante): el video del alumno de fondo + ventana que se achica + reencuadres + elementos.
// Regla: nada le tapa la cara. Si un elemento necesita el centro, se cambia la ventana (datos.ventana), no se tapa.
import React from "react";
import { AbsoluteFill, Easing, OffthreadVideo, spring, staticFile } from "remotion";
import D from "./datos.json";
import { Elementos } from "./Elementos";
import { C, TAM, VERT, lerp, ramp, useT } from "./ui";

type Geo = { x: number; y: number; w: number; h: number; r: number; zoom: number };
// Modos de ventana. 16:9: FULL, DER (video a la derecha), IZQ, ARRIBA (ventana chica arriba), ESQUINA.
// 9:16: FULL, ARRIBA (video arriba, contenido abajo), ABAJO (video abajo, contenido arriba).
const GEO: Record<string, Geo> = VERT
  ? {
      FULL: { x: 0, y: 0, w: 1080, h: 1920, r: 0, zoom: 1 },
      ARRIBA: { x: 70, y: 110, w: 940, h: 860, r: 34, zoom: 1.1 },
      ABAJO: { x: 70, y: 850, w: 940, h: 860, r: 34, zoom: 1.1 },
    }
  : {
      FULL: { x: 0, y: 0, w: 1920, h: 1080, r: 0, zoom: 1 },
      DER: { x: 1010, y: 90, w: 830, h: 900, r: 30, zoom: 1.08 },
      IZQ: { x: 80, y: 90, w: 830, h: 900, r: 30, zoom: 1.08 },
      ARRIBA: { x: 560, y: 36, w: 800, h: 470, r: 28, zoom: 1.05 },
      ESQUINA: { x: 1300, y: 600, w: 560, h: 420, r: 26, zoom: 1.15 },
    };

const VID = (D as { video?: { w: number; h: number } }).video ?? { w: 1920, h: 1080 };
const CARA = (D as { cara?: { x: number; y: number } }).cara ?? { x: VID.w / 2, y: VID.h * 0.4 };
const MODOS = ((D as { ventana?: [number, string][] }).ventana ?? [[0, "FULL"]]) as [number, string][];
const ACENTOS = ((D as { acentos?: number[] }).acentos ?? []) as number[];
const CORTES = ((D as { cortes?: number[] }).cortes ?? []) as number[];

// Ubica el video dentro de una ventana: lo agranda lo justo para cubrirla (sin bordes negros) y centra la cara.
const encuadre = (g: Geo, z: number) => {
  const s = Math.max(g.w / VID.w, g.h / VID.h) * g.zoom * z;
  const W = VID.w * s, H = VID.h * s;
  const left = Math.min(0, Math.max(g.w - W, g.w / 2 - CARA.x * s));
  const top = Math.min(0, Math.max(g.h - H, g.h * 0.45 - CARA.y * s));
  return { s, W, H, left, top };
};

export const Personal: React.FC = () => {
  const { t, f, fps } = useT();
  let k = 0;
  for (let i = 0; i < MODOS.length; i++) if (t >= MODOS[i][0]) k = i;
  const prev = GEO[k > 0 ? MODOS[k - 1][1] : MODOS[0][1]] ?? GEO.FULL;
  const next = GEO[MODOS[k][1]] ?? GEO.FULL;
  const p = k === 0 ? 1 : spring({ frame: f - Math.round(MODOS[k][0] * fps), fps, config: { damping: 18, stiffness: 120, mass: 0.85 } });
  const g = {} as Geo;
  (Object.keys(next) as (keyof Geo)[]).forEach((key) => (g[key] = lerp(prev[key], next[key], p)));

  // Reencuadres: golpe de zoom al arrancar, acercamientos en las frases clave y zoom alternado en cada corte
  let z = 1 + 0.12 * (1 - spring({ frame: f, fps, config: { damping: 16, stiffness: 140 } }));
  for (const at of ACENTOS) z += 0.09 * ramp(t, at - 0.05, at + 0.15) * (1 - ramp(t, at + 1.6, at + 2.4, Easing.inOut(Easing.cubic)));
  const seg = CORTES.filter((c) => t >= c).length;
  z *= seg % 2 === 1 ? 1.07 : 1;

  const e = encuadre(g, z);
  const ventana = Math.min(1, Math.max(0, (TAM.w - g.w) / 200));
  const video = { position: "absolute" as const, left: e.left, top: e.top, width: e.W, height: e.H };
  const fondo = encuadre(GEO.FULL, 1.25);
  return (
    <AbsoluteFill style={{ background: C.fondo }}>
      {ventana > 0.001 && (
        <AbsoluteFill style={{ opacity: ventana, overflow: "hidden" }}>
          <OffthreadVideo muted src={staticFile("video.mp4")} style={{ position: "absolute", left: fondo.left, top: fondo.top, width: fondo.W, height: fondo.H, filter: "blur(40px) brightness(0.32)" }} />
          <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 50%, ${C.acento}22, transparent 65%)` }} />
        </AbsoluteFill>
      )}
      <div
        style={{
          position: "absolute", left: g.x, top: g.y, width: g.w, height: g.h, borderRadius: g.r, overflow: "hidden",
          boxShadow: ventana > 0.01 ? `0 40px 100px rgba(0,0,0,${0.7 * ventana})` : "none",
          outline: ventana > 0.01 ? `2px solid rgba(255,255,255,${0.14 * ventana})` : "none",
        }}
      >
        <OffthreadVideo muted src={staticFile("video.mp4")} style={video} />
      </div>
      <Elementos />
    </AbsoluteFill>
  );
};
