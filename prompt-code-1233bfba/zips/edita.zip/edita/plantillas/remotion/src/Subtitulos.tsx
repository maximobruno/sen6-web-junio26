// Subtítulos quemados palabra por palabra (solo si la ficha dice "subtítulos: sí").
// Grupos cortos (máx. 4 palabras o hasta una pausa); la palabra que se está diciendo va en color de acento.
// En 9:16 quedan dentro de la zona segura (y ≈ 1180–1400) para que la interfaz de Reels/Shorts no los tape.
import React from "react";
import D from "./datos.json";
import { C, FT, MAY, PT, VERT, useT } from "./ui";

type P = { w: string; s: number; e: number };
const PAL = ((D as { palabras?: P[] }).palabras ?? []) as P[];
const GRUPOS: P[][] = [];
for (const p of PAL) {
  const g = GRUPOS[GRUPOS.length - 1];
  if (!g || g.length >= 4 || p.s - g[g.length - 1].e > 0.35 || /[.?!,]$/.test(g[g.length - 1].w)) GRUPOS.push([p]);
  else g.push(p);
}

export const Subtitulos: React.FC = () => {
  const { t } = useT();
  const g = GRUPOS.find((x, i) => t >= x[0].s - 0.05 && t < (GRUPOS[i + 1]?.[0].s ?? x[x.length - 1].e + 0.4));
  if (!g) return null;
  return (
    <div style={{ position: "absolute", left: VERT ? 70 : 160, right: VERT ? 140 : 160, top: VERT ? 1180 : 880, display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "0 18px", zIndex: 900 }}>
      {g.map((p, i) => (
        <span key={i} style={{ fontFamily: FT, fontWeight: PT, fontSize: VERT ? 74 : 62, textTransform: MAY, color: t >= p.s && t < p.e + 0.05 ? C.acento : "#fff", WebkitTextStroke: "2px rgba(0,0,0,0.85)", paintOrder: "stroke", textShadow: "0 6px 18px rgba(0,0,0,0.7)" }}>
          {p.w.replace(/[.,;:]$/, "")}
        </span>
      ))}
    </div>
  );
};
