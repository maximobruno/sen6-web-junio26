// Canal faceless: escenas (imágenes, capturas, clips) que cambian cada pocos segundos + elementos encima.
// Regla: la pantalla nunca queda vacía ni quieta. Cada escena se mueve (acercamiento lento / paneo).
import React from "react";
import { AbsoluteFill, Img, OffthreadVideo, staticFile } from "remotion";
import D from "./datos.json";
import { Elementos } from "./Elementos";
import { C, DINAMICO, FX, PXB, R, TAM, clamp01, ramp, useT } from "./ui";

type Escena = { s: number; e: number; src?: string; tipo?: "imagen" | "video" | "captura" | "color"; mov?: "in" | "out" | "izq" | "der" | "arriba" | "abajo"; trans?: "fundido" | "empuje" | "zoom" | "flash" | "corte"; etiqueta?: string; oscurecer?: number; foco?: string };
const ESC = ((D as { escenas?: Escena[] }).escenas ?? []) as Escena[];
const TR = 0.35;

const Media: React.FC<{ e: Escena; k: number }> = ({ e, k }) => {
  const m = e.mov ?? "in";
  const amp = DINAMICO ? 0.14 : 0.07;
  let sc = 1 + amp * k, x = 0, y = 0;
  if (m === "out") sc = 1 + amp - amp * k;
  if (m === "izq" || m === "der") { sc = 1 + amp; x = (m === "izq" ? -1 : 1) * (k - 0.5) * amp * TAM.w * 0.6; }
  if (m === "arriba" || m === "abajo") { sc = 1 + amp; y = (m === "arriba" ? -1 : 1) * (k - 0.5) * amp * TAM.h * 0.6; }
  const style: React.CSSProperties = { position: "absolute", width: "100%", height: "100%", objectFit: "cover", objectPosition: e.foco ?? "50% 50%", transform: `translate(${x}px, ${y}px) scale(${sc})` };
  if (!e.src || e.tipo === "color") return <AbsoluteFill style={{ background: `radial-gradient(circle at 30% 30%, ${C.superficie}, ${C.fondo})` }} />;
  if (e.tipo === "video" || /\.(mp4|mov|webm)$/i.test(e.src)) return <OffthreadVideo muted src={staticFile(e.src)} style={style} />;
  if (e.tipo === "captura") {
    // captura de pantalla: entera y legible sobre su propio fondo desenfocado
    return (
      <AbsoluteFill>
        <Img src={staticFile(e.src)} style={{ ...style, filter: "blur(36px) brightness(0.35)", transform: "scale(1.2)" }} />
        <AbsoluteFill style={{ padding: TAM.w > TAM.h ? "70px 160px" : "300px 60px", transform: `scale(${1 + amp * 0.5 * k})` }}>
          <Img src={staticFile(e.src)} style={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: R, filter: "drop-shadow(0 30px 60px rgba(0,0,0,.6))" }} />
        </AbsoluteFill>
      </AbsoluteFill>
    );
  }
  return <Img src={staticFile(e.src)} style={style} />;
};

export const Faceless: React.FC = () => {
  const { t } = useT();
  return (
    <AbsoluteFill style={{ background: C.fondo, overflow: "hidden" }}>
      {ESC.map((e, i) => {
        if (t < e.s - 0.01 || t > e.e + TR) return null;
        const k = clamp01((t - e.s) / Math.max(0.5, e.e - e.s + TR));
        const tr = i === 0 ? "corte" : e.trans ?? "fundido";
        const p = tr === "corte" ? 1 : ramp(t, e.s, e.s + TR);
        let tf = "", op = p;
        if (tr === "empuje") { tf = `translateX(${(1 - p) * TAM.w}px)`; op = 1; }
        if (tr === "zoom") tf = `scale(${1.25 - 0.25 * p})`;
        return (
          <AbsoluteFill key={i} style={{ opacity: op, transform: tf, zIndex: i }}>
            <Media e={e} k={k} />
            <AbsoluteFill style={{ background: `linear-gradient(180deg, rgba(0,0,0,${0.25 * (e.oscurecer ?? 1)}) 0%, rgba(0,0,0,0) 35%, rgba(0,0,0,0) 60%, rgba(0,0,0,${0.45 * (e.oscurecer ?? 1)}) 100%)` }} />
            {e.etiqueta && (
              <div style={{ position: "absolute", right: TAM.w > TAM.h ? 40 : 150, top: TAM.w > TAM.h ? 36 : 260, fontFamily: FX, fontWeight: PXB, fontSize: 20, color: "#fff", background: "rgba(0,0,0,0.55)", padding: "6px 14px", borderRadius: 20 }}>{e.etiqueta}</div>
            )}
            {tr === "flash" && <AbsoluteFill style={{ background: "#fff", opacity: 1 - ramp(t, e.s, e.s + 0.25) }} />}
          </AbsoluteFill>
        );
      })}
      <AbsoluteFill style={{ zIndex: 500 }}>
        <Elementos />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
