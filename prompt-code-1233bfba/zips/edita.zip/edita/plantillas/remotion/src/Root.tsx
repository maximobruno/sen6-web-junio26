import React from "react";
import { AbsoluteFill, Composition } from "remotion";
import "./fuentes";
import D from "./datos.json";
import { Personal } from "./Personal";
import { Faceless } from "./Faceless";
import { Subtitulos } from "./Subtitulos";
import { TAM } from "./ui";

// Una sola composición "Video": el modo (personal/faceless) y el formato (16:9 / 9:16) salen de datos.json,
// que escribe build.py. "Guia" es la misma con la zona segura de Reels/Shorts dibujada encima (solo para revisar).
const Video: React.FC = () => (
  <AbsoluteFill>
    {D.modo === "personal" ? <Personal /> : <Faceless />}
    {(D as { subtitulos?: boolean }).subtitulos ? <Subtitulos /> : null}
  </AbsoluteFill>
);

const Guia: React.FC = () => {
  const v = D.formato === "9:16";
  return (
    <AbsoluteFill>
      <Video />
      {v ? (
        <div style={{ position: "absolute", left: 60, top: 250, width: 880, height: 1210, border: "6px dashed #00E5FF" }} />
      ) : (
        <div style={{ position: "absolute", left: 96, top: 54, width: 1728, height: 972, border: "4px dashed #00E5FF" }} />
      )}
    </AbsoluteFill>
  );
};

export const Root: React.FC = () => {
  const { w, h } = TAM;
  const fps = D.fps ?? 30;
  const frames = Math.max(1, Math.ceil(D.dur * fps));
  return (
    <>
      <Composition id="Video" component={Video} durationInFrames={frames} fps={fps} width={w} height={h} />
      <Composition id="Guia" component={Guia} durationInFrames={frames} fps={fps} width={w} height={h} />
    </>
  );
};
