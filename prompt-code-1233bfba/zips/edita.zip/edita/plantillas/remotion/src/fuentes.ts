// Carga las tipografías del canal desde public/fonts (las baja scripts/fuentes.py según tema.json).
// El render espera a que estén cargadas (delayRender), así nunca sale un cuadro con la fuente equivocada.
import { continueRender, delayRender, staticFile } from "remotion";
import lista from "./fuentes.json";

const h = delayRender("cargando tipografías", { timeoutInMilliseconds: 90000 });
Promise.all(
  (lista as { family: string; weight: number; style: string; file: string }[]).map((f) =>
    new FontFace(f.family, `url(${staticFile("fonts/" + f.file)})`, { weight: String(f.weight), style: f.style })
      .load()
      .then((ff) => {
        document.fonts.add(ff);
      }),
  ),
)
  .catch((e) => console.error("No pude cargar una tipografía:", e))
  .finally(() => continueRender(h));
