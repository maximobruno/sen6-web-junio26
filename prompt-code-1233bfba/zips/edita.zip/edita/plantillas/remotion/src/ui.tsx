// Piezas comunes: tiempo, resortes, colores y fuentes del canal, íconos de trazo, áreas de pantalla y entradas.
import React from "react";
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import T from "./tema.json";
import D from "./datos.json";

// ---------- tema del canal (sale de la ficha de edición) ----------
export const C = T.colores;
export const FT = `"${T.fuentes.titulos.familia}", system-ui, sans-serif`;
export const FX = `"${T.fuentes.texto.familia}", system-ui, sans-serif`;
export const PT = Math.max(...T.fuentes.titulos.pesos);
export const PX = Math.min(...T.fuentes.texto.pesos);
export const PXB = Math.max(...T.fuentes.texto.pesos);
export const R = T.radio ?? 20;
export const MAY = T.mayusculas ? ("uppercase" as const) : ("none" as const);
export const DINAMICO = T.estilo !== "sobrio";
export const TEMA = T;

export const VERT = D.formato === "9:16";
export const TAM = VERT ? { w: 1080, h: 1920 } : { w: 1920, h: 1080 };

// ---------- tiempo ----------
export const useT = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return { t: f / fps, f, fps };
};
export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const ramp = (t: number, a: number, b: number, ease = Easing.out(Easing.cubic)) =>
  interpolate(t, [a, b], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });
export const useSpringAt = (at: number, cfg: { damping?: number; stiffness?: number; mass?: number } = {}) => {
  const { f, fps } = useT();
  return spring({ frame: f - Math.round(at * fps), fps, config: { damping: 14, stiffness: 170, mass: 0.6, ...cfg } });
};

// ---------- texto con acentos: [palabra] = color de acento · {palabra} = subrayado ----------
export const Rich: React.FC<{ t: string; color?: string }> = ({ t, color = C.acento }) => {
  const parts = t.split(/(\[[^\]]+\]|\{[^}]+\})/g).filter(Boolean);
  return (
    <>
      {parts.map((p, i) =>
        p.startsWith("[") ? (
          <span key={i} style={{ color }}>{p.slice(1, -1)}</span>
        ) : p.startsWith("{") ? (
          <span key={i} style={{ textDecoration: "underline", textDecorationColor: color, textDecorationThickness: "0.08em", textUnderlineOffset: "0.12em" }}>{p.slice(1, -1)}</span>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
};
export const plano = (t: string) => t.replace(/[[\]{}]/g, "");

// Texto que se escribe solo
export const Typed: React.FC<{ text: string; s: number; dur: number }> = ({ text, s, dur }) => {
  const { t } = useT();
  const ch = Array.from(text);
  const n = Math.round(clamp01((t - s) / Math.max(0.01, dur)) * ch.length);
  return (
    <span>
      {ch.slice(0, n).join("")}
      <span style={{ opacity: n < ch.length && t >= s && Math.floor(t * 4) % 2 === 0 ? 1 : 0, color: C.acento }}>|</span>
      <span style={{ color: "transparent" }}>{ch.slice(n).join("")}</span>
    </span>
  );
};

// ---------- íconos de trazo (sin emojis) ----------
const P: Record<string, string> = {
  check: "M5 12.5l4.5 4.5L19 7.5",
  x: "M6 6l12 12M18 6L6 18",
  candado: "M7 11V8a5 5 0 0110 0v3M5 11h14v10H5z",
  abierto: "M7 11V8a5 5 0 019.6-2M5 11h14v10H5z",
  play: "M8 5l11 7-11 7z",
  campana: "M6 17V11a6 6 0 0112 0v6l2 2H4zM10 21h4",
  estrella: "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z",
  reloj: "M12 3a9 9 0 110 18 9 9 0 010-18zM12 7v5l3.5 2",
  grafico: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  dinero: "M12 3v18M16.5 7.5c-.8-1.4-2.5-2-4.5-2-2.5 0-4 1.2-4 3s1.6 2.6 4 3 4 1.3 4 3.2-1.7 3.1-4.2 3.1c-2.1 0-3.8-.8-4.6-2.3",
  flecha: "M4 12h15M13 6l6 6-6 6",
  alerta: "M12 3l10 18H2zM12 10v5M12 18v.5",
  persona: "M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0",
  lupa: "M10.5 3a7.5 7.5 0 110 15 7.5 7.5 0 010-15zM16 16l5 5",
  idea: "M9 18h6M10 21h4M12 3a6 6 0 00-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0012 3z",
  corazon: "M12 20s-8-5-8-11a4.5 4.5 0 018-2.8A4.5 4.5 0 0120 9c0 6-8 11-8 11z",
  rayo: "M13 2L4 14h7l-1 8 9-12h-7z",
  mundo: "M12 3a9 9 0 110 18 9 9 0 010-18zM3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18",
  camara: "M3 8h4l2-3h6l2 3h4v12H3zM12 10.5a3.5 3.5 0 110 7 3.5 3.5 0 010-7z",
  mano: "M7 11V5.5a1.5 1.5 0 013 0V11m0-4.5a1.5 1.5 0 013 0V11m0-3.5a1.5 1.5 0 013 0V13a7 7 0 01-7 7h-.5A6.5 6.5 0 015 15.5L3.5 12a1.5 1.5 0 012.6-1.5L7 12",
  libro: "M4 5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zM4 21V5M8 7h7",
};
export const ICONOS = Object.keys(P);
export const Icono: React.FC<{ n: string; size?: number; color?: string; grosor?: number; dibujo?: number }> = ({ n, size = 48, color = C.texto, grosor = 2, dibujo = 1 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0, overflow: "visible" }}>
    <path d={P[n] ?? P.estrella} stroke={color} strokeWidth={grosor} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - dibujo} />
  </svg>
);

// ---------- áreas de pantalla ----------
export type Area = { x: number; y: number; w: number; h: number };
const AREAS_H: Record<string, Area> = {
  izq: { x: 90, y: 110, w: 820, h: 860 },
  der: { x: 1010, y: 110, w: 820, h: 860 },
  arriba: { x: 160, y: 50, w: 1600, h: 300 },
  abajo: { x: 160, y: 560, w: 1600, h: 460 },
  centro: { x: 240, y: 130, w: 1440, h: 820 },
  completo: { x: 0, y: 0, w: 1920, h: 1080 },
  abajo_esq: { x: 80, y: 860, w: 900, h: 150 },
  arriba_esq: { x: 70, y: 50, w: 640, h: 100 },
  ancho_izq: { x: 90, y: 110, w: 1150, h: 860 },
};
// 9:16: todo el texto dentro de la zona segura de Reels/Shorts (x 60–940, y 250–1460)
const AREAS_V: Record<string, Area> = {
  arriba: { x: 70, y: 250, w: 860, h: 560 },
  abajo: { x: 70, y: 1000, w: 860, h: 460 },
  centro: { x: 70, y: 250, w: 860, h: 1210 },
  completo: { x: 0, y: 0, w: 1080, h: 1920 },
  abajo_esq: { x: 70, y: 1290, w: 860, h: 170 },
  arriba_esq: { x: 70, y: 250, w: 620, h: 100 },
};
export const modoEn = (t: number): string => {
  const V = ((D as { ventana?: [number, string][] }).ventana ?? [[0, "FULL"]]) as [number, string][];
  let m = V[0][1];
  for (const [at, mm] of V) if (t >= at) m = mm;
  return m;
};
export const areaPara = (lado: string | undefined, s: number): Area => {
  let l = lado ?? "auto";
  if (l === "auto") {
    if (D.modo === "personal") {
      const m = modoEn(s + 0.2);
      const cara = (D as { cara?: { x: number; y: number } }).cara ?? { x: TAM.w / 2, y: TAM.h / 2 };
      l = VERT
        ? m === "ARRIBA" ? "abajo" : m === "ABAJO" ? "arriba" : cara.y > 960 ? "arriba" : "abajo"
        : m === "DER" ? "izq" : m === "IZQ" ? "der" : m === "ARRIBA" ? "abajo" : m === "ESQUINA" ? "ancho_izq" : cara.x > 960 ? "izq" : "der";
    } else l = "centro";
  }
  if (VERT) {
    const a = AREAS_V[l] ?? AREAS_V[l === "izq" ? "arriba" : l === "der" ? "abajo" : "centro"];
    // Personal vertical a pantalla completa: las zonas libres se calculan desde la cara (no tapar boca ni mentón)
    if (D.modo === "personal" && modoEn(s + 0.2) === "FULL") {
      const vid = (D as { video?: { w: number; h: number } }).video ?? { w: 1080, h: 1920 };
      const cara = (D as { cara?: { x: number; y: number } }).cara ?? { x: vid.w / 2, y: vid.h * 0.4 };
      const fy = cara.y * Math.max(1080 / vid.w, 1920 / vid.h);
      const M = ((D as { margen_cara?: number }).margen_cara ?? 300);
      if (a === AREAS_V.abajo || a === AREAS_V.abajo_esq) { const y = Math.max(a.y, fy + M); return { ...a, y, h: Math.max(160, 1460 - y) }; }
      if (a === AREAS_V.arriba) return { ...a, h: Math.max(160, Math.min(a.h, fy - M - a.y)) };
    }
    return a;
  }
  // Personal a pantalla completa: la cara queda centrada en x≈960 -> el lado libre llega hasta 220 px antes de la cara
  if (D.modo === "personal" && modoEn(s + 0.2) === "FULL" && (l === "izq" || l === "der")) {
    const MARGEN = ((D as { margen_cara?: number }).margen_cara ?? 230);
    return l === "izq" ? { x: 80, y: 110, w: 960 - MARGEN - 80, h: 860 } : { x: 960 + MARGEN, y: 110, w: 1920 - 80 - 960 - MARGEN, h: 860 };
  }
  return AREAS_H[l] ?? AREAS_H.centro;
};

// ---------- entradas (rotarlas entre videos: misma estética, otros movimientos) ----------
export type Entrada = "resorte" | "barrido" | "giro" | "foco" | "persiana" | "caida";
export const ENTRADA_DEF: Entrada = ((D as { entrada?: Entrada }).entrada ?? "resorte") as Entrada;

export const Caja: React.FC<{ s: number; e: number; area: Area; entrada?: Entrada; children: React.ReactNode; align?: "center" | "flex-start" | "flex-end"; z?: number }> = ({
  s, e, area, entrada = ENTRADA_DEF, children, align = "center", z = 10,
}) => {
  const { t } = useT();
  const p = useSpringAt(s, entrada === "caida" ? { damping: 10, stiffness: 160 } : {});
  const q = ramp(t, e - 0.28, e, Easing.in(Easing.cubic));
  if (t < s - 0.01 || t > e + 0.02) return null;
  let tr = "", clip: string | undefined, filter: string | undefined;
  const k = 1 - p;
  if (entrada === "resorte") tr = `scale(${0.75 + 0.25 * p}) translateY(${k * 30}px)`;
  if (entrada === "barrido") clip = `inset(0 ${k * 100}% 0 0 round ${R}px)`;
  if (entrada === "giro") tr = `perspective(1400px) rotateY(${k * 28}deg) translateX(${k * 60}px)`;
  if (entrada === "foco") { filter = `blur(${k * 16}px)`; tr = `scale(${1 + k * 0.08})`; }
  if (entrada === "persiana") clip = `inset(0 0 ${k * 100}% 0 round ${R}px)`;
  if (entrada === "caida") tr = `translateY(${k * -120}px)`;
  const salida = `translateY(${q * -24}px)`;
  return (
    <div style={{ position: "absolute", left: area.x, top: area.y, width: area.w, height: area.h, display: "flex", flexDirection: "column", justifyContent: align, alignItems: "stretch", zIndex: z }}>
      <div style={{ transform: `${tr} ${salida}`, clipPath: clip, filter, opacity: clamp01(p * 2) * (1 - q), transformOrigin: "50% 50%" }}>{children}</div>
    </div>
  );
};

// Tarjeta base con los colores del canal
export const Tarjeta: React.FC<{ children: React.ReactNode; style?: React.CSSProperties; claro?: boolean }> = ({ children, style, claro }) => (
  <div
    style={{
      background: claro ? C.texto : C.superficie,
      color: claro ? C.fondo : C.texto,
      borderRadius: R,
      padding: VERT ? "34px 38px" : "38px 46px",
      boxShadow: "0 30px 80px rgba(0,0,0,0.45)",
      border: `1px solid ${claro ? "transparent" : "rgba(255,255,255,0.08)"}`,
      fontFamily: FX,
      ...style,
    }}
  >
    {children}
  </div>
);

// Sello "EJEMPLO": todo dato inventado lo lleva en pantalla
export const Ejemplo: React.FC<{ texto?: string }> = ({ texto = "EJEMPLO" }) => (
  <span style={{ fontFamily: FX, fontWeight: PXB, fontSize: 18, letterSpacing: 2, color: C.fondo, background: C.acento2, padding: "4px 10px", borderRadius: 6, marginLeft: 12, verticalAlign: "middle" }}>{texto}</span>
);
