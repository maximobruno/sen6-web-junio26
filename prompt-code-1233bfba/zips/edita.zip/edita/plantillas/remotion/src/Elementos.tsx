// Catálogo de elementos. build.py los pide por "type" en datos.json -> elementos.
// Todos usan los colores y fuentes del canal (tema.json). Ver referencias/estilos.md para cuándo usar cada uno.
import React from "react";
import { Img, OffthreadVideo, staticFile } from "remotion";
import D from "./datos.json";
import { Area, C, Caja, DINAMICO, Ejemplo, Entrada, FT, FX, Icono, MAY, PT, PX, PXB, R, Rich, TEMA, Tarjeta, Typed, VERT, areaPara, clamp01, ramp, useSpringAt, useT } from "./ui";

export type B = { type: string; s: number; e: number; lado?: string; entrada?: Entrada; [k: string]: any };
type El = React.FC<{ b: B; a: Area }>;

const tam = (base: number) => (VERT ? base * 0.92 : base);
const Kicker: React.FC<{ t?: string }> = ({ t }) =>
  t ? <div style={{ fontFamily: FX, fontWeight: PXB, fontSize: tam(24), letterSpacing: 4, textTransform: "uppercase", color: C.acento, marginBottom: 14 }}>{t}</div> : null;

// Raya que tacha un texto en el momento "at"
const Tachado: React.FC<{ at?: number; color?: string }> = ({ at, color = C.error }) => {
  const { t } = useT();
  if (at == null) return null;
  const p = ramp(t, at, at + 0.35);
  return <div style={{ position: "absolute", left: -6, top: "52%", height: 7, width: `calc(${p * 100}% + 12px)`, background: color, borderRadius: 4, transform: "rotate(-2deg)" }} />;
};

// 1. TITULO: frase grande, palabra por palabra. lineas: [{t, at?, tachar?, chico?}]
const Titulo: El = ({ b }) => {
  const { t } = useT();
  const lineas: { t: string; at?: number; tachar?: number; chico?: boolean }[] = b.lineas ?? [{ t: b.texto }];
  const big = b.lado === "completo" || b.lado === "centro";
  const base = tam(big ? 104 : 78);
  return (
    <div style={{ fontFamily: FT, fontWeight: PT, color: C.texto, textTransform: MAY, lineHeight: 1.05, textAlign: big ? "center" : "left", padding: big ? "0 60px" : 0, textShadow: "0 4px 24px rgba(0,0,0,0.6), 0 1px 3px rgba(0,0,0,0.5)" }}>
      <Kicker t={b.kicker} />
      {lineas.map((l, i) => {
        const at = l.at ?? b.s + i * 0.35;
        // palabras sueltas, pero un [tramo con acento] de varias palabras conserva su acento en cada una
        const words: string[] = [];
        for (const m of l.t.match(/\[[^\]]+\]|\{[^}]+\}|[^\s[{]+/g) ?? []) {
          if (m.startsWith("[") || m.startsWith("{")) { const o = m[0], c = m[m.length - 1]; m.slice(1, -1).split(" ").forEach((x) => words.push(o + x + c)); }
          else words.push(m);
        }
        return (
          <div key={i} style={{ position: "relative", display: "inline-block", fontSize: l.chico ? base * 0.55 : base, margin: "6px 0", width: "100%" }}>
            {words.map((w, j) => {
              const p = clamp01((t - at - j * 0.06) / 0.22);
              return (
                <span key={j} style={{ display: "inline-block", opacity: p, transform: `translateY(${(1 - p) * 30}px)`, marginRight: "0.25em" }}>
                  <Rich t={w} />
                </span>
              );
            })}
            <Tachado at={l.tachar} />
          </div>
        );
      })}
    </div>
  );
};

// 2. NUMERO: cifra que cuenta. valor, desde?, prefijo?, sufijo?, decimales?, etiqueta?, ejemplo?, fuente?
const Numero: El = ({ b, a }) => {
  const { t } = useT();
  const finalTxt = `${b.prefijo ?? ""}${Number(b.valor).toLocaleString("es-AR", { minimumFractionDigits: b.decimales ?? 0, maximumFractionDigits: b.decimales ?? 0 })}${b.sufijo ?? ""}`;
  const fs = Math.min(tam(170), (a.w - 100) / (finalTxt.length * 0.52));   // nunca parte la cifra en dos renglones
  const p = ramp(t, b.s + 0.15, b.s + 1.1);
  const v = (b.desde ?? 0) + (b.valor - (b.desde ?? 0)) * p;
  const txt = v.toLocaleString("es-AR", { minimumFractionDigits: b.decimales ?? 0, maximumFractionDigits: b.decimales ?? 0 });
  return (
    <Tarjeta style={{ textAlign: "center" }}>
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: fs, lineHeight: 1, color: C.acento, fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>
        {b.prefijo ?? ""}{txt}{b.sufijo ?? ""}
      </div>
      {b.etiqueta && <div style={{ fontSize: tam(38), fontWeight: PXB, marginTop: 14 }}><Rich t={b.etiqueta} />{b.ejemplo && <Ejemplo />}</div>}
      {!b.etiqueta && b.ejemplo && <Ejemplo />}
      {b.fuente && <div style={{ fontSize: tam(22), color: C.suave, marginTop: 12 }}>Fuente: {b.fuente}</div>}
    </Tarjeta>
  );
};

// 3. LISTA: items: [{t, at, tachar?, icono?}], titulo?, numerada?
const Lista: El = ({ b }) => {
  const { t } = useT();
  const items: { t: string; at: number; tachar?: number; icono?: string }[] = b.items;
  return (
    <Tarjeta>
      {b.titulo && <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(50), textTransform: MAY, marginBottom: 18 }}><Rich t={b.titulo} /></div>}
      {items.map((it, i) => {
        const p = clamp01((t - it.at) / 0.25);
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 20, padding: "12px 0", opacity: 0.15 + 0.85 * p, transform: `translateX(${(1 - p) * -30}px)`, borderTop: i ? "1px solid rgba(255,255,255,0.08)" : "none" }}>
            {b.numerada !== false && !it.icono ? (
              <div style={{ width: tam(54), height: tam(54), borderRadius: tam(27), background: p > 0.5 ? C.acento : "transparent", border: `2px solid ${C.acento}`, color: p > 0.5 ? C.fondo : C.acento, fontFamily: FT, fontWeight: PT, fontSize: tam(28), display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{i + 1}</div>
            ) : (
              <Icono n={it.icono ?? "check"} size={tam(46)} color={C.acento} grosor={2.4} dibujo={p} />
            )}
            <div style={{ position: "relative", fontSize: tam(38), fontWeight: PXB, lineHeight: 1.2 }}><Rich t={it.t} /><Tachado at={it.tachar} /></div>
          </div>
        );
      })}
    </Tarjeta>
  );
};

// 4. CAPTURA: imagen o video de public/. marco: navegador | celular | ninguno. url?, etiqueta?, zoom: in|out
const Captura: El = ({ b, a }) => {
  const { t } = useT();
  const k = clamp01((t - b.s) / Math.max(0.5, b.e - b.s));
  const z = b.zoom === "out" ? 1.12 - 0.12 * k : 1 + 0.1 * k;
  const esVideo = /\.(mp4|mov|webm)$/i.test(b.src);
  const media = esVideo ? (
    <OffthreadVideo muted src={staticFile(b.src)} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
  ) : (
    <Img src={staticFile(b.src)} style={{ width: "100%", height: "100%", objectFit: b.ajuste ?? "cover", objectPosition: b.foco ?? "50% 0%" }} />
  );
  const cel = b.marco === "celular";
  const W = cel ? Math.min(a.w, a.h * 0.5) : a.w;
  const H = cel ? W * 2 : Math.min(a.h - (b.etiqueta ? 70 : 0), a.w * 0.62);
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div style={{ width: W, height: H, borderRadius: cel ? 44 : R, overflow: "hidden", background: "#111", border: cel ? "12px solid #111" : "none", boxShadow: "0 30px 90px rgba(0,0,0,0.55)", display: "flex", flexDirection: "column" }}>
        {b.marco === "navegador" && (
          <div style={{ height: 46, background: "#E9E9EC", display: "flex", alignItems: "center", gap: 9, padding: "0 16px", flexShrink: 0 }}>
            {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <div key={c} style={{ width: 13, height: 13, borderRadius: 7, background: c }} />)}
            <div style={{ marginLeft: 14, flex: 1, height: 28, borderRadius: 14, background: "#fff", fontFamily: FX, fontSize: 17, color: "#555", display: "flex", alignItems: "center", padding: "0 14px" }}>{b.url ?? ""}</div>
          </div>
        )}
        <div style={{ flex: 1, overflow: "hidden" }}>
          <div style={{ width: "100%", height: "100%", transform: `scale(${z})`, transformOrigin: b.foco ?? "50% 0%" }}>{media}</div>
        </div>
      </div>
      {b.etiqueta && (
        <div style={{ marginTop: 16, fontFamily: FX, fontWeight: PXB, fontSize: tam(24), color: C.texto, background: "rgba(0,0,0,0.55)", padding: "8px 18px", borderRadius: 30 }}>{b.etiqueta}</div>
      )}
    </div>
  );
};

// 5. CITA: texto, autor?
const Cita: El = ({ b }) => (
  <Tarjeta style={{ borderLeft: `10px solid ${C.acento}` }}>
    <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(120), lineHeight: 0.6, color: C.acento, height: 50 }}>"</div>
    <div style={{ fontSize: tam(46), fontWeight: PXB, lineHeight: 1.25 }}><Rich t={b.texto} /></div>
    {b.autor && <div style={{ fontSize: tam(26), color: C.suave, marginTop: 18 }}>— {b.autor}</div>}
  </Tarjeta>
);

// 6. CHIPS: chips: [{t, at}], titulo?
const Chips: El = ({ b }) => {
  const { t } = useT();
  return (
    <div>
      {b.titulo && <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(48), color: C.texto, textTransform: MAY, marginBottom: 18, textShadow: "0 4px 20px rgba(0,0,0,0.5)" }}><Rich t={b.titulo} /></div>}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 14 }}>
        {(b.chips as { t: string; at: number }[]).map((c, i) => {
          const p = clamp01((t - c.at) / 0.2);
          return (
            <div key={i} style={{ fontFamily: FX, fontWeight: PXB, fontSize: tam(32), padding: "12px 24px", borderRadius: 40, background: i === b.activo ? C.acento : C.superficie, color: i === b.activo ? C.fondo : C.texto, opacity: p, transform: `scale(${0.7 + 0.3 * p})`, boxShadow: "0 10px 30px rgba(0,0,0,0.35)" }}>{c.t}</div>
          );
        })}
      </div>
    </div>
  );
};

// 7. ETIQUETA (zócalo): texto, sub?, icono?
const Etiqueta: El = ({ b }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 18, background: C.superficie, borderRadius: R, padding: "16px 26px", boxShadow: "0 16px 40px rgba(0,0,0,0.45)", borderLeft: `8px solid ${C.acento}`, alignSelf: "flex-start" }}>
    {b.icono && <Icono n={b.icono} size={tam(44)} color={C.acento} grosor={2.4} />}
    <div>
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(38), color: C.texto, textTransform: MAY }}><Rich t={b.texto} /></div>
      {b.sub && <div style={{ fontFamily: FX, fontWeight: PX, fontSize: tam(24), color: C.suave, marginTop: 4 }}>{b.sub}</div>}
    </div>
  </div>
);

// 8. BARRAS: barras: [{t, v, at?, resaltar?}], titulo?, unidad?, ejemplo?
const Barras: El = ({ b }) => {
  const { t } = useT();
  const bs: { t: string; v: number; at?: number; resaltar?: boolean }[] = b.barras;
  const mx = Math.max(...bs.map((x) => x.v));
  return (
    <Tarjeta>
      {b.titulo && <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(46), textTransform: MAY, marginBottom: 22 }}><Rich t={b.titulo} />{b.ejemplo && <Ejemplo />}</div>}
      {bs.map((x, i) => {
        const at = x.at ?? b.s + 0.3 + i * 0.25;
        const p = ramp(t, at, at + 0.7);
        return (
          <div key={i} style={{ marginBottom: 18 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: tam(28), fontWeight: PXB, marginBottom: 8 }}>
              <span>{x.t}</span>
              <span style={{ color: x.resaltar ? C.acento : C.suave, fontVariantNumeric: "tabular-nums" }}>{Math.round(x.v * p).toLocaleString("es-AR")}{b.unidad ?? ""}</span>
            </div>
            <div style={{ height: tam(30), borderRadius: 15, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${(x.v / mx) * 100 * p}%`, background: x.resaltar ? C.acento : C.suave, borderRadius: 15 }} />
            </div>
          </div>
        );
      })}
      {!b.titulo && b.ejemplo && <Ejemplo />}
    </Tarjeta>
  );
};

// 9. COMPARAR: a: {titulo, items[]}, b: {titulo, items[]}, bAt?, ganador?: "a" | "b"
const Comparar: El = ({ b }) => {
  const { t } = useT();
  const col = (d: { titulo: string; items: string[] }, at: number, gana: boolean, mal: boolean) => {
    const p = clamp01((t - at) / 0.3);
    return (
      <Tarjeta style={{ flex: 1, opacity: p, transform: `translateY(${(1 - p) * 40}px)`, border: gana ? `3px solid ${C.ok}` : undefined }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, fontFamily: FT, fontWeight: PT, fontSize: tam(42), textTransform: MAY, marginBottom: 14 }}>
          <Icono n={mal ? "x" : "check"} size={tam(40)} color={mal ? C.error : C.ok} grosor={3} />
          <Rich t={d.titulo} />
        </div>
        {d.items.map((x, i) => <div key={i} style={{ fontSize: tam(30), fontWeight: PX, padding: "8px 0", color: C.suave }}><Rich t={x} /></div>)}
      </Tarjeta>
    );
  };
  return (
    <div style={{ display: "flex", flexDirection: VERT || b.lado === "izq" || b.lado === "der" ? "column" : "row", gap: 24 }}>
      {col(b.a, b.s, b.ganador === "a", b.ganador === "b")}
      {col(b.b, b.bAt ?? b.s + 0.6, b.ganador === "b", b.ganador === "a")}
    </div>
  );
};

// 10. PASO: n, total?, titulo, sub?
const Paso: El = ({ b }) => {
  const p = useSpringAt(b.s + 0.1);
  return (
    <Tarjeta style={{ display: "flex", alignItems: "center", gap: 30 }}>
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(150), lineHeight: 1, color: "transparent", WebkitTextStroke: `3px ${C.acento}`, position: "relative" }}>
        {b.n}
        <div style={{ position: "absolute", inset: 0, color: C.acento, clipPath: `inset(${(1 - p) * 100}% 0 0 0)` }}>{b.n}</div>
      </div>
      <div>
        <div style={{ fontFamily: FX, fontWeight: PXB, fontSize: tam(24), letterSpacing: 4, color: C.suave }}>PASO {b.n}{b.total ? ` DE ${b.total}` : ""}</div>
        <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(56), textTransform: MAY, lineHeight: 1.05 }}><Rich t={b.titulo} /></div>
        {b.sub && <div style={{ fontSize: tam(28), color: C.suave, marginTop: 8 }}>{b.sub}</div>}
      </div>
    </Tarjeta>
  );
};

// 11. CAPITULO: pantalla completa (tapa todo 2–3 s, es un corte, no un gráfico encima). n, titulo
const Capitulo: El = ({ b }) => {
  const { t } = useT();
  const w = ramp(t, b.s, b.s + 0.45);
  const out = ramp(t, b.e - 0.4, b.e);
  return (
    <div style={{ position: "absolute", inset: 0, background: C.fondo, clipPath: `inset(0 ${(1 - w) * 100}% 0 ${out * 100}%)`, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      <div style={{ fontFamily: FX, fontWeight: PXB, fontSize: tam(32), letterSpacing: 8, color: C.acento }}>CAPÍTULO {b.n}</div>
      <div style={{ width: 120 * ramp(t, b.s + 0.3, b.s + 0.8), height: 6, background: C.acento, margin: "22px 0" }} />
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(110), color: C.texto, textTransform: MAY, textAlign: "center", padding: "0 80px", lineHeight: 1.02 }}><Rich t={b.titulo} /></div>
    </div>
  );
};

// 12. LINEA de tiempo: puntos: [{t, d?, at}]
const Linea: El = ({ b }) => {
  const { t } = useT();
  const ps: { t: string; d?: string; at: number }[] = b.puntos;
  const last = ps[ps.length - 1].at;
  const p = ramp(t, b.s, last + 0.4);
  return (
    <Tarjeta>
      {b.titulo && <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(44), textTransform: MAY, marginBottom: 30 }}><Rich t={b.titulo} /></div>}
      <div style={{ position: "relative", height: 8, background: "rgba(255,255,255,0.1)", borderRadius: 4, margin: "40px 30px 0" }}>
        <div style={{ position: "absolute", left: 0, top: 0, height: 8, width: `${p * 100}%`, background: C.acento, borderRadius: 4 }} />
        {ps.map((x, i) => {
          const q = clamp01((t - x.at) / 0.25);
          const left = ps.length === 1 ? 50 : (i / (ps.length - 1)) * 100;
          return (
            <div key={i} style={{ position: "absolute", left: `${left}%`, top: -14, transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", width: 260 }}>
              <div style={{ width: 36, height: 36, borderRadius: 18, background: q > 0.5 ? C.acento : C.superficie, border: `4px solid ${C.acento}`, transform: `scale(${0.6 + 0.4 * q})` }} />
              <div style={{ opacity: q, fontFamily: FT, fontWeight: PT, fontSize: tam(40), marginTop: 14 }}>{x.t}</div>
              {x.d && <div style={{ opacity: q, fontSize: tam(22), color: C.suave, textAlign: "center", marginTop: 4 }}>{x.d}</div>}
            </div>
          );
        })}
      </div>
      <div style={{ height: 150 }} />
    </Tarjeta>
  );
};

// 13. ALERTA: texto, sub?
const Alerta: El = ({ b }) => {
  const { t } = useT();
  const sh = DINAMICO ? Math.sin((t - b.s) * 40) * 6 * clamp01(1 - (t - b.s) / 0.4) : 0;
  return (
    <Tarjeta style={{ display: "flex", alignItems: "center", gap: 26, border: `3px solid ${C.error}`, transform: `translateX(${sh}px)` }}>
      <Icono n="alerta" size={tam(80)} color={C.error} grosor={2.2} />
      <div>
        <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(52), textTransform: MAY, lineHeight: 1.05 }}><Rich t={b.texto} color={C.error} /></div>
        {b.sub && <div style={{ fontSize: tam(28), color: C.suave, marginTop: 8 }}>{b.sub}</div>}
      </div>
    </Tarjeta>
  );
};

// 14. ICONO grande + palabra (miniatura simbólica): icono, texto, sub?
const IconoGrande: El = ({ b }) => {
  const { t } = useT();
  const d = ramp(t, b.s + 0.05, b.s + 0.8);
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
      <div style={{ width: tam(230), height: tam(230), borderRadius: tam(115), background: C.superficie, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 0 10px ${C.acento}33, 0 30px 80px rgba(0,0,0,0.5)` }}>
        <Icono n={b.icono} size={tam(130)} color={C.acento} grosor={1.8} dibujo={d} />
      </div>
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(70), color: C.texto, textTransform: MAY, marginTop: 26, textShadow: "0 4px 20px rgba(0,0,0,0.55)" }}><Rich t={b.texto} /></div>
      {b.sub && <div style={{ fontFamily: FX, fontSize: tam(30), color: C.suave, marginTop: 6 }}>{b.sub}</div>}
    </div>
  );
};

// 15. PROGRESO: actual, total, etiqueta?  (píldora en la esquina; dejala varios bloques seguidos)
const Progreso: El = ({ b }) => (
  <div style={{ display: "inline-flex", alignItems: "center", gap: 14, alignSelf: "flex-start", background: "rgba(0,0,0,0.6)", borderRadius: 40, padding: "10px 22px", fontFamily: FX, fontWeight: PXB, fontSize: tam(26), color: C.texto }}>
    <div style={{ display: "flex", gap: 6 }}>
      {Array.from({ length: b.total }).map((_, i) => <div key={i} style={{ width: 26, height: 8, borderRadius: 4, background: i < b.actual ? C.acento : "rgba(255,255,255,0.2)" }} />)}
    </div>
    {b.etiqueta ?? `${b.actual}/${b.total}`}
  </div>
);

// 16. SUSCRIBIR: botón + cursor + campana. clicAt?, campanaAt?
const Suscribir: El = ({ b }) => {
  const { t } = useT();
  const clic = b.clicAt ?? b.s + 0.9;
  const camp = b.campanaAt ?? clic + 0.8;
  const hecho = t >= clic;
  const cx = t < clic ? ramp(t, b.s + 0.2, clic) : ramp(t, clic + 0.2, camp);
  const curX = t < clic ? 300 - 140 * cx : 160 + 230 * cx;
  const curY = t < clic ? 160 - 120 * cx : 40;
  const ring = t > camp && t < camp + 1 ? Math.sin((t - camp) * 26) * 18 * (1 - (t - camp)) : 0;
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 18, alignSelf: "center" }}>
      <div style={{ fontFamily: FX, fontWeight: PXB, fontSize: tam(40), padding: "18px 40px", borderRadius: 50, background: hecho ? C.superficie : C.texto, color: hecho ? C.texto : C.fondo, transform: `scale(${t > clic && t < clic + 0.15 ? 0.94 : 1})` }}>
        {hecho ? "Suscrito" : TEMA.textos?.suscribir ?? "Suscribirme"}
      </div>
      <div style={{ width: tam(80), height: tam(80), borderRadius: 40, background: C.superficie, display: "flex", alignItems: "center", justifyContent: "center", transform: `rotate(${ring}deg)`, opacity: hecho ? 1 : 0.4 }}>
        <Icono n="campana" size={tam(44)} color={t > camp ? C.acento : C.texto} grosor={2.4} />
      </div>
      <svg width="46" height="46" viewBox="0 0 24 24" style={{ position: "absolute", left: curX, top: curY, filter: "drop-shadow(0 4px 6px rgba(0,0,0,.5))" }}>
        <path d="M4 2l16 9-7 2-3 7z" fill="#fff" stroke="#000" strokeWidth="1.2" strokeLinejoin="round" />
      </svg>
    </div>
  );
};

// 17. CTA propio del canal (tema.json -> cta): texto?, sub?
const Cta: El = ({ b }) => {
  const cta = (TEMA as { cta?: { texto: string; sub?: string } }).cta ?? { texto: "Gracias por ver" };
  return (
    <Tarjeta style={{ textAlign: "center", border: `3px solid ${C.acento}` }}>
      <div style={{ fontFamily: FT, fontWeight: PT, fontSize: tam(62), textTransform: MAY, lineHeight: 1.05 }}><Rich t={b.texto ?? cta.texto} /></div>
      {(b.sub ?? cta.sub) && <div style={{ fontSize: tam(30), color: C.suave, marginTop: 12 }}><Typed text={b.sub ?? cta.sub} s={b.s + 0.5} dur={0.9} /></div>}
    </Tarjeta>
  );
};

export const MAPA: Record<string, El> = {
  titulo: Titulo, numero: Numero, lista: Lista, captura: Captura, cita: Cita, chips: Chips, etiqueta: Etiqueta, barras: Barras,
  comparar: Comparar, paso: Paso, capitulo: Capitulo, linea: Linea, alerta: Alerta, icono: IconoGrande, progreso: Progreso,
  suscribir: Suscribir, cta: Cta,
};
const LADO_DEF: Record<string, string> = { etiqueta: "abajo_esq", progreso: "arriba_esq", capitulo: "completo" };

export const Elementos: React.FC = () => {
  const { t } = useT();
  const els = (D.elementos ?? []) as B[];
  return (
    <>
      {els
        .filter((b) => t >= b.s - 0.05 && t <= b.e + 0.05)
        .map((b, i) => {
          const E = MAPA[b.type];
          if (!E) return null;
          const a = areaPara(b.lado ?? LADO_DEF[b.type], b.s);
          if (b.type === "capitulo") return <E key={`${b.type}-${b.s}-${i}`} b={b} a={a} />;
          return (
            <Caja key={`${b.type}-${b.s}-${i}`} s={b.s} e={b.e} area={a} entrada={b.entrada} align={b.type === "etiqueta" || b.type === "progreso" ? "flex-start" : "center"} z={b.type === "progreso" ? 30 : 10}>
              <E b={b} a={a} />
            </Caja>
          );
        })}
    </>
  );
};
