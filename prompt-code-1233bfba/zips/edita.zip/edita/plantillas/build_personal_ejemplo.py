# EJEMPLO de guion visual para un video PERSONAL (cabeza parlante, 16:9).
# Copialo a la carpeta del video como build.py, junto con anclas.py, y ejecutalo parado ahí: python3 build.py
# Cada elemento queda pegado a la frase EXACTA que se dice (A("frase")). Escribe editor/src/datos.json.
# Las frases de este ejemplo son de un video de prueba: reemplazalas por las de tu transcripción.
import json, subprocess
from anclas import A, DUR, cortes, palabras, revisar

TEMA = json.load(open("../tema.json"))          # colores y fuentes del canal (de la ficha)
SUBTITULOS = False                               # sale de la ficha ("subtítulos: sí/no")
FORMATO = "16:9"                                 # "9:16" para Shorts/Reels
CARA = {"x": 975, "y": 470}                      # centro de la cara en el cuadro, medido en work/cuadro.jpg
w, h = map(int, subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", "editor/public/video.mp4"], capture_output=True, text=True).stdout.strip().split(","))

E = []                      # elementos
V = [(0, "FULL")]           # ventana: FULL / DER (video a la derecha) / IZQ / ARRIBA / ESQUINA  (9:16: FULL / ARRIBA / ABAJO)
AC = []                     # acentos: acercamientos de la toma en frases clave
def add(**k): E.append(k); return k
def ventana(t, m): V.append((round(t, 2), m))

# --- gancho: las marcas aparecen mientras las nombra (video a pantalla completa, gráfico del lado libre)
add(type="chips", s=A("Microsoft") - 0.1, e=A("casi 2000") - 0.15, lado="izq", titulo="Intentaron [destronar] a YouTube",
    chips=[{"t": "Microsoft", "at": A("Microsoft")}, {"t": "Twitter", "at": A("Twitter")}, {"t": "TikTok", "at": A("TikTok")}, {"t": "Disney", "at": A("Disney")}])
add(type="numero", s=A("casi 2000") - 0.1, e=A("Hay una sola") - 0.1, lado="izq", valor=2000, prefijo="US$ ", sufijo=" M", etiqueta="para destronar a [YouTube]")
AC.append(A("destronar"))

# --- promesa: el video se corre a la derecha y la lista ocupa la izquierda
ventana(A("Hay una sola") - 0.2, "DER")
add(type="titulo", s=A("Hay una sola"), e=A("en este video") - 0.1, lado="izq", lineas=[{"t": "Una sola plataforma", "at": A("una sola")}, {"t": "[lo logró]", "at": A("lo logró")}])
add(type="lista", s=A("en este video") - 0.1, e=A("Se llama") - 0.15, lado="izq", titulo="En este video",
    items=[{"t": "Qué copió Instagram", "at": A("qué copió")}, {"t": "Lo único que [no copió]", "at": A("lo único")},
           {"t": "Qué hacer con tu canal", "at": A("qué hacer con")}])
AC.append(A("lo único"))

# --- vuelve a pantalla completa; zócalos con los nombres
ventana(A("Se llama") - 0.2, "FULL")
add(type="etiqueta", s=A("Instagram Features"), e=A("lo presentaron") - 0.05, texto="Instagram [Features]", icono="play")
add(type="etiqueta", s=A("Adam"), e=A("Tessa") - 0.1, texto="Adam Mosseri", sub="jefe de Instagram", icono="persona")
add(type="etiqueta", s=A("Tessa"), e=A("En un video") - 0.1, texto="Tessa Lyons", sub="vicepresidenta de producto", icono="persona")
add(type="icono", s=A("En un video"), e=DUR, lado="izq", icono="camara", texto="Video [horizontal]", sub="fijate el detalle")
AC.append(A("horizontal"))

D = {"modo": "personal", "formato": FORMATO, "fps": 30, "dur": DUR, "video": {"w": w, "h": h}, "cara": CARA,
     "ventana": V, "acentos": AC, "cortes": cortes(), "elementos": E, "entrada": "giro", "ritmo_max": 15,
     "subtitulos": SUBTITULOS, "palabras": palabras() if SUBTITULOS else []}
problemas = revisar(D)
json.dump(D, open("editor/src/datos.json", "w"), ensure_ascii=False, indent=1)
print("editor/src/datos.json listo" + (" (revisá los PROBLEMAS antes de renderizar)" if problemas else ""))
