# EJEMPLO de mezcla: un efecto por evento del guion visual + música de fondo + voz -> work/mezcla.wav
# Copialo a la carpeta del video como mezcla.py y ejecutalo parado ahí: python3 mezcla.py <ruta de la skill>
# Lee editor/src/datos.json (Remotion) o hf/beats.json (HyperFrames). La biblioteca está en ../sfx (carpeta del canal).
import json, os, sys
sys.path.insert(0, os.path.join(sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser("~/.claude/skills/edita"), "scripts"))
from sfx_motor import Mezcla

LIB = "../sfx/lib"                                   # efectos (descargar_mixkit.sh ../sfx, una sola vez por canal)
MUSICA = ["../sfx/musica_silk.mp3"]                  # elegila según el tono de la ficha (ver referencias/estilos.md)
VOZ = "work/cortado.mov" if os.path.exists("work/cortado.mov") else "work/cortado.wav"
LARGO = False                                        # video largo (>3 min): efectos 2–3 dB más bajos y menos seguidos

if os.path.exists("editor/src/datos.json"):
    D = json.load(open("editor/src/datos.json")); DUR = D["dur"]; EL = D.get("elementos", [])
    ESC = D.get("escenas", []); VEN = D.get("ventana", [])
else:
    D = json.load(open("hf/beats.json")); DUR = D["dur"]
    EL = [{"type": b["layout"], "s": b["t"]} for b in D["beats"]]; ESC, VEN = [], []

M = Mezcla(DUR, lib=LIB)
k = -2.5 if LARGO else 0
# entrada de cada elemento (tabla de referencias/estilos.md)
ENTRA = {"titulo": ("whoosh_pop", -21), "frase": ("whoosh_pop", -21), "numero": ("select", -19), "lista": ("sweep_small", -22),
         "captura": ("shutter", -18), "cita": ("sweep_small", -22), "chips": ("bubble_pop", -21), "etiqueta": ("sweep_short", -23),
         "barras": ("sweep_small", -22), "comparar": ("sweep_small", -22), "paso": ("impact", -20), "capitulo": ("impact", -18),
         "linea": ("sweep_small", -22), "alerta": ("wrong", -20), "icono": ("bubble_pop", -20), "suscribir": ("mouse_click", -18),
         "cta": ("achievement", -20), "imagen": ("whoosh_fast", -24)}
for b in EL:
    if b["type"] in ENTRA and b["s"] > 0.4:          # nada de golpes en 0 s: tapan la primera palabra
        n, db = ENTRA[b["type"]]; M.put(n, b["s"], db + k, align="peak" if "whoosh" in n else "onset")
    for it in b.get("items", []) + b.get("chips", []):   # cada ítem que aparece
        if isinstance(it, dict) and it.get("at"): M.put("bubble_pop", it["at"], -24 + k)
    if b["type"] == "numero": M.put("coin", b["s"] + 1.0, -24 + k)
    if b["type"] == "suscribir":
        M.put("mouse_click", b.get("clicAt", b["s"] + 0.9), -18 + k); M.put("bell_notif", b.get("campanaAt", b["s"] + 1.7), -20 + k)
for at, _ in VEN[1:]:                                 # cambios de ventana (personal)
    M.put("whoosh_fast", at + 0.2, -21 + k, align="peak")
for e in ESC[1:]:                                     # cambios de escena (faceless): suave, que no canse
    M.put("whoosh_fast2" if e.get("trans") == "empuje" else "sweep_short", e["s"], -27 + k, align="peak")

M.guardar(voz=VOZ, musica=MUSICA, salida="work/mezcla.wav")
