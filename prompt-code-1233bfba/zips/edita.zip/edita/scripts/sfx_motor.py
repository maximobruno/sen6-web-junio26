# Motor de mezcla (solo biblioteca estándar + ffmpeg). Importalo desde el mezcla.py de cada video:
#   import sys; sys.path.insert(0, "<ruta de la skill>/scripts"); from sfx_motor import Mezcla
#   M = Mezcla(dur, lib="sfx/lib")
#   M.put("bubble_pop", 3.2, -19)                 # efecto en el segundo 3,2 a -19 dB
#   M.put("whoosh_fast", 5.0, -20, align="peak")  # los whoosh se alinean por el pico (cae justo en el movimiento)
#   M.typing(4.0, 5.1)                             # tecleo continuo
#   M.guardar(voz="work/cortado.wav", musica=["sfx/musica_silk.mp3"], salida="work/mezcla.wav")
# guardar(): voz a -16 LUFS, música a -31 LUFS con "ducking" (baja sola cuando hablás), fundidos, y la mezcla
# en WAV de 32 bits flotante con pico a -3 dBFS como máximo (nunca recorta). Después: unir_audio.sh.
import subprocess, re, os, tempfile, array, math

SR = 48000

def _run(args):
    r = subprocess.run(args, capture_output=True, text=True, stdin=subprocess.DEVNULL)
    if r.returncode: raise RuntimeError(r.stderr[-2000:])
    return r

def _dur(p):
    return float(_run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).stdout)

def _lufs(p):
    o = _run(["ffmpeg", "-hide_banner", "-nostats", "-i", p, "-af", "ebur128", "-f", "null", "-"]).stderr
    v = re.findall(r"I:\s+(-?[\d.]+) LUFS", o)
    return float(v[-1]) if v else -70.0

def _analizar(p):
    """(inicio del sonido, pico de energía, pico absoluto 0-1) leyendo el efecto a 8 kHz"""
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", p, "-ac", "1", "-ar", "8000", "-f", "s16le", "-"], capture_output=True).stdout
    x = array.array("h"); x.frombytes(raw[: len(raw) // 2 * 2])
    if not x: return 0.0, 0.0, 1.0
    a = [abs(v) for v in x]; mx = max(a) or 1
    on = next(i for i, v in enumerate(a) if v > mx * 0.06)
    win = 80; s = sum(a[:win]); best, bi = s, 0
    for i in range(win, len(a)):
        s += a[i] - a[i - win]
        if s > best: best, bi = s, i - win // 2
    return on / 8000, max(0, bi) / 8000, mx / 32768

class Mezcla:
    def __init__(self, dur, lib="sfx/lib"):
        self.dur, self.lib = float(dur), lib
        self.ev = []; self.cache = {}

    def _info(self, n):
        if n not in self.cache:
            p = f"{self.lib}/{n}.mp3"
            if not os.path.exists(p): raise FileNotFoundError(f"falta el efecto {p}: corré descargar_mixkit.sh")
            self.cache[n] = (p,) + _analizar(p)
        return self.cache[n]

    def put(self, n, at, db, align="onset", maxlen=None, gap=0.12):
        """align='peak' para whooshes; 'onset' (el comienzo del sonido) para el resto"""
        if at is None or at < 0 or at > self.dur: return
        if any(abs(at - a) < gap and m == n for a, m, *_ in self.ev): return   # no repetir el mismo pegado
        p, on, pk, amp = self._info(n)
        ref = pk if align == "peak" else on
        self.ev.append((at, n, db, ref, maxlen, amp))

    def typing(self, s, e, db=-26, n="typing_e"):
        t = s
        while t < e - 0.05:
            d = min(1.8, e - t); self.put(n, t, db, maxlen=d, gap=0); t += d

    def _pista_sfx(self, salida):
        if not self.ev:
            _run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", f"anullsrc=r={SR}:cl=stereo", "-t", f"{self.dur:.3f}", "-c:a", "pcm_f32le", salida]); return
        nombres = sorted({n for _, n, *_ in self.ev})
        idx = {n: i for i, n in enumerate(nombres)}
        usos = {n: [e for e in self.ev if e[1] == n] for n in nombres}
        fc = []; labs = []; k = 0
        for n in nombres:
            c = len(usos[n]); i = idx[n]
            base = f"[{i}:a]aformat=sample_rates={SR}:channel_layouts=stereo"
            if c == 1: fc.append(base + f"[s{i}_0]")
            else: fc.append(base + f",asplit={c}" + "".join(f"[s{i}_{j}]" for j in range(c)))
            for j, (at, _, db, ref, maxlen, amp) in enumerate(usos[n]):
                if maxlen: cut0, off = ref, at          # tramo de largo fijo que arranca justo en at
                else:
                    off = at - ref; cut0 = 0.0
                    if off < 0: cut0, off = -off, 0.0
                tr = f"atrim=start={cut0:.4f}" + (f":end={cut0 + maxlen:.4f}" if maxlen else "") + ",asetpts=PTS-STARTPTS"
                if maxlen: tr += f",afade=t=out:st={max(0, maxlen - 0.04):.3f}:d=0.04"
                g = db - 20 * math.log10(max(amp, 1e-4))   # normaliza el pico del efecto y aplica db
                ms = int(round(off * 1000))
                fc.append(f"[s{i}_{j}]{tr},volume={g:.2f}dB,adelay={ms}|{ms}[u{k}]"); labs.append(f"[u{k}]"); k += 1
        fc.append("".join(labs) + f"amix=inputs={k}:normalize=0:duration=longest,apad,atrim=duration={self.dur:.3f}[o]")
        f = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False); f.write(";\n".join(fc)); f.close()
        args = ["ffmpeg", "-v", "error", "-y"]
        for n in nombres: args += ["-i", self.cache[n][0]]
        _run(args + ["-filter_complex_script", f.name, "-map", "[o]", "-t", f"{self.dur:.3f}", "-c:a", "pcm_f32le", "-ar", str(SR), salida]); os.remove(f.name)

    def _cama_musical(self, musica, salida, mus_inicio, fundido):
        """encadena los temas con fundido cruzado hasta cubrir la duración"""
        if not musica: return None
        lista = []; total = 0.0; i = 0
        while total < self.dur + 2 and i < 40:
            m = musica[i % len(musica)]; d = _dur(m)
            ini = mus_inicio if i == 0 else 1.0; fin = max(ini + 5, d - 3)
            lista.append((m, ini, fin)); total += (fin - ini) - (fundido if i else 0); i += 1
        args = ["ffmpeg", "-v", "error", "-y"]
        for m, *_ in lista: args += ["-i", m]
        fc = [f"[{j}:a]atrim=start={a:.2f}:end={b:.2f},asetpts=PTS-STARTPTS,aformat=sample_rates={SR}:channel_layouts=stereo[m{j}]" for j, (_, a, b) in enumerate(lista)]
        cur = "[m0]"
        for j in range(1, len(lista)):
            fc.append(f"{cur}[m{j}]acrossfade=d={fundido}:c1=tri:c2=tri[x{j}]"); cur = f"[x{j}]"
        fc.append(f"{cur}atrim=duration={self.dur:.3f},apad,atrim=duration={self.dur:.3f}[o]")
        _run(args + ["-filter_complex", ";".join(fc), "-map", "[o]", "-t", f"{self.dur:.3f}", "-c:a", "pcm_f32le", salida])
        return salida

    def guardar(self, voz, musica, salida, voz_lufs=-16, mus_lufs=-31, mus_inicio=10, fundido=2.5, duck_db=-6):
        tmp = tempfile.mkdtemp(prefix="edita_mezcla_")
        try:
            self._guardar(tmp, voz, musica, salida, voz_lufs, mus_lufs, mus_inicio, fundido, duck_db)
        finally:
            import shutil; shutil.rmtree(tmp, ignore_errors=True)

    def _guardar(self, tmp, voz, musica, salida, voz_lufs, mus_lufs, mus_inicio, fundido, duck_db):
        sfx = f"{tmp}/sfx.wav"; self._pista_sfx(sfx)
        v = f"{tmp}/voz.wav"
        _run(["ffmpeg", "-v", "error", "-y", "-i", voz, "-vn", "-af", f"aformat=sample_rates={SR}:channel_layouts=stereo,apad,atrim=duration={self.dur:.3f}", "-t", f"{self.dur:.3f}", "-c:a", "pcm_f32le", v])
        gv = voz_lufs - _lufs(v)
        cama = self._cama_musical(musica, f"{tmp}/mus.wav", mus_inicio, fundido)
        args = ["ffmpeg", "-v", "error", "-y", "-i", v, "-i", sfx]
        fc = [f"[0:a]volume={gv:.2f}dB,asplit=2[v][vsc]"]
        if cama:
            gm = mus_lufs - _lufs(cama)
            args += ["-i", cama]
            # ducking: la música baja ~6 dB cuando hay voz y vuelve en las pausas
            ratio = 10 ** (-duck_db / 20) * 2
            fc.append(f"[2:a]volume={gm:.2f}dB,afade=t=in:d=0.6,afade=t=out:st={max(0, self.dur - 1.5):.3f}:d=1.5[m0]")
            fc.append(f"[m0][vsc]sidechaincompress=threshold=0.015:ratio={ratio:.1f}:attack=40:release=500:makeup=1[m]")
            fc.append("[v][m][1:a]amix=inputs=3:normalize=0:duration=first[o]")
        else:
            fc.append("[vsc]anullsink;[v][1:a]amix=inputs=2:normalize=0:duration=first[o]")
        pre = f"{tmp}/pre.wav"
        _run(args + ["-filter_complex", ";".join(fc), "-map", "[o]", "-t", f"{self.dur:.3f}", "-c:a", "pcm_f32le", pre])
        o = _run(["ffmpeg", "-hide_banner", "-nostats", "-i", pre, "-af", "volumedetect", "-f", "null", "-"]).stderr
        mx = float(re.findall(r"max_volume:\s*(-?[\d.]+) dB", o)[-1])
        g = min(0.0, -3.0 - mx)   # pico máximo -3 dBFS; nunca recortar
        _run(["ffmpeg", "-v", "error", "-y", "-i", pre, "-af", f"volume={g:.2f}dB", "-c:a", "pcm_f32le", salida])
        print(f"mezcla: {len(self.ev)} efectos, {self.dur:.2f} s, voz {gv:+.1f} dB, pico {mx + g:.1f} dBFS -> {salida}")
