#!/bin/bash
# Uso (parado en la carpeta editor/ de Remotion): bash stills.sh <composicion> <salida.jpg> <seg1> <seg2> ...
# Saca un cuadro de cada momento y los junta en una grilla para revisar ANTES del render completo
# (cosas sobre la cara, textos que se pisan, fuera de la zona segura, anclas mal ubicadas).
set -e
COMP="$1"; OUT="$2"; shift 2
FPS=$(python3 -c "import json;print(json.load(open('src/datos.json')).get('fps',30))")
TMPD="$(mktemp -d)"; i=0
for s in "$@"; do
  F=$(python3 -c "print(int(round($s*$FPS)))")
  npx remotion still src/index.ts "$COMP" "$TMPD/$(printf %03d $i).png" --frame=$F --scale=0.4 --log=error
  ffmpeg -v error -y -i "$TMPD/$(printf %03d $i).png" -vf "drawtext=text='${s}s':x=12:y=12:fontsize=28:fontcolor=white:box=1:boxcolor=black@0.6:boxborderw=6" "$TMPD/t$(printf %03d $i).png" 2>/dev/null || cp "$TMPD/$(printf %03d $i).png" "$TMPD/t$(printf %03d $i).png"
  i=$((i+1))
done
COLS=3; [ $i -lt 3 ] && COLS=$i
ROWS=$(( (i + COLS - 1) / COLS ))
ffmpeg -v error -y -pattern_type glob -i "$TMPD/t*.png" -vf "tile=${COLS}x${ROWS}:padding=6:color=white" -frames:v 1 -q:v 3 "$OUT"
rm -rf "$TMPD"; echo "grilla: $OUT ($i cuadros)"
