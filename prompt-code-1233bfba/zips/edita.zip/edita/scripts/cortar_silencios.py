# Uso: python3 cortar_silencios.py <carpeta_del_video> [--umbral 0.35] [--pad 0.075] [--ruido -35]
#                                   [--sin-cortes] [--excluir work/excluir.json] [--publico editor/public]
# Corta los silencios largos (los deja en ~2*pad s), en cuadros exactos. Solo biblioteca estándar + ffmpeg.
#  - Personal (hay work/fuente.mp4): genera work/cortado.mov y <publico>/video.mp4 (sin audio, para Remotion)
#  - Faceless (hay work/fuente.wav): genera work/cortado.wav
# Siempre: work/keep.json (tramos que quedan) y work/timemap.json ([ini, fin, inicio_en_el_recortado] por tramo)
# --umbral: un silencio más largo que esto (s) se corta.  --ruido: qué tan bajo es "silencio" (dB; con ruido de fondo usá -30)
# --excluir: [[ini, fin], ...] en tiempos del ORIGINAL a sacar (tomas repetidas; ver tomas_repetidas.py)
import sys, json, subprocess, os, argparse, re
ap = argparse.ArgumentParser()
ap.add_argument("p"); ap.add_argument("--umbral", type=float, default=0.35); ap.add_argument("--pad", type=float, default=0.075)
ap.add_argument("--ruido", type=float, default=-35); ap.add_argument("--sin-cortes", action="store_true")
ap.add_argument("--excluir"); ap.add_argument("--publico", default="editor/public")
a = ap.parse_args(); os.chdir(a.p)
VIDEO = os.path.exists("work/fuente.mp4")
src = "work/fuente.mp4" if VIDEO else "work/fuente.wav"
if not os.path.exists(src): sys.exit("No hay work/fuente.mp4 ni work/fuente.wav: corré antes preparar.sh")
def probe(*args): return subprocess.run(["ffprobe", "-v", "error", *args, src], capture_output=True, text=True).stdout.strip()
if VIDEO:
    n, d = probe("-select_streams", "v:0", "-show_entries", "stream=r_frame_rate", "-of", "csv=p=0").split("/")
    fps = float(n) / float(d)
else:
    fps = 1000.0  # audio: precisión de 1 ms
dur = float(probe("-show_entries", "format=duration", "-of", "csv=p=0"))
fr = lambda t: round(round(t * fps) / fps, 4)
if a.sin_cortes:
    keep = [(0.0, fr(dur - 0.02))]
else:
    out = subprocess.run(["ffmpeg", "-hide_banner", "-i", src, "-af", f"silencedetect=noise={a.ruido}dB:d={a.umbral}", "-f", "null", "-"], capture_output=True, text=True).stderr
    st = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", out)]; en = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", out)]
    keep = []; cur = 0.0
    for s, e in zip(st, en):
        if s < 0.05: cur = max(0, e - 0.12); continue          # silencio al principio
        keep.append((cur, s + a.pad)); cur = e - a.pad
    if len(st) > len(en): keep.append((cur, min(dur, st[-1] + a.pad)))   # termina en silencio
    else: keep.append((cur, dur - 0.05))
    keep = [(fr(x), fr(y)) for x, y in keep if y - x > 0.1]
if a.excluir:
    for ex0, ex1 in json.load(open(a.excluir)):
        nk = []
        for x, y in keep:
            if y <= ex0 or x >= ex1: nk.append((x, y)); continue
            if x < ex0: nk.append((x, fr(ex0)))
            if y > ex1: nk.append((fr(ex1), y))
        keep = [(x, y) for x, y in nk if y - x > 0.1]
tm = []; acc = 0.0
for x, y in keep: tm.append((x, y, round(acc, 4))); acc += y - x
json.dump(keep, open("work/keep.json", "w")); json.dump(tm, open("work/timemap.json", "w"))
parts = []; labels = ""
for i, (x, y) in enumerate(keep):
    d = y - x
    af = f"[0:a]atrim=start={x}:end={y},asetpts=PTS-STARTPTS,afade=t=in:d=0.008,afade=t=out:st={max(0, d - 0.008):.4f}:d=0.008[a{i}]"
    if VIDEO:
        parts.append(f"[0:v]trim=start={x}:end={y},setpts=PTS-STARTPTS[v{i}];" + af); labels += f"[v{i}][a{i}]"
    else:
        parts.append(af); labels += f"[a{i}]"
if VIDEO:
    open("work/cut_fc.txt", "w").write(";".join(parts) + f";{labels}concat=n={len(keep)}:v=1:a=1[vc][a];[vc]format=yuv420p[v]")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex_script", "work/cut_fc.txt", "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-crf", "14", "-r", str(round(fps, 3)), "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709",
                    "-c:a", "pcm_s16le", "work/cortado.mov"], check=True)
    os.makedirs(a.publico, exist_ok=True)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "work/cortado.mov", "-an", "-c:v", "copy", "-movflags", "+faststart", f"{a.publico}/video.mp4"], check=True)
    print(f"{len(keep)} tramos: {dur:.2f} s -> {acc:.2f} s (fps {fps:g}) · work/cortado.mov + {a.publico}/video.mp4")
else:
    open("work/cut_fc.txt", "w").write(";".join(parts) + f";{labels}concat=n={len(keep)}:v=0:a=1[a]")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", src, "-filter_complex_script", "work/cut_fc.txt", "-map", "[a]", "-c:a", "pcm_s16le", "-ar", "48000", "work/cortado.wav"], check=True)
    print(f"{len(keep)} tramos: {dur:.2f} s -> {acc:.2f} s · work/cortado.wav")
print("Ahora transcribí el audio YA cortado: bash transcribir.sh work/cortado.{mov|wav} work/transcript_cortado.json")
