# ALTERNATIVA (solo si existe `uv`): transcripción con faster-whisper, más rápida en videos largos.
# Uso: uv run --python 3.12 --with faster-whisper python transcribir_fw.py <audio> <salida.json> [modelo=medium] ["palabras clave del tema"]
# Escribe el MISMO formato que transcribir.sh: [{"text","start","end"}, ...]
import sys, json, subprocess
import numpy as np
from faster_whisper import WhisperModel
src, out = sys.argv[1], sys.argv[2]
mod = sys.argv[3] if len(sys.argv) > 3 else "medium"
prompt = sys.argv[4] if len(sys.argv) > 4 else None
# el audio se lee con ffmpeg (evita problemas de PyAV)
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True).stdout
audio = np.frombuffer(raw, np.float32)
m = WhisperModel(mod, compute_type="int8")
segs, _ = m.transcribe(audio, language="es", word_timestamps=True, initial_prompt=prompt)
res = []
for s in segs:
    print(f"[{s.start:7.2f}] {s.text}", flush=True)
    res += [{"text": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)} for w in s.words if w.word.strip()]
json.dump(res, open(out, "w"), ensure_ascii=False, indent=0)
print(f"{len(res)} palabras -> {out}")
