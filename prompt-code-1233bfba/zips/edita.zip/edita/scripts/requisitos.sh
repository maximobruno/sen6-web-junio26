#!/bin/bash
# Uso: bash requisitos.sh
# Revisa lo que hace falta para editar con Remotion y HyperFrames. No instala nada: solo informa.
# Salida: una línea por requisito con OK / FALTA / OJO y qué hacer.
ok(){ printf "  OK     %-26s %s\n" "$1" "$2"; }
falta(){ printf "  FALTA  %-26s %s\n" "$1" "$2"; FALTAN=$((FALTAN+1)); }
ojo(){ printf "  OJO    %-26s %s\n" "$1" "$2"; }
FALTAN=0
echo "== Revisión de requisitos"

# Sistema
OS=$(uname -s)
if [ "$OS" = "Darwin" ]; then
  V=$(sw_vers -productVersion); M=${V%%.*}
  if [ "$M" -ge 15 ]; then ok "macOS $V" "sirve para Remotion y HyperFrames"
  else ojo "macOS $V" "Remotion pide macOS 15 (Sequoia) o más nuevo: usá HyperFrames"; fi
else
  ok "Sistema $OS" "(en Linux Remotion pide glibc 2.35+)"
fi

# Node 22+
if command -v node >/dev/null 2>&1; then
  NV=$(node -v | sed 's/v//'); NM=${NV%%.*}
  if [ "$NM" -ge 22 ]; then ok "Node.js $NV" ""; else falta "Node.js $NV" "hace falta 22 o más nuevo (HyperFrames lo exige)"; fi
else falta "Node.js" "instalar Node 22 LTS (Mac: brew install node@22 · Windows: winget install OpenJS.NodeJS.LTS)"; fi

# FFmpeg / ffprobe
if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then ok "FFmpeg" "$(ffmpeg -version | head -1 | cut -d' ' -f3)"
else falta "FFmpeg" "Mac: brew install ffmpeg · Windows: winget install ffmpeg"; fi

# Chrome (Remotion y HyperFrames renderizan con un Chrome sin ventana; las capturas usan el Chrome instalado)
if [ -d "/Applications/Google Chrome.app" ] || command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1; then ok "Google Chrome" ""
else falta "Google Chrome" "bajarlo de google.com/chrome (Mac: brew install --cask google-chrome)"; fi

# Python 3 (solo biblioteca estándar; en Mac viene con las Command Line Tools que instala Homebrew)
if command -v python3 >/dev/null 2>&1 && python3 -c "import json" >/dev/null 2>&1; then ok "Python 3" "$(python3 --version 2>&1 | cut -d' ' -f2) (solo biblioteca estándar)"
else falta "Python 3" "Mac: xcode-select --install · Windows: winget install Python.Python.3.12"; fi

# Homebrew (solo Mac, para instalar lo anterior)
if [ "$OS" = "Darwin" ]; then
  if command -v brew >/dev/null 2>&1; then ok "Homebrew" ""; else ojo "Homebrew" "no está: se instala desde brew.sh (la contraseña la escribís vos en la terminal)"; fi
fi

# Skills oficiales
SK="$HOME/.claude/skills"; PL="$HOME/.claude/plugins"
if ls -d "$SK"/remotion* >/dev/null 2>&1 || grep -rqs "remotion-best-practices" "$SK" 2>/dev/null; then ok "Skills de Remotion" ""
else falta "Skills de Remotion" "npx -y skills@latest add remotion-dev/skills -g -y"; fi
if ls -d "$SK"/hyperframes* >/dev/null 2>&1 || grep -rqs "hyperframes" "$PL"/installed_plugins.json 2>/dev/null; then ok "Skills de HyperFrames" ""
else falta "Skills de HyperFrames" "claude plugin marketplace add heygen-com/hyperframes && claude plugin install hyperframes@hyperframes"; fi

# uv (opcional: transcripción alternativa con faster-whisper)
if command -v uv >/dev/null 2>&1; then ok "uv (opcional)" "permite usar faster-whisper como alternativa"; fi

echo
if [ "$FALTAN" -eq 0 ]; then echo "Todo listo para editar."; else echo "Faltan $FALTAN cosas. Instalalas antes de editar (la contraseña de la compu la escribís vos en la terminal, nunca en el chat)."; fi
