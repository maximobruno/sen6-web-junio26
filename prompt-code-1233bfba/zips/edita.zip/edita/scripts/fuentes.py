# Uso: python3 fuentes.py <tema.json> <carpeta_destino> [--json src/fuentes.json] [--css estilo-fuentes.css --prefijo assets/fonts/]
# Baja las tipografías de Google Fonts elegidas en la ficha como archivos .ttf locales (gratis, licencia OFL).
# Locales y no por internet: así el render es igual siempre (HyperFrames lo exige; Remotion las carga desde public/).
# Escribe una lista [{family, weight, style, file}] (--json, para Remotion) y/o un CSS con @font-face (--css, para HyperFrames).
import json, sys, os, re, argparse, urllib.request, urllib.parse
ap = argparse.ArgumentParser(); ap.add_argument("tema"); ap.add_argument("dest")
ap.add_argument("--json"); ap.add_argument("--css"); ap.add_argument("--prefijo", default="fonts/")
a = ap.parse_args()
T = json.load(open(a.tema))
os.makedirs(a.dest, exist_ok=True)
fams = {}
for rol, f in T["fuentes"].items():
    fams.setdefault(f["familia"], set()).update(f.get("pesos", [400, 700]))
lista = []
for fam, pesos in fams.items():
    q = f"{fam}:wght@{';'.join(str(p) for p in sorted(pesos))}"
    url = "https://fonts.googleapis.com/css2?family=" + urllib.parse.quote(q, safe=":@;")
    # sin "User-Agent" de navegador, Google devuelve .ttf (los navegadores reciben woff2)
    try:
        css = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "curl/8"})).read().decode()
    except Exception as e:
        sys.exit(f"No pude bajar '{fam}' ({e}). Revisá el nombre exacto en fonts.google.com y los pesos disponibles.")
    for blk in re.findall(r"@font-face\s*{[^}]+}", css):
        w = re.search(r"font-weight:\s*(\d+)", blk).group(1); st = re.search(r"font-style:\s*(\w+)", blk).group(1)
        src = re.search(r"url\((https://[^)]+\.ttf)\)", blk)
        if not src: continue
        fn = f"{fam.replace(' ', '')}-{w}{'i' if st == 'italic' else ''}.ttf"
        if not os.path.exists(os.path.join(a.dest, fn)):
            urllib.request.urlretrieve(src.group(1), os.path.join(a.dest, fn))
        if not any(x["file"] == fn for x in lista):
            lista.append({"family": fam, "weight": int(w), "style": st, "file": fn})
for x in lista: print(f"  {x['family']} {x['weight']} -> {a.dest}/{x['file']}")
if a.json:
    json.dump(lista, open(a.json, "w"), indent=1)
if a.css:
    open(a.css, "w").write("\n".join(f'@font-face {{ font-family:"{x["family"]}"; src:url("{a.prefijo}{x["file"]}") format("truetype"); font-weight:{x["weight"]}; font-style:{x["style"]}; }}' for x in lista) + "\n")
print(f"{len(lista)} archivos de fuente listos")
