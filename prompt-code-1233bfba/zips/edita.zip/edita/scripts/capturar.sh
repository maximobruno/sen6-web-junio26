#!/bin/bash
# Uso: bash capturar.sh <url> <salida.png> [ancho,alto=1600,1000]
# Captura real de una página pública con Chrome sin ventana (no inicia sesión en nada).
# Páginas largas: alto grande (p. ej. 1440,6000) y después recortar con ffmpeg crop.
C=""
for x in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" "$(command -v google-chrome)" "$(command -v chromium)"; do
  [ -n "$x" ] && [ -x "$x" ] && C="$x" && break
done
[ -z "$C" ] && { echo "No encuentro Google Chrome"; exit 1; }
PROF="${TMPDIR:-/tmp}/edita_chrome_perfil"
"$C" --headless=new --disable-gpu --hide-scrollbars --window-size=${3:-1600,1000} --user-data-dir="$PROF" --lang=es-419 --virtual-time-budget=12000 --screenshot="$2" "$1" >/dev/null 2>&1
ls -la "$2"
