#!/bin/bash
# Uso: bash descargar_mixkit.sh <carpeta_sfx>
# Baja una biblioteca probada de efectos (sfx/lib/*.mp3) y música (sfx/musica_*.mp3) de Mixkit.
# Licencia Mixkit (mixkit.co/license): gratis para YouTube y redes, uso comercial; NO se puede registrar en Content ID
# ni revender suelta. Si llega un reclamo: escribir a team@mixkit.co. Nunca usar la biblioteca de CapCut en videos monetizados.
D="$1"; mkdir -p "$D/lib"; UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"
while read n id; do [ -s "$D/lib/$n.mp3" ] || curl -s -A "$UA" -o "$D/lib/$n.mp3" "https://assets.mixkit.co/active_storage/sfx/$id/$id-preview.mp3"; done <<'L'
whoosh_fast 1492
whoosh_fast2 1490
sweep_small 166
sweep_short 175
whoosh_pop 3005
impact 2903
punch 2050
msg_pop 2354
bubble_pop 2357
hard_pop 2364
pop_cluster 2359
typing_e 1397
typing_phone 1393
click_tone 2568
check 1120
select 3124
correct 2870
positive 951
achievement 600
wrong 946
wand 3062
sparkle_whoosh 2350
coin 216
shutter 1133
air_zoom 2608
bell_notif 933
notif_bell2 592
mouse_click 1117
double_click 275
page_turn 1106
scifi_confirm 914
tile_reveal 960
L
while read id name; do [ -s "$D/musica_$name.mp3" ] || curl -s -A "$UA" -o "$D/musica_$name.mp3" "https://assets.mixkit.co/music/$id/$id.mp3"; done <<'L'
130 tech_house_vibes
872 gimme_groove
587 discover
601 skyline
184 vastness
22 piano_reflections
188 echoes
612 selpan
605 delirium
1168 coffee_or_tea
143 silk
175 digital_clouds
102 stylz
726 uplifting_bass
644 upbeat_644
1068 energetic_1068
839 happy_839
989 energetic_989
614 silent_descent
615 tapis
606 drawing_sky
79 journey
623 deep_urban
371 cat_walk
132 hazy_after_hours
744 house_02
134 deep_techno
1147 midnight_funk
L
ls "$D/lib" | wc -l; ls "$D"/musica_*.mp3
