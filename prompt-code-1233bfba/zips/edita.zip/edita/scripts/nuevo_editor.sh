#!/bin/bash
# Uso: bash nuevo_editor.sh <carpeta_del_video> [remotion|hyperframes]
# Arma el proyecto de edición dentro de la carpeta del video, con el estilo del canal (tema.json de la carpeta del canal):
#   remotion    -> <video>/editor/  (copia la plantilla, baja las fuentes a public/fonts, instala dependencias)
#   hyperframes -> <video>/hf/      (build.mjs + estilo; las fuentes van a hf/assets/fonts)
# El tema se busca en <video>/../tema.json (la carpeta del canal). Si EDITA_NODE_MODULES apunta a un node_modules
# de Remotion ya instalado (misma versión), se enlaza en vez de instalar de nuevo (ahorra ~1 GB y varios minutos).
set -e
SK="$(cd "$(dirname "$0")/.." && pwd)"
V="$(cd "$1" && pwd)"; HERR="${2:-remotion}"
TEMA="$V/../tema.json"; [ -f "$TEMA" ] || TEMA="$V/tema.json"
[ -f "$TEMA" ] || { echo "No encuentro tema.json en la carpeta del canal: completá primero el formulario (ficha de edición)."; exit 1; }
if [ "$HERR" = "remotion" ]; then
  E="$V/editor"; mkdir -p "$E/src" "$E/public/fonts" "$E/out"
  cp "$SK/plantillas/remotion/"{package.json,tsconfig.json,remotion.config.ts} "$E/"
  for f in "$SK/plantillas/remotion/src/"*; do b=$(basename "$f"); [ "$b" = "datos.json" ] && [ -f "$E/src/datos.json" ] && continue; cp "$f" "$E/src/"; done
  cp "$TEMA" "$E/src/tema.json"
  python3 "$SK/scripts/fuentes.py" "$TEMA" "$E/public/fonts" --json "$E/src/fuentes.json"
  cd "$E"
  if [ -d node_modules ]; then echo "node_modules ya existe"
  elif [ -n "$EDITA_NODE_MODULES" ] && [ -d "$EDITA_NODE_MODULES/remotion" ]; then ln -s "$EDITA_NODE_MODULES" node_modules; echo "node_modules enlazado"
  else echo "Instalando Remotion (la primera vez tarda unos minutos)…"; npm install --no-audit --no-fund; fi
  echo "listo: $E  (vista previa: cd \"$E\" && npm run dev)"
else
  H="$V/hf"; mkdir -p "$H/assets/fonts" "$H/assets/img" "$H/out"
  cp "$SK/plantillas/hyperframes/build.mjs" "$H/"
  [ -f "$H/beats.json" ] || cp "$SK/plantillas/hyperframes/beats_ejemplo.json" "$H/beats.json"
  cp "$TEMA" "$H/tema.json"
  python3 "$SK/scripts/fuentes.py" "$TEMA" "$H/assets/fonts" --css "$H/fuentes.css" --prefijo assets/fonts/
  cat > "$H/hyperframes.json" <<'J'
{ "$schema": "https://hyperframes.heygen.com/schema/hyperframes.json", "paths": { "blocks": "compositions", "components": "compositions/components", "assets": "assets" } }
J
  echo "listo: $H  (armar: node build.mjs · revisar: npx hyperframes check · render: npx hyperframes render --output out/video_mudo.mp4)"
fi
