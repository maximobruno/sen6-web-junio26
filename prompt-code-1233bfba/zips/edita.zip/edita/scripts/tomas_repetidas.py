# Uso: python3 tomas_repetidas.py work/transcript.json [--min 4] [--ventana 25]
# Busca frases dichas dos veces seguidas (cuando te equivocás y repetís) y muletillas de error ("perdón", "de nuevo").
# Imprime cada caso con el texto y propone el tramo a sacar (la PRIMERA toma) en work/excluir_sugerido.json.
# Claude revisa cada propuesta leyendo el contexto antes de usarla con cortar_silencios.py --excluir.
import json, sys, re, unicodedata, argparse
ap = argparse.ArgumentParser(); ap.add_argument("t"); ap.add_argument("--min", type=int, default=4); ap.add_argument("--ventana", type=float, default=25)
a = ap.parse_args()
W = json.load(open(a.t))
if W and isinstance(W[0], dict) and "words" in W[0]:  # formato por segmentos (faster-whisper viejo)
    W = [{"text": w["w"], "start": w["s"], "end": w["e"]} for s in W for w in s["words"]]
def norm(w): return re.sub(r"[^a-z0-9ñ]", "", unicodedata.normalize("NFKD", w.lower()).encode("ascii", "ignore").decode())
N = [norm(w["text"]) for w in W]
txt = lambda i, j: " ".join(w["text"] for w in W[i:j])
sug = []; usados = set()
for i in range(len(N) - a.min):
    if i in usados: continue
    g = N[i:i + a.min]
    if not all(g): continue
    for j in range(i + a.min, len(N) - a.min + 1):
        if W[j]["start"] - W[i]["start"] > a.ventana: break
        if N[j:j + a.min] == g:
            ini, fin = W[i]["start"] - 0.05, W[j]["start"] - 0.05
            print(f"REPETIDA  {W[i]['start']:7.2f}s  «{txt(i, i + a.min + 4)}…»  y otra vez en {W[j]['start']:.2f}s")
            print(f"          tramo a sacar (1ª toma): [{ini:.2f}, {fin:.2f}]  «{txt(i, j)}»")
            sug.append([round(ini, 2), round(fin, 2)]); usados.update(range(i, j)); break
for k, w in enumerate(N):
    if w in ("perdon", "perdona", "denuevo") or (w == "de" and k + 1 < len(N) and N[k + 1] == "nuevo"):
        print(f"MULETILLA {W[k]['start']:7.2f}s  «{txt(max(0, k - 6), k + 6)}»")
json.dump(sug, open("work/excluir_sugerido.json", "w"))
print(f"\n{len(sug)} tomas repetidas -> work/excluir_sugerido.json (revisalas antes de usarlas)")
