#!/bin/bash
# Uso: bash preparar.sh <video_o_audio> <carpeta_del_video>
# Copia el material a la carpeta del video y deja todo listo para transcribir.
#  - Video (canal personal): si es HDR de iPhone (HLG/PQ) lo pasa a SDR; separa la voz; hace una hoja de contacto
#    (work/hoja.jpg) para ubicar la cara.
#  - Audio (canal faceless): lo pasa a WAV.
# Deja: work/fuente.mp4 (video) o work/fuente.wav (audio), work/voz16k.wav y work/info.txt
set -e
SRC="$1"; P="$2"
[ -f "$SRC" ] || { echo "No encuentro el archivo: $SRC"; exit 1; }
SRC="$(cd "$(dirname "$SRC")" && pwd)/$(basename "$SRC")"   # ruta completa (después cambiamos de carpeta)
mkdir -p "$P"/{work,capturas,out/archivo}
EXT="${SRC##*.}"; EXT=$(echo "$EXT" | tr 'A-Z' 'a-z')
HASV=$(ffprobe -v error -select_streams v -show_entries stream=codec_type -of csv=p=0 "$SRC" | grep -c video || true)
# una portada (mp3 con imagen) no cuenta como video
if [ "$EXT" = "mp3" ] || [ "$EXT" = "wav" ] || [ "$EXT" = "m4a" ] || [ "$EXT" = "aac" ] || [ "$EXT" = "flac" ] || [ "$EXT" = "ogg" ]; then HASV=0; fi
cd "$P"
if [ "$HASV" -gt 0 ]; then
  cp "$SRC" "original.$EXT"
  echo "== video"
  ffprobe -v error -show_entries format=duration:stream=codec_type,codec_name,width,height,r_frame_rate,color_transfer -of default=nw=1 "original.$EXT" | grep -v unknown | tee work/info.txt
  TRC=$(ffprobe -v error -select_streams v:0 -show_entries stream=color_transfer -of csv=p=0 "original.$EXT")
  if [ "$TRC" = "arib-std-b67" ] || [ "$TRC" = "smpte2084" ]; then
    echo "== HDR ($TRC): lo paso a SDR para que no se vea lavado"
    if command -v avconvert >/dev/null 2>&1; then
      # avconvert (de macOS) hace el mapeo de tonos igual que la app Fotos; el preset respeta la orientación
      avconvert --source "original.$EXT" --output work/fuente.mp4 --preset Preset1920x1080 --replace
    elif ffmpeg -hide_banner -filters 2>/dev/null | grep -q zscale; then
      ffmpeg -v error -y -i "original.$EXT" -vf "zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p" -c:v libx264 -crf 16 -c:a copy work/fuente.mp4
    else
      echo "   OJO: no hay avconvert ni zscale; sigo con el original (los colores pueden verse lavados)."
      cp "original.$EXT" work/fuente.mp4
    fi
  else
    ffmpeg -v error -y -i "original.$EXT" -c copy -movflags +faststart work/fuente.mp4 2>/dev/null || ffmpeg -v error -y -i "original.$EXT" -c:v libx264 -crf 16 -c:a aac -b:a 256k work/fuente.mp4
  fi
  ffmpeg -v error -y -i work/fuente.mp4 -vn -ac 1 -ar 16000 work/voz16k.wav
  DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 work/fuente.mp4)
  # hoja de contacto: 12 cuadros repartidos para ubicar la cara
  ffmpeg -v error -y -i work/fuente.mp4 -vf "fps=12/$DUR,scale=320:-2,tile=4x3" -frames:v 1 work/hoja.jpg
  # un cuadro a tamaño real para medir la cara (FACE) con precisión
  ffmpeg -v error -y -ss $(python3 -c "print($DUR/3)") -i work/fuente.mp4 -frames:v 1 work/cuadro.jpg
  echo "listo (personal): work/fuente.mp4, work/voz16k.wav, work/hoja.jpg, work/cuadro.jpg"
else
  cp "$SRC" "original.$EXT"
  echo "== audio"
  ffprobe -v error -show_entries format=duration:stream=codec_name,sample_rate,channels -of default=nw=1 "original.$EXT" | tee work/info.txt
  ffmpeg -v error -y -i "original.$EXT" -vn -ar 48000 -c:a pcm_s16le work/fuente.wav
  ffmpeg -v error -y -i work/fuente.wav -ac 1 -ar 16000 work/voz16k.wav
  echo "listo (faceless): work/fuente.wav, work/voz16k.wav"
fi
echo "== volumen de la voz (YouTube normaliza a -14 LUFS)"
ffmpeg -hide_banner -i work/voz16k.wav -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1
