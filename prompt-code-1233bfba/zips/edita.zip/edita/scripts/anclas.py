# Anclas por frase: convierte "lo que dijo" en "el segundo exacto" del audio/video YA CORTADO.
# Copialo a la carpeta del video y usalo desde build.py (ejecutá build.py parado en esa carpeta):
#   from anclas import A, DUR, palabras, cortes, revisar
#   t = A("frase exacta")          -> segundo en que empieza la frase
#   A("frase", word=2)             -> segundo de la 3ª palabra de la frase
#   A("frase", end=True)           -> segundo en que TERMINA la frase
#   A("frase", after=0)            -> busca desde el principio (por defecto sigue desde la última encontrada)
# Usa work/transcript_cortado.json (preferido: tiempos exactos). Si no existe, mapea work/transcript.json con el
# timemap (acumula error: los gráficos terminan apareciendo antes de tiempo en videos largos).
# Solo biblioteca estándar.
import json, unicodedata, re, os, subprocess

def _load(p):
    d = json.load(open(p))
    if d and isinstance(d[0], dict) and "words" in d[0]:     # formato por segmentos
        return [{"text": w["w"], "start": w["s"], "end": w["e"]} for s in d for w in s["words"]]
    return d

TM = json.load(open("work/timemap.json")) if os.path.exists("work/timemap.json") else [[0, 1e9, 0]]
def to_cut(t):
    for a, b, c in TM:
        if t < a: return c
        if t <= b: return round(c + (t - a), 3)
    a, b, c = TM[-1]; return round(c + (b - a), 3)

_CUT_T = os.path.exists("work/transcript_cortado.json")
if not _CUT_T: print("OJO: falta work/transcript_cortado.json; uso el mapeo por timemap (menos preciso)")
W = _load("work/transcript_cortado.json" if _CUT_T else "work/transcript.json")
def norm(w): return re.sub(r"[^a-z0-9ñ]", "", unicodedata.normalize("NFKD", w.lower().replace("ñ", "__n__")).encode("ascii", "ignore").decode().replace("__n__", "ñ"))
N = [norm(w["text"]) for w in W]
S = [w["start"] if _CUT_T else to_cut(w["start"]) for w in W]
E = [w["end"] if _CUT_T else to_cut(w["end"]) for w in W]
_med = "work/cortado.mov" if os.path.exists("work/cortado.mov") else "work/cortado.wav"
DUR = round(float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", _med], capture_output=True, text=True).stdout), 3)
_last = [0]

def A(phrase, after=None, word=0, end=False):
    """segundo (en el recortado) en que dice la frase. Tirá error si no la encuentra: usá las palabras tal cual las transcribió."""
    q = [x for x in (norm(x) for x in phrase.split()) if x]
    start = max(0, _last[0] - 150) if after is None else after
    for rng in (range(start, len(N) - len(q) + 1), range(0, len(N) - len(q) + 1)):
        for i in rng:
            if N[i:i + len(q)] == q:
                _last[0] = i
                j = i + (len(q) - 1 if end else word)
                return round(E[j] if end else S[j], 3)
    raise ValueError("no encontré la frase: " + phrase)

def palabras():
    """[{w, s, e}] del recortado (para subtítulos)"""
    return [{"w": W[i]["text"], "s": round(S[i], 3), "e": round(E[i], 3)} for i in range(len(W))]

def cortes():
    """segundos (en el recortado) donde hay un corte: sirven para cambiar el encuadre y esconder el salto"""
    return [round(c, 3) for (_, _, c) in TM][1:]

def revisar(D):
    """Chequea el guion visual antes de renderizar. Devuelve la cantidad de problemas."""
    prob = []
    els = sorted(D.get("elementos", []), key=lambda b: b["s"])
    for b in els:
        if b["e"] <= b["s"]: prob.append(f"{b['type']} {b['s']:.2f}: termina antes de empezar")
        if b["e"] > DUR + 0.05: prob.append(f"{b['type']} {b['s']:.2f}: termina después del final ({DUR})")
        for k, v in b.items():   # tiempos internos (…At / at) dentro del elemento
            vals = [v] if isinstance(v, (int, float)) and (k.endswith("At") or k == "at") else []
            if isinstance(v, list): vals = [x.get("at") for x in v if isinstance(x, dict) and isinstance(x.get("at"), (int, float))]
            for x in vals:
                if not (b["s"] - 0.3 <= x <= b["e"] + 0.05): prob.append(f"{b['type']} {b['s']:.2f}: '{k}' = {x:.2f} cae fuera del elemento (ancla equivocada: usá una frase más larga)")
    for i, a in enumerate(els):   # dos elementos en el mismo lugar al mismo tiempo
        for b in els[i + 1:]:
            if b["s"] >= a["e"]: break
            la, lb = a.get("lado", "auto"), b.get("lado", "auto")
            if la == lb and la not in ("arriba_esq", "abajo_esq") and not a.get("encima") and not b.get("encima"):
                prob.append(f"{a['type']} {a['s']:.2f} y {b['type']} {b['s']:.2f} se pisan en '{la}'")
    if D.get("modo") == "personal":   # nada en el centro mientras el video está a pantalla completa
        V = D.get("ventana", [[0, "FULL"]])
        def modo_en(t):
            m = V[0][1]
            for at, mm in V:
                if t >= at: m = mm
            return m
        for b in els:
            if b.get("lado") in ("centro", "completo") and b["type"] not in ("capitulo",) and modo_en(b["s"] + 0.2) == "FULL":
                prob.append(f"{b['type']} {b['s']:.2f}: va al centro con el video a pantalla completa -> te tapa la cara (cambiá la ventana)")
        v = D.get("video", {})
        if D.get("formato") == "9:16" and v.get("w", 0) > v.get("h", 1):   # grabado horizontal -> reel vertical: no hay lugar libre
            for b in els:
                if b["type"] in ("icono", "lista", "captura", "comparar", "barras", "linea", "numero", "cita", "paso") and modo_en(b["s"] + 0.2) == "FULL":
                    prob.append(f"{b['type']} {b['s']:.2f}: grabación horizontal en 9:16 a pantalla completa no deja lugar -> ventana ARRIBA/ABAJO para este elemento")
    if D.get("subtitulos"):   # los subtítulos van abajo: los gráficos de abajo se pisan con ellos
        for b in els:
            if b.get("lado") in ("abajo", "abajo_esq", "centro") or (b.get("lado") is None and b["type"] in ("etiqueta",)):
                prob.append(f"{b['type']} {b['s']:.2f}: con subtítulos, '{b.get('lado', 'abajo_esq')}' se pisa con ellos -> usá 'arriba' (9:16) o 'izq'/'der' (16:9)")
    gaps = []   # ritmo: huecos sin nada nuevo
    ev = sorted([b["s"] for b in els] + [x[0] for x in D.get("ventana", [])] + [x["s"] for x in D.get("escenas", [])] + D.get("acentos", []))
    lim = D.get("ritmo_max", 15)
    for x, y in zip([0] + ev, ev + [DUR]):
        if y - x > lim: gaps.append(f"{x:.1f}–{y:.1f} s ({y - x:.1f} s sin nada nuevo)")
    for p in prob: print("PROBLEMA ", p)
    for g in gaps: print("RITMO    ", g)
    print(f"revisión: {len(prob)} problemas, {len(gaps)} huecos de ritmo (máx {lim} s) · {len(els)} elementos · {DUR} s")
    return len(prob)
