#!/bin/bash
# Uso: bash transcribir.sh <audio_o_video> <salida.json> [modelo=medium] [idioma=es]
# Transcribe EN TU COMPUTADORA (whisper.cpp vía HyperFrames, sin instalar Python ni subir nada) con tiempos por palabra.
# Salida: lista JSON [{"text","start","end"}, ...]  (es el formato que leen anclas.py, cortar_silencios.py y tomas_repetidas.py)
# Modelos: small (rápido, ~0,5 GB) · medium (recomendado en español, ~1,5 GB) · large-v3 (el más preciso, ~3 GB, lento).
# La primera vez baja el modelo: puede tardar varios minutos. Ojo: los modelos terminados en .en son SOLO inglés.
set -e
IN="$1"; OUT="$2"; MOD="${3:-medium}"; LANG_="${4:-es}"
[ -f "$IN" ] || { echo "No encuentro: $IN"; exit 1; }
ABS_IN="$(cd "$(dirname "$IN")" && pwd)/$(basename "$IN")"
TMPD="$(mktemp -d)"
# whisper trabaja mejor con WAV mono 16 kHz
ffmpeg -v error -y -i "$ABS_IN" -vn -ac 1 -ar 16000 "$TMPD/audio16k.wav"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$TMPD/audio16k.wav")
echo "Transcribiendo ${DUR%.*} s de audio con el modelo $MOD ($LANG_)…"
# el tiempo límite se escala solo; en compus lentas se puede subir con HYPERFRAMES_TRANSCRIBE_TIMEOUT_MS
npx -y hyperframes transcribe "$TMPD/audio16k.wav" -d "$TMPD" -m "$MOD" -l "$LANG_" --json > "$TMPD/res.json" 2> "$TMPD/log.txt" || { tail -20 "$TMPD/log.txt"; exit 1; }
python3 - "$TMPD/transcript.json" "$OUT" <<'PY'
import json, sys
w = json.load(open(sys.argv[1]))
out = [{"text": x["text"].strip(), "start": round(float(x["start"]), 3), "end": round(float(x["end"]), 3)} for x in w if x.get("text", "").strip()]
json.dump(out, open(sys.argv[2], "w"), ensure_ascii=False, indent=0)
# texto legible, en renglones cortados en los puntos
line, t0 = [], None
for x in out:
    if t0 is None: t0 = x["start"]
    line.append(x["text"])
    if x["text"][-1:] in ".?!" or len(line) > 22:
        print(f"[{t0:7.2f}] {' '.join(line)}"); line, t0 = [], None
if line: print(f"[{t0:7.2f}] {' '.join(line)}")
print(f"\n{len(out)} palabras -> {sys.argv[2]}")
PY
rm -rf "$TMPD"
