# Uso: python3 verificar_sync.py <referencia_voz> <final.mp4>
# Compara la voz del video final contra la voz recortada en 3 puntos. Debe dar 0 ms (±1).
# (Por qué: el audio que Remotion saca de un video embebido sale ~1 cuadro atrasado. Por eso siempre se renderiza
#  MUDO y se une la voz original aparte.)  Solo biblioteca estándar + ffmpeg.
import sys, subprocess, array
src, out = sys.argv[1], sys.argv[2]; SR = 2000
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", out], capture_output=True, text=True).stdout)
def rd(f, ss, t):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, ss):.3f}", "-t", f"{t:.3f}", "-i", f, "-ac", "1", "-ar", str(SR),
                          "-af", "highpass=f=120", "-f", "s16le", "-"], capture_output=True).stdout
    x = array.array("h"); x.frombytes(raw[: len(raw) // 2 * 2]); return [v / 32768 for v in x]
peor = 0
for t0 in (dur * 0.15, dur * 0.5, dur * 0.8):
    a = rd(src, t0 + 0.25, 2.0)          # 2 s de la referencia
    b = rd(out, t0, 2.5)                 # 2,5 s del final: busca ±0,25 s
    if len(a) < SR or len(b) < len(a): continue
    best, lag = -1e18, 0
    for k in range(0, len(b) - len(a) + 1):
        s = 0.0
        for i in range(0, len(a), 2): s += a[i] * b[i + k]
        if s > best: best, lag = s, k
    ms = (lag / SR - 0.25) * 1000
    peor = max(peor, abs(ms))
    print(f"t={t0:6.1f}s  desfase de la voz: {ms:+.1f} ms")
print("SINCRONÍA OK" if peor <= 2 else "OJO: la voz está desfasada; revisá la referencia y el render")
