#!/bin/bash
# Uso: bash unir_audio.sh <video_render_mudo.mp4> <mezcla.wav> <salida.mp4> [true_peak=-1] [referencia_voz]
# Une el video (renderizado SIN sonido) con la mezcla, normaliza a -14 LUFS (lo que usa YouTube) con limitador suave,
# AAC 320k 48 kHz, y verifica que la voz quede sincronizada (debe dar 0 ms).
# referencia_voz por defecto: work/cortado.mov (personal) o work/cortado.wav (faceless).
# Reels/Shorts: pasá -1.5 como 4º argumento (los celulares toleran menos picos).
set -e
V="$1"; A="$2"; O="$3"; TP="${4:--1}"; REF="$5"
if [ -z "$REF" ]; then if [ -f work/cortado.mov ]; then REF=work/cortado.mov; else REF=work/cortado.wav; fi; fi
# limitador suave antes de normalizar: deja llegar a -14 LUFS en modo lineal (sin bombeo) y sin recortes
LIM="alimiter=limit=0.4:attack=4:release=80:level=false:latency=1"
M=$(ffmpeg -hide_banner -i "$A" -af "$LIM,loudnorm=I=-14:TP=$TP:LRA=11:print_format=json" -f null - 2>&1 | sed -n '/{/,/}/p')
g(){ echo "$M" | python3 -c "import json,sys;print(json.load(sys.stdin)['$1'])"; }
ffmpeg -v error -y -i "$V" -i "$A" -map 0:v -map 1:a -c:v copy \
  -af "$LIM,loudnorm=I=-14:TP=$TP:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true,aresample=48000" \
  -c:a aac -b:a 320k -shortest -movflags +faststart "$O"
ffprobe -v error -show_entries stream=width,height:format=duration -of default=nw=1 "$O"
ffmpeg -hide_banner -i "$O" -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+(I:|Peak:)" | tail -2
python3 "$(dirname "$0")/verificar_sync.py" "$REF" "$O"
