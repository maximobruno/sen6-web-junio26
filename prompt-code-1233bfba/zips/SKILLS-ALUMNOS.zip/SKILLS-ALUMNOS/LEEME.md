# SKILLS PARA AUTOMATIZAR TU CANAL — leeme primero

Esta carpeta tiene los "manuales de instrucciones" que Claude va a leer cuando produzca tus
videos. No tenés que abrirlos ni entenderlos: solo instalarlos.

---

## Cómo se instalan (30 segundos)

1. Poné **esta carpeta entera** en tu Escritorio.
2. Abrí la app de Claude en la carpeta de tu canal.
3. Pegale este mensaje:

```
En mi Escritorio está la carpeta SKILLS-ALUMNOS.
Instalá las skills que hay adentro donde corresponde
(están agrupadas en subcarpetas: instalá el contenido,
no las subcarpetas). Después decime cuáles quedaron
disponibles.
```

Listo. Para comprobarlo, preguntale: **"¿qué skills tenés instaladas?"**

---

## Qué hay en cada carpeta

### 1-OBLIGATORIA
Instalala sí o sí, hagas el canal que hagas.

| Skill | Para qué |
|---|---|
| `full-output-enforcement` | Evita que el guion de 1.800 palabras te salga cortado a la mitad con un "…[continúa]". |

### 2-VIDEO-AVANZADO
Solo si tu canal lleva **textos animados, gráficos en movimiento o animación programada**.
Si tu canal es narración sobre imágenes (que es lo más común y lo más barato), **saltealo**:
no lo necesitás y solo te agrega ruido.

| Skill | Para qué |
|---|---|
| `hyperframes` | La puerta de entrada. Sin esta, las demás no se usan bien. |
| `hyperframes-core` | Cómo se arma una composición: estructura y tiempos. |
| `hyperframes-cli` | Previsualizar y renderizar. |
| `hyperframes-animation` | El movimiento y las transiciones. |
| `hyperframes-keyframes` | Movimiento fino, 2D y 3D. |
| `hyperframes-creative` | Paletas, tipografía y dirección de arte. |
| `hyperframes-registry` | Bloques y componentes ya hechos. |
| `motion-doctrine` | Que el video se sienta un solo movimiento de cámara y no una pila de diapositivas. |
| `media-use` | Consigue música, efectos, iconos y logos, y los deja como archivo en tu carpeta. |
| `general-video` | Videos largos o de varias escenas cuando ningún formato encaja. |

### 3-SEGUN-TU-CANAL
Instalá solo las que te correspondan. Podés volver por las otras más adelante.

| Skill | Instalala si… |
|---|---|
| `youtube-explainer` | Hacés explainers narrados largos, con mascota o con un sistema visual propio. |
| `faceless-explainer` | Hacés explainers faceless a partir de un texto o un tema. |
| `motion-graphics` | Necesitás piezas cortas: logo animado, contador de datos, placa de título. |
| `embedded-captions` | Hacés vertical (Shorts, Reels, TikTok) y querés subtítulos incrustados. |
| `captions-overlay` | Va junto con la anterior: dónde y cómo se colocan los subtítulos. |
| `cut-the-curve` | Querés transiciones que se sientan cine y no cortes secos. |
| `seam-craft` | Va junto con la anterior: cómo se unen dos escenas. |
| `oversized-cursor` | Mostrás pantallas, apps o webs y necesitás un cursor grande que guíe la mirada. |
| `brandkit` | Querés armar la identidad visual del canal antes del primer video. |

---

## Las que NO están acá, porque ya las tenés

`skill-creator` y `docx` **vienen incluidas con la app de Claude**. No las busques en esta
carpeta.

- `skill-creator` es la que convierte tus respuestas del cuestionario en el manual de tu canal.
  Es la más importante de todas.
- `docx` genera el guion en Word sin romperte los acentos.

**Comprobalo antes de empezar:** preguntale a Claude *"¿tenés disponible skill-creator y docx?"*.
Si te dice que no, pedile: *"instalame el pack de skills de Anthropic"*.

---

## Las que tampoco están, a propósito

Las skills de los canales que vimos en clase (arte, filosofía, fútbol, autosuficiencia) **no
están en esta carpeta**, y no es un olvido.

Cada una guarda el ADN medido de *ese* canal: su duración, su ritmo de corte, su fórmula de
guion, sus competidores. Copiarlas a tu canal no te ahorra trabajo — te hace producir el canal
de otro.

**Tu skill la vas a construir vos en el paso 8**, con tus datos y tus reglas. Ese es el
ejercicio. Lo que está en esta carpeta son las herramientas; el manual de tu canal lo escribís
con el cuestionario.
