# How This Skill Works — Step by Step (for the scriptwriter)

Plain-English walkthrough of what the skill does when you run it, in order. Run it
yourself and record each step, because that recording is the footage for the video.

## Install (what the viewer does after commenting "VOX")

1. Get the zip.
2. Unzip it. You get a `youtube-explainer` folder.
3. Drop that folder into the project folder you want to work in.
4. Open Claude Code in that project and call the skill by name.

That is the whole install. The only other thing to connect is the three tools below.

## The three tools it uses (one-time setup)

- **Higgsfield** — runs Gemini Omni for the images AND the animation.
- **ElevenLabs** — the voiceover.
- **HyperFrames** — assembles the frames and the voice into the final video.

(ffmpeg is used locally for the finishing pass.)

## What the skill does, step by step

1. **Checks its toolkit.** It confirms which tools it needs and which you have
   connected, and tells you if anything is missing. Nothing breaks silently.
2. **Topic + working title.** You give it a topic; it locks a working title.
3. **Config (it asks, never assumes):** duration, aspect ratio, the visual style
   (pick Documentary Vox), and the voice (your ElevenLabs voice, by name). It sets
   the image model (GPT Image 2) and the video model (Gemini Omni).
4. **Cost gate.** It reads your Higgsfield balance and shows the estimated cost in
   dollars before it generates anything. You approve.
5. **Research.** It web-researches the topic into a fact sheet with real sources.
   You check the facts.
6. **Script.** It writes a tight spoken script from those facts. You approve it. (Gate 1)
7. **Voiceover.** One ElevenLabs pass in your chosen voice. You listen and approve the read.
8. **Timestamps.** It transcribes the voiceover to word-level timing. This becomes
   the clock everything syncs to.
9. **Segment plan.** It slices the video into beats bound to the voice and shows you the plan.
10. **Style sheet.** It builds ONE reference board, the rulebook for the Vox look
    (palette, halftone cutouts, texture, one accent color). You approve it. (Gate 2)
11. **Keyframes.** It generates one frame per beat, every frame referencing the style
    sheet so nothing drifts. You approve them. (Gate 3)
12. **Animate.** It hands each frame to Gemini Omni with one committed camera move per
    shot. (Real faces use a generic figure; the preset popup is pre-declined so the
    batch never stalls.)
13. **Assemble + finish.** It stitches the clips under the voiceover in HyperFrames,
    adds a music bed, and applies the cut-on-twos step (the stepped frame rate that
    makes it read as Vox, not a computer).
14. **Deliver + cost.** It renders the final video, prints the exact cost it took
    (spend-only), and gives you the folder where everything saved.

## The one rule

The skill gets you most of the way in one run. You add the topic and the value that
makes it yours.
