---
name: youtube-explainer
description: Produce a complete narrated, stylized animated explainer video for YouTube from a topic — built VOICE-FIRST: research → retention-engineered script → one continuous voiceover → word-timestamp sync → lock the world once (a mascot's character + sets, OR one style-system sheet) → animate every beat from those locked references → assemble in HyperFrames → upscale. Forks on a `mascot` key (storyboard path vs single-generation / Vox path). Multi-style and brand-neutral. Renders on the Higgsfield MCP by default (GPT Image 2 images, Gemini Omni Flash video, Higgsfield upscale); ElevenLabs voice, faster-whisper timing, HyperFrames assembly. Every image prompt is written with the prompt-cine skill (6 boxes: framing, angle, subject+action, focus, light, color). Use for producing long-form faceless / animated / narrated explainer videos for YouTube. For channel-cloning use channel-research-and-video-generator; for the Higgsfield platform's own pipeline use higgsfield-video-creation.
---

# YouTube Explainer — the proven pipeline (v2, locked 2026-07-05)

Turn a topic into a finished narrated animated video the way owner-judged tests
proved works: **voice first → lock the world once → blueprint each beat →
animate → cut the picture to the voice.** The world is locked as reference
images (a character + sets for a mascot video, or one style-system sheet for a
graphic one); every beat's picture is generated FROM those locked references, so
nothing drifts. Every law below exists because its absence produced a specific,
observed failure. Deviations are bugs.

**The two core principles everything else serves:**

1. **The voice is the master clock.** Narration is generated before any image,
   transcribed to word timestamps, and every visual decision is bound to it.
   Picture confirms the words at the moment they're spoken.
2. **Consistency is carried by locked references, not by chance.** The character,
   the sets, and the hero props — or, with no mascot, the one style-system
   sheet — are approved as reference images ONCE, then bound to every blueprint
   and every animation. Anything NOT handed to a generation as a locked
   reference will be reinvented differently every call — the root cause of all
   drift (the lady changing, the store changing, the terminal morphing).
3. **Every IMAGE prompt is written with Prompt Cine (SEN6 rule).** Style
   sheet, character sheet, set plates, props, storyboards and keyframes: all
   of them are built with the `prompt-cine` skill's 6-box structure —
   ENCUADRE + ÁNGULO + SUJETO+ACCIÓN + FOCO + LUZ + COLOR — using its local
   reference base. See **"Image prompts = Prompt Cine"** below. Video prompts
   (Step 15) keep the camera laws: Prompt Cine is still-image only.

## Requirements

1. **Higgsfield MCP connector** available (the ONLY engine — tools like
   `generate_image`, `generate_video`, `upscale_video`, `balance`,
   `job_status`). Everything runs on Higgsfield; fal is not used.
2. **ElevenLabs** for voice (`ELEVENLABS_API_KEY`, or its stock voices) via
   `scripts/tts.py`, AND for the **script-driven music bed** via
   `scripts/gen_music.py` (ElevenLabs Music, same key).
3. **`faster-whisper`** installed locally — the timing spine (word timestamps;
   base.en / cpu / int8).
4. **HyperFrames** for assembly (`npx hyperframes`), plus `ffmpeg` / `ffprobe`
   on PATH.
5. If the channel already has a locked style bible / anchor pack (a `channel/`
   folder with STYLE-BIBLE.md, a character sheet, set plates, prop references),
   reuse it; never regenerate an approved anchor without the user asking. A
   brand-new channel builds it once on its first video.
6. **The `prompt-cine` skill installed** (it ships in the SEN6 kit at Prompt
   Code, next to this pack). Check it at the start of the run: if it is not
   available, STOP and tell the student, in Spanish, to install Prompt Cine from
   the SEN6 kit before generating any image. Never fall back to writing image
   prompts freehand.

---

## Image prompts = Prompt Cine (applies to Steps 2, 11, 13)

Every `generate_image` prompt in this skill is built with the `prompt-cine`
skill, never written freehand. Load it and use its `buscar.mjs` and `kb/`
exactly as that skill describes (`PC_DIR` = its base directory).

**1. Lock the cinematic look once (Step 2).** Ask the student for a visual
reference in their own words ("como Blade Runner", "fotografía de Deakins",
"documental de National Geographic", "un cuadro de Hopper"), or derive one
from the topic if they have none. Run
`node "PC_DIR/buscar.mjs" "<reference>"` and fix, for the whole video:
- **04 LUZ** and **05 COLOR** — one choice each from the reference's fiche;
- the **FOCO technique** (camera / lens / emulsion / format) when the fiche has
  `tecnica` — skip it for illustrated presets (paper, clay, vector…), where
  real lenses make no sense; keep only the depth-of-field part.
These go into the manifest as `cine: {referencia, luz, color, tecnica, fuentes}`
and into the channel's STYLE-BIBLE if there is one. They are LOCKED like the
style sheet: repeated word-for-word in every image prompt. If the reference is
not in `kb/`, follow Prompt Cine's hard rule (search the web in English AND
Spanish, verified data only, never invent gear).

**2. Per image, only these boxes change:** **01 ENCUADRE**, **02 ÁNGULO** and
**SUJETO + ACCIÓN** (frozen instant, no motion verbs), taken from the beat's
shot plan (Step 10). Pick them from the reference's fiche options; vary them
across beats (wide / medium / close / macro, eye level / low / high) so the
video never repeats the same shot twice in a row.

**3. Assemble each image prompt in this order:**
```
<01 encuadre>, <02 ángulo>, <sujeto + acción>, <03 foco>, <04 luz>, <05 color>

[STYLE BLOCK — the preset / Vox variant, verbatim, as this skill requires]
[reference bindings by job_id — "same visual style, palette and rendering
technique as the reference", anchors "EXACTLY like the reference"]
```
The 6-box line goes FIRST; the locked style block and the reference bindings
stay exactly as the rest of this skill specifies (they are what keeps
consistency). Where the two disagree, the 6-box LUZ/COLOR win over a preset's
generic lighting words, and the preset's MATERIALS (paper, clay, halftone…)
win over photographic realism.

**4. Prompt Cine's rules hold inside this skill:** no camera movement words in
image prompts (dolly, push-in, pan, zoom live only in Step 15); no empty
adjectives ("cinematic", "epic", "masterpiece", "8k"); never "in the style of
<film/brand>" — the reference is translated into its visual traits.

**5. Show it in Spanish.** At Gate 2 and Gate 3, next to each image, show its
6 boxes as Prompt Cine delivers them (`**01 ENCUADRE** — <en> · <es>` …) and a
**Fuentes:** line, so the student learns what each shot is doing.

## PHASE A — Plan (cheap: text and approvals only)

### Step 1 — Topic + working title
Confirm the topic and its angle, and a **working title** — the promise the
script must deliver (Step 6 checks the hook against it). If the channel keeps a
topic slate, pull the next topic and hold the two-question test (have I wondered
this? / have I never seen it answered?).

### Step 2 — Style, config & the two keys
Confirm duration, and:

**Voice — ASK, never assume.** This skill is shared; every user connects their
OWN ElevenLabs account, so there is no house voice. **Ask whether they have a
particular voice in mind (by name).**
- If they name one → resolve it against THEIR connected library with
  `scripts/list_voices.py` (case-sensitive, id-first) and use that voice. If
  the name doesn't match, show the closest matches from their library and let
  them pick.
- If they're unsure → run `list_voices.py`, **suggest one or two** that fit the
  script's tone (name them), but still get an explicit pick.
- A stored default (env `VOICE_ID`, a channel bible) is a SUGGESTION to offer,
  never an auto-choice. The user chooses the voice BY NAME before any TTS runs.

**Aspect ratio — ASK, never assume**:
**16:9** (standard YouTube long-form) or **9:16** (Shorts / Reels / TikTok);
other ratios (1:1, 4:5) on request. The chosen ratio is LOCKED for the whole
run — every reference image, style sheet, storyboard panel, keyframe, clip,
the HyperFrames canvas, and the upscale inherit it (mixing ratios mid-run
breaks the locked references). Store it in the manifest as `aspect`. If the
channel has a locked style bible, LOAD it and skip the style questions;
otherwise pick a style from
[references/style-presets.md](references/style-presets.md) (Vox, Paper Cut, …).
**Then lock the cinematic look with Prompt Cine** (reference → LUZ, COLOR,
FOCO technique) as described in "Image prompts = Prompt Cine".

Set the two keys that steer the whole run:
- **`mascot` (Y/N)** — does a recurring character carry this video? This forks
  the pipeline from Phase C on: **YES → the storyboard path** (character + set +
  prop anchors → 2×2 storyboards → reference-to-video expand); **NO → the
  single-generation path** (one style-system sheet → per-beat keyframe →
  image-to-video — the Vox route).
- **`models`** — everything runs on **Higgsfield** (never fal). ASK which
  **image model** and which **video model**: default **`gpt_image_2`** (strong
  typography, which the Vox look needs) for images and **`gemini_omni`** for
  video. Offer the Higgsfield alternates (`nano_banana_pro` /
  `nano_banana_2_lite` for images) only if the user wants them; `upscale_video`
  always finishes.

### Step 3 — Cost gate (in DOLLARS)
The user NEVER sees credits — only dollars. Credits are internal plumbing;
convert them and speak dollars. State the toolkit once, then quote per video.

**The toolkit (fixed monthly — stated once, not per video):**

| Tool | Its job | Monthly |
|---|---|---|
| Claude Pro | writes + runs the skill | $20 |
| Higgsfield (Plus / Ultra) | images + animation + upscale | $39 / $99 |
| ElevenLabs (Starter) | voiceover | $6 |
| HyperFrames | stitches the 10s clips into one video | **Free (local)** |

Rule of thumb for the audience: **~$65/mo toolkit + ~$7 per finished minute.**

**Per-video estimate (before any generation):**
- Read the plan from `balance` → $/credit (Ultra $0.033, Plus $0.039, Starter
  $0.075). `get_cost:true` on one representative image (chosen model + quality)
  and one clip (`gemini_omni` at the planned seconds), multiply by the real
  counts, add a 15% re-roll buffer, then **convert credits → dollars at the plan
  rate.** Voice = ElevenLabs (characters → $, usually "$0, covered by your
  plan"). Assembly = HyperFrames ($0). Upscale = measured at delivery (no
  preflight). **Announce, don't block** — only stop if the balance can't cover it.

Present as ONE dollar line with a small breakdown, e.g.:
> This 8-min no-mascot video ≈ **$56**. Animation ~$48, images ~$2, voice $0
> (in your plan), assembly free (HyperFrames), upscale measured on delivery.
> You have ~$120 in Higgsfield credits. Rendering.

The real total lands in the delivery receipt (Step 19), including the upscale
pass that couldn't be pre-quoted.

### Step 4 — Run folder + manifest
`explainer-runs/<slug>/` with `frames/ boards/ clips/ audio/`. `manifest.json`
tracks every artifact's status AND its Higgsfield `job_id`. Before generating
anything, check the manifest; skip what exists. A crash resumes; nothing
re-bills.

### Step 5 — Research → fact-sheet
Web-research the topic into `fact-sheet.md`: 10-20 verified facts WITH clickable
sources, key numbers, misconceptions. Show the facts + links in chat for the
user's own accuracy QC. The script may only claim what's here.

### Step 6 — Script, written to be spoken
Write the full script per [references/script.md](references/script.md): one
continuous spoken essay on the retention format — cold-open-on-payoff, then
Hook → Body → Payoff for short-form (≲90s) or Hook → Intro → Chapters → Ending
for long-form, an open loop about once a minute (all tracked to closure),
concrete over abstract — that delivers on the working title's promise. Voice-first: write
flowing prose for ONE continuous VO; do NOT pre-chop into blocks here — the
segment slicing happens later from the word-timestamps (Steps 9-10). Run the
self-check quality gate before showing anything.

### Step 7 — 🚦 GATE 1: script + sources
Show the full script and the sources behind it. Nothing visual generates until
the user approves. Edits here are free.

---

## PHASE B — Voice & timing (the sync spine)

### Step 8 — Generate the voiceover FIRST
ONE ElevenLabs call for the whole narration (one call = one consistent voice)
via `scripts/tts.py`. Voice name/ID is validated once and stored — names are
case-sensitive ("Rachel", not "rachel").

**🚦 VOICE CHECK (mini-gate).** Give the user a clickable link to the generated
voiceover file and get an explicit OK on the voice and the read BEFORE
transcribing (Step 9). The VO is the master clock — every timestamp, segment
window, clip duration and cut hangs on it; a wrong voice discovered at
assembly costs the entire picture-lock. A re-take here is one cheap API call.

### Step 9 — Transcribe to word timestamps
faster-whisper (word_timestamps=True) → `audio/word-timestamps.json`. This is
the master clock, not a subtitles nicety.

### Step 10 — Segment breakdown bound to the voice
Slice the script into segments. Each segment gets:
- a **trigger phrase** and its start/end window from the timestamps (window =
  this trigger to the next; 5-10s each),
- a **beat type**: character / concept / diagram (concept + diagram beats carry
  NO people — see the CHARACTER GATE),
- its **shot plan**: mascot path = the 4 moments its 2×2 storyboard will show
  (vary wide / medium / close / macro, a mini-arc per segment); no-mascot path =
  the single keyframe the beat animates from,
- its **energy zone** — `intro` (max energy, every beat bold, no restraint) or
  `body` (graded, high floor), read from where the script marks the intro→body
  handoff; a short-form video (≲90s) is ALL `intro`. Feeds the ENERGY-ZONE law
  (Step 15).

**Present the breakdown in chat BEFORE Phase C generates anything:** a table of
segment / timecode window / trigger phrase / beat type / planned shot
(Prompt Cine ENCUADRE + ÁNGULO) / energy zone / camera (variant + move), so the user sees exactly what will be generated
against which seconds of their voice. **The table MUST open by declaring the
run's CAMERA DOCTRINE, derived from length: short-form (≲90s) → the ENERGY-ZONE
law governs EVERY clip (one committed bold move on every beat — Variant B/C
beats keep their structure but never get subtle-drift cameras); long-form
(>90s) → variant-by-beat-type with energy graded by zone (max in the intro,
high floor in the body).** Never decide the camera regime silently per clip.
Announce and continue (not a hard gate — Gates 2 and 3 still approve the
actual pictures), but edits requested here are free; every step after this
costs money.

---

## PHASE C — Lock the world (forks on the `mascot` key)

Both paths lock the look ONCE and bind it downstream. All images are Higgsfield
`generate_image` with **`gpt_image_2`** (base — strong typography, which the Vox
look needs) or **`nano_banana_pro` / `nano_banana_2_lite`** (backups, if the
style drifts or to cut cost). Generation is async: submit → poll
`job_status {jobId, sync:true}` → **keep the returned `job_id`**, because a
reference downstream is passed as that job_id (Higgsfield binds media by
media_id / job_id, never a file path or URL). Store every job_id in the manifest.

### Step 11 — Assets, per the mascot key
Approved reference images, all at the run's `aspect` (Step 2). Every prompt
here is built with Prompt Cine (6-box line first, then the locked style block).

**Path M (mascot = YES) — anchors:**
- **Character model sheet** — front + three-quarter (avoid full profile), FACE
  fully defined including the MOUTH (an undefined feature drops on a head-turn).
- **Set plates** — one per recurring location, INCLUDING its resident cast.
- **Prop references** — one per hero object.
Only the CHARACTER and the STYLE persist across videos; sets/props are per-video.

**Path S (mascot = NO) — one style-system sheet (the "rulebook"):** a single
reference board at the run's aspect ratio that locks the look — palette, type, components, background
world — in one image (the Vox master sheet; the same idea works for any style).
Optionally a stage/background plate + hero-prop refs. No character sheet. Build
it from the master-sheet template in
[references/vox-prompt-pack.md](references/vox-prompt-pack.md).

### Step 12 — 🚦 GATE 2: asset approval
Show every asset; the user approves or corrects (cheap to iterate here).
Approved assets are LAW downstream. Record approval + job_ids in the manifest.

---

## PHASE D — Blueprint the shots (forks)

### Step 13 — Path M: anchored 2×2 storyboards
One clean 2×2 sheet per segment (four panels, each at the run's aspect), `generate_image` gpt_image_2,
the relevant anchors passed AS REFERENCES (set plate + character + props, by
job_id). Each panel is described with its own Prompt Cine ENCUADRE + ÁNGULO +
SUJETO+ACCIÓN; FOCO, LUZ and COLOR are the locked ones, identical in all four.
Rules: ALL FOUR panels the SAME location/cast/props, identical across
panels; CLEAN (no panel numbers/captions/labels — only the video's whitelisted
diegetic words); 2×2 grid only (each cell at the run's aspect); four panels = the segment's
4-frame plan. Build the LABELED copy programmatically (PIL overlay: title, time
range, per-panel timecode) for human review ONLY — never fed to animation.

### Step 13 — Path S: per-beat keyframes
One keyframe per beat, `generate_image` gpt_image_2, the **style-system sheet
passed as the reference** (by job_id) + the beat's Prompt Cine 6-box line (its
ENCUADRE, ÁNGULO, SUJETO+ACCIÓN; the locked FOCO, LUZ, COLOR) + the full-bleed line +
"same visual style, palette, and rendering technique as the reference."
**Logos:** lock the real logo in the still — it animates fine. **Real faces:** the
black bar gets a face past IMAGE gen, but `gemini_omni` still BLOCKS the animation
step as `nsfw` (confirmed 2026-07-10) — the black-bar-then-animate trick does NOT
clear the video filter. So for an ANIMATED face beat, use a **generic invented
figure** (an anonymous cutout resembling no real person; keep the black bar as a
style device) or **Ken-Burns the approved still** (ffmpeg `zoompan`) instead of
animating it. Reserve real-face stills for beats you will not animate.

### Step 14 — 🚦 GATE 3: blueprint approval
Show the labeled boards / keyframes stacked, each with its 6 Prompt Cine boxes
in Spanish. The user checks story, consistency,
shot variety, continuity. Then run `scripts/check_frames.py --aspect <run
aspect>` (aspect + sparse / boxed check), eyeball the survivors, re-roll
anything off (~cheap). This is the
last cheap checkpoint — do not animate one frame before it passes.

---

## PHASE E — Animate (both paths converge on `gemini_omni`) — the expensive step

`generate_video`, model **`gemini_omni`**, duration = the segment's voice window
(4–10s), 720p (the model's ceiling — upscaled in Phase F), references bound by
job_id:
- **Path M:** references = `[storyboard, set plate, character sheet, prop refs]`
  — the model EXPANDS the storyboard into one connected shot.
- **Path S:** reference = `[keyframe]` ONLY — straight image-to-video. Do NOT
  also pass the style sheet at this step: a flat rulebook image as a 2nd video
  reference ANCHORS the model to stillness and damps the camera move (confirmed
  A/B — the same keyframe with the board attached moved far less). The keyframe
  already carries the locked style; STYLE-LOCK is held by restating the style
  paragraph in words. The style sheet is a KEYFRAME-step reference only.

**NOTE — the keyframe is a REFERENCE, not a locked first frame.** `gemini_omni`
takes the image as a style/content guide; it does NOT guarantee the clip opens on
that exact frame (it has no `start_image` parameter), so a clip may begin already
mid-move or slightly off the approved keyframe. If the exact opening matters:
(1) add **"open on the attached frame as frame ONE, then begin the move"** to the
prompt; (2) for beats where it's critical, use a **start-frame-locking model**
(Kling 3.0 / Seedance `start_image`) instead; (3) or briefly hold the keyframe
still at the head of the clip in assembly. The crossfades (Step 17) also soften
any opening drift.

### Step 15 — The prompt laws (load-bearing; apply per path)
**🚦 SHOT-PLAN PREVIEW (before the FIRST `generate_video` call).** Present in
chat, per segment: the camera doctrine (restated from Step 10 — short-form
≲90s → energy-zone law on every clip; long-form → variant-by-beat-type,
graded), the variant chosen, AND the full 3-part SHOT (law 4b below: named
background + FG thrusting at the lens + 2-3 rack-focus landings) each clip will
be prompted with — so the user reviews what every animation will DO before it
costs money. Edits here are free text; a re-roll later is not. If the doctrine
was never declared, stop and declare it now — no clip generates under an
undeclared camera regime or an unshown shot.
The reusable scaffolding — the per-clip STYLE/SHOT/AUDIO/AVOID skeleton and the
three style-block variants — is in
[references/vox-prompt-pack.md](references/vox-prompt-pack.md); the laws below are
what every block must satisfy. **Pick the right variant per beat type and PASTE ITS BLOCK VERBATIM as the
clip's [STYLE BLOCK] — never write a custom style paragraph in its place.**
The variant text (fill only its `<placeholders>`) IS the mechanism: the 3D
parallax comes from its exact sentences ("deep 3D paper diorama … layers
separated in real space … foreground elements crossing close to the lens …
the camera is an actor"). Rewriting it "in your own words" silently drops the
dimensional language and produces flat clips (observed failure, 2026-07-10).
Variant A (camera-as-actor) for scene / character / metaphor beats (most
clips), Variant B (strict visual system) for stat-number hero reveals,
Variant C (locked cutout-collage stage) for chart / grid / bar beats.
1. **EXPAND law (Path M)** — "<ref 0> is the STORYBOARD: four frames of ONE
   continuous scene in reading order. Animate THROUGH them as ONE continuous
   UNBROKEN shot: open already fully inside frame one (NEVER show the grid,
   panels or borders), flow through frames two-three-four as WAYPOINTS of a
   single take, generating all the in-between motion. NO cuts."
2. **STYLE-LOCK (both, critical on Path S)** — restate the style in the video
   prompt, not just via the reference, or Omni transforms the style mid-clip.
3. **ANCHOR bindings (Path M)** — set/character/props "EXACTLY like the
   reference … unchanged"; character "including the MOUTH."
4. **CAMERA law — the camera is an ACTOR (do NOT water this down).** ONE
   committed, CONFIDENT move per clip: a bold push-in / dive / crane / rail-ride
   that FLIES BETWEEN the physical paper layers with true parallax, a foreground
   cutout crossing close to the lens (motion blur ok), a rack focus.
   **PARALLAX FLOOR — verbatim, never paraphrased:** every Variant-A SHOT block
   (and every max-energy-zone clip) must contain these phrases word-for-word:
   *"deep 3D paper diorama"*, *"layers separated in REAL space"*, *"strong
   shallow depth of field"*, *"one foreground cutout crossing close to the lens
   with motion blur"*, *"true parallax between foreground, midground and
   background"*. Diluting these to "some parallax" or moving them into the
   STYLE paragraph instead of the SHOT is the observed cause of flat clips.
   **PACING words are load-bearing too:** the model renders constant-velocity
   moves unless told otherwise — write the speed profile explicitly
   ("ACCELERATES hard", "whip-fast final third", "snaps to a stop with
   overshoot"), never just "committed move". Bold but
   SINGULAR — one move, not five, no cuts. Energy comes from the CAMERA moving
   through RIGID layers; the anti-morph and anti-glossy laws keep it safe, so you
   NEVER trade camera energy for safety. A gentle / restrained / static camera is
   the #1 cause of a flat, low-energy video (this exact timidity was a real
   failure — apply the pack's Variant A in full). Match intensity to the
   narration's tension: boldest on the punch beats, still a committed move on the
   calm ones — never a dead-static clip. **Make it ONE-WAY** — the final frame
   must be a DIFFERENT composition than the opening. A reference-driven model
   anchors to the single input image and will BOOMERANG (drift out and return to
   it) if the described end ≈ the reference framing; describe a clearly distinct
   end and forbid the return: "one-way camera travel, do NOT return to the opening
   framing, no boomerang, no loop."
   **ENERGY-ZONE law (grade by retention position, not evenly — Vox route).**
   Intro / hook (the cold-open through the first chapter doorway, AS MARKED IN THE
   SCRIPT — length is the writer's call, never a fixed timer) AND *all* of a
   short-form video (≲90s): MAX energy, every beat bold, NO restrained clips — this zone exists to
   stop the scroll and pull the viewer in (the immersive mode). A short explainer
   is basically ONE long hook — keep it bold front to back. **In this max-energy
   zone the variant camera floor rises too: Variant B/C beats KEEP their
   structure (hero numbers, pop-up builds, locked stage — the readability layer)
   but trade "subtle drift only" for ONE committed camera move (a bold push-in /
   rise that lands with the final pop event). Subtle-drift-only clips are
   permitted only in a long-form BODY.** Long-form BODY (after
   the hook): graded energy with a HIGH floor — bold on punch/reveal beats,
   controlled-but-still-moving on explanatory beats; contrast makes the punches
   land, and sustained max for ten minutes goes numb — but the calm beats still
   TRAVEL, never a timid crawl. **flat ≠ restrained:** dead-static (first frame ≈
   last) is always wrong; a slow deliberate move that still travels is a legitimate
   calm beat. (Calibrated for the Vox route; other styles are a separate call.)
4b. **SHOT-DENSITY law — the reference's actual structure (this is where the
   energy is; confirmed against the source video's on-screen prompts).** One
   camera move described once and stretched over a 6-10s clip renders as ONE
   slow event and feels empty (observed failure, 2026-07-10). The reference
   never did that — every one of his SHOTs has THREE parts, and this is
   mandatory (worked exemplars in vox-prompt-pack Section E):
   (1) a named BACKGROUND thrown out of focus (depth established);
   (2) FG elements that RACE / ROCKET / WHIP / SPIRAL **past or straight AT the
   lens** with motion blur — the SUBJECT moves violently, not just the camera;
   (3) ONE committed camera move with **2-3 hard LANDINGS**, each snapping a new
   subject into razor RACK FOCUS while the previous blurs away, ending on a
   specific SETTLE (macro / mid-orbit / trembling summit).
   The 2-3 rack-focus landings are what make one 8s clip carry three beats. Use
   named cinematography verbs (whip, rack focus, climb, track, dutch tilt, ALERT
   WASH, deep focus falloff), not adjectives. A SHOT that is one slow move with
   no landings and nothing thrusting at the lens is an unfinished prompt.
5. **CHARACTER GATE** — concept/diagram beats: "There are NO people, characters
   or figures anywhere in this shot."
6. **COUNTING law** — cumulative/sequence beats state the EXACT object count and
   EXACT number of events ("EXACTLY THREE bars rise; total pop-ups: THREE").
7. **COLOR law** — name each key color in words and rule out the near-miss it
   drifts to ("DARK BLUE-GREEN, NOT green; accents warm gold, NOT yellow").
8. **TEXT law — bake it IN, never overlay it.** Any word or number the video
   needs is generated INTO the frame as part of the paper (gpt_image_2 renders
   short big type well, and it inherits the grain/lighting). **Big type only**
   (micro/fine type breaks — think in big blocks); no on-screen text except the
   video's whitelisted diegetic words. **Do NOT lay crisp CSS/vector labels over
   the footage in assembly for a textured/collage style — an overlay never
   matches the grain and reads as pasted-on (a real, tested failure).** If a label
   is wanted, regenerate that beat with the label baked in.
9. **AUDIO law = sound-design only** in the clip, 2–3 named sounds (paper pops,
   whooshes, ticks); no music, no narration, no dialogue — the VO and music bed
   are separate assembly tracks.

### Step 16 — Batching + auto-QC
Consistency is carried by the bound references, not by order — batches are safe.
**Pilot batch** 2–3 representative segments → show the user → catch systemic
flaws before they multiply. Then fire the rest CONCURRENTLY (submit all, poll
all — sequential turns 5 minutes into 40). Per clip, sample first/mid/last
frames: references present, counts right, palette right, no text/grid artifacts,
no morphing. Fail → auto re-roll once with the violated law emphasized → still
bad → flag for human. Update the manifest per clip; a crash resumes without
re-billing.

**Higgsfield operational notes:** (1) Ultra caps at **8 concurrent jobs — for
IMAGES too, not just video** (a 9-keyframe batch had its 9th rejected); fire in
waves of ≤8 and slot the rest in as they finish. (2) `generate_video` may return a
**preset recommendation** (e.g. "IN THE DARK") instead of running your prompt —
and it fires on ANY prompt, NOT just dark / black-bar scenes (observed tripping on
a bright ring reveal and a chart, but NOT on the actual dark slogan). Reliable
pattern: submit → on the popup, resubmit with `declined_preset_id: <that id>`;
once you know the session's preset id, **pre-decline it on ALL remaining clips** so
a batch never stalls.

---

## PHASE F — Assemble, upscale & deliver

### Step 17 — Assemble in HyperFrames (free)
Pull the clips and stitch them under the ONE continuous VO in **HyperFrames**
(the `hyperframes` + `hyperframes-cli` skills → build `index.html`). Trim each
clip to its voice window, cut on the narration beats, duck each clip's diegetic
audio to ~18–20% under the VO. HyperFrames is local and free.

- **Smooth the cuts — never hard-jump.** Hard cuts between shots that have
  *settled* read as jumps. Add a **~0.3s crossfade at every cut**. The deeper fix
  is upstream: prompt clips to keep the camera MOVING through the end (don't
  settle) so the cut lands on motion and hides itself.
- **Music must BUILD, generated FROM the script.** Read the script's emotional
  arc — where tension rises, where the climax lands — and pass a matching prompt
  to **`scripts/gen_music.py`** (ElevenLabs Music, the member's own plan):
  *sparse → rising percussion/ostinato → climax → resolve.* Never ask for
  "minimal / ambient / restrained / drone" — that yields a flat hum. Keep it low
  (~0.12–0.14) and **duck it further (~0.05–0.06) under the most
  information-dense stretch** so the VO stays clear, ramping in/out over ~1.5s.
- **No text overlays for a textured style** (see the TEXT law) — labels live in
  the frames, not the assembly.
- **Cut on twos for the analog styles.** For **Documentary Vox** (and other
  stepped/collage looks) add the stepped-framerate hand-drawn pass so motion reads
  Vox, not computer-smooth — the one Vox signature the prompts can't make (ffmpeg
  `-vf "fps=12,fps=24"` on the clips; full recipe in
  [references/vox-prompt-pack.md](references/vox-prompt-pack.md) Section F). Skip for
  the smooth styles (3D Paper Cut, Flat Vector).

Write a thin, neutral `DESIGN.md` (identity lives in the frames, no brand file).
`npx hyperframes lint` → `preview` for approval → **render only when the user
asks** → 720p `renders/final-720.mp4`.

### Step 17b — Upscale to YouTube resolution
Omni is 720p; upscale the finished MP4 once with `upscale_video`
(`provider: bytedance`, `preset: aigc`, `resolution: 1080p` or `4k`) →
`renders/final.mp4`. ONE pass on the whole video, not per clip. (This is the one
line the cost gate couldn't preflight — its real credits land in the Step 19
receipt.)

### Step 18 — Final QC
Play-length vs narration, audio levels, no black frames, plus an auto-built
consistency contact sheet (one frame per segment, side by side) reviewed BEFORE
showing the user. Catch your own drift.

### Step 19 — Deliver + the dollar receipt
One run folder holds everything (final.mp4, poster, script, fact-sheet, boards,
clips, audio, manifest). **End by showing the run folder's EXACT ABSOLUTE PATH** — the full filesystem
path (e.g. `C:\Users\...\explainer-runs\<slug>` on Windows,
`/Users/.../explainer-runs/<slug>` on macOS) printed as raw copyable text (in a
code span), so the user can paste it straight into Explorer / Finder to open the
folder. Relative markdown links do NOT open a folder when clicked — a raw
absolute path is required. ALSO give a clickable **`file://` URL** to the folder
(spaces percent-encoded as `%20`) for clients that support it, plus markdown
links to the key assets (`renders/final.mp4`, `frames/`, `clips/`, the script and
fact-sheet) for one-click open. Write README.txt (the folder
map), and give the **dollar receipt**: read the real credits spent (`balance` delta / actual job
costs, INCLUDING the upscale), convert at the plan rate, add voice, and present
the total + remaining balance in DOLLARS (never raw credits). **Then add a
SUBSCRIPTIONS note so the per-video number never reads as the whole cost** — this
render cost sits ON TOP OF the fixed monthly tools the user pays regardless:
**Claude Pro (~$20/mo minimum) — remind them they still pay for Claude**, the
Higgsfield plan (their Plus/Ultra tier — the credits are drawn from it), and
ElevenLabs (their voice plan). State the marginal render cost AND this monthly
baseline so they see the true picture. The finished
explainer video is the deliverable — the skill ends here. No titles, no
thumbnails, no packaging; that is deliberately out of scope.

---

## When things go wrong (observed failure → fix)

- **Grid/storyboard flashes at the start (Path M)** → EXPAND law wording
  drifted; describe the output as opening in-scene, reference demoted to
  plan-only.
- **Zoom-cut-cut instead of flow** → missing "ONE unbroken take, waypoints not
  shots, generate the in-between motion".
- **Style transforms mid-clip (Path S)** → the STYLE-LOCK law: restate the full
  style in the video prompt, not just via the attached reference.
- **Clip feels empty / "not much happening"** → the SHOT was one slow move with
  no landings and nothing thrusting at the lens. Rewrite to the reference's
  3-part structure (law 4b / vox-pack Section E): named background thrown out of
  focus + FG racing/rocketing PAST the lens + 2-3 hard rack-focus landings.
- **Video feels flat / low energy** → three causes, check in order: (a) the style
  sheet was attached as a 2nd VIDEO reference — drop it, Path-S clips pass the
  keyframe ONLY (this was the #1 confirmed cause; a flat board reference anchors
  the model to stillness); (b) wrong energy zone — a short/hook piece must be bold
  throughout, not graded like a long body; (c) the camera was watered down to
  gentle/restrained — apply the full **Variant A camera-as-actor** (dive, fly
  between layers, foreground crossing the lens, rack focus). Bold camera + rigid
  cutouts + keyframe-only reference.
- **Cuts feel like jumps** → add ~0.3s crossfades at assembly AND prompt clips to
  keep the camera moving through the end (cut on motion, don't settle).
- **Clip starts and ends on the same frame (boomerang)** → reference-driven video
  returned to the single input image. Describe a genuinely DIFFERENT end
  composition and add "one-way, no boomerang / return / loop." Stronger fix: pass
  a distinct end-frame image as a second reference so it travels A→B.
- **Clip doesn't open on the approved keyframe** → `gemini_omni`'s reference is
  not a locked first frame. Add "open on the attached frame as frame one, then
  move," and/or use a `start_image`-locking model (Kling 3.0 / Seedance) for that
  beat.
- **A text overlay looks pasted-on** → never overlay text for a textured style;
  the crisp layer can't match the grain. Bake the label into the keyframe.
- **Baked text duplicates or garbles DURING the clip** → a camera PULL-BACK that
  reveals fresh empty canvas makes the model generate a SECOND copy of the words
  into the new space (and mangle them — seen twice on a two-line closer). Fix:
  prefer a push-IN on text-hero / closer beats, add "EXACTLY ONE copy, do not
  duplicate / repeat / mirror the text," and for a text-critical closer fall back
  to a slow ZOOM on the clean keyframe STILL (ffmpeg `zoompan`) — guaranteed clean
  letters with a subtle move, no dependence on the model redrawing the text.
- **Music is a flat hum** → prompt a rising tension ARC with a build + climax, not
  "minimal / ambient / restrained"; duck it under the dense-explanation beats.
- **Batch stalls / preset popup** → Higgsfield suggested a preset; pass
  `declined_preset_id`. Max 8 concurrent jobs on Ultra.
- **Wrong event count / mangled small text** → COUNTING law (exact numbers) /
  TEXT law (big type only; micro type breaks).
- **Hue drift** → COLOR law in words, not just the reference.
- **Character loses mouth/face on turns (Path M)** → face under-defined; fix the
  sheet (mouth explicit, front/three-quarter), bind it, say "including the
  MOUTH".
- **Known face / logo blocked (Path S)** → the model refuses real people. The
  **black bar gets a face past IMAGE gen but NOT past `gemini_omni` VIDEO gen —
  the clip still returns `nsfw`** (confirmed 2026-07-10). For an ANIMATED real-face
  beat, use a **generic invented figure** (anonymous cutout, keep the bar as a
  style device) or **Ken-Burns the approved still** (ffmpeg `zoompan` push-in)
  rather than animating the real face. **Logos are fine** — lock the logo flat in
  the still and it animates without the block.
- **Higgsfield job failed** → resubmit once; twice → strengthen the negatives /
  simplify the scene; balance too low → stop and say the exact gap.
- **Blurry on the big screen** → Omni is 720p by design; the Step 17b upscale
  pass is what lands it at 1080p/4K.
- **Voice not found** → case-sensitive name; use the stored validated ID.
- **Run interrupted** → the manifest knows; resume, never restart.

## Scripts & engines

- **Images / video / upscale** → Higgsfield **MCP** (`generate_image`
  gpt_image_2, `generate_video` gemini_omni, `upscale_video`).
- **Voice** → `tts.py` (ELEVENLABS_API_KEY-aware); `list_voices.py` to pick a
  voice. **Music bed** → `gen_music.py` (ElevenLabs Music; prompt built from the
  script's arc). **Timestamps** → faster-whisper. **Frame gate** →
  `check_frames.py`.
- **Assembly** → HyperFrames (`npx hyperframes`).

Per-run build scripts live in the run folder and follow the resumable-manifest
pattern.
