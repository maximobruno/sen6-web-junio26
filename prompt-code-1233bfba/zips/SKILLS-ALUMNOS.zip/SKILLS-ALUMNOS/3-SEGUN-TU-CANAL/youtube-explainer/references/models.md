# Model Menu

Default engine is the **Higgsfield MCP** (the sponsored path). fal is the
pay-per-use alternate. **Always default to the cost-effective set below**; only
change models if the user asks. Discover exact params/limits at runtime with
`models_explore(action:"get", model_id:…)` and preflight cost with
`get_cost:true` (see below).

> Credit costs below were measured live on Higgsfield; they move. Re-preflight
> with `get_cost:true` before quoting a big job.

---

## Higgsfield models (default engine)

### Images — `generate_image`

| Model | id | Role | Cost (measured) |
|---|---|---|---|
| **GPT Image 2** ⭐ base | `gpt_image_2` | Style sheets, storyboards, keyframes. Best typography / text rendering — the Vox look needs it. Quality `low/medium/high`, res `1k/2k/4k`. | `high 2k` ≈ **7 cr** · `low 1k` ≈ **0.5 cr** |
| Nano Banana Pro | `nano_banana_pro` | Backup — locks a reference style hard; switch to it if the look drifts. Res `1k/2k/4k`. | `2k` ≈ **2 cr** |
| Nano Banana 2 Lite | `nano_banana_2_lite` | Cheapest backup for high volume. | ≈ **1 cr** |

Pass references by **job_id** (not a URL/path): `medias:[{value:<job_id>, role:"image"}]`.

### Video — `generate_video`

| Model | id | Note | Cost |
|---|---|---|---|
| **Gemini Omni Flash** ⭐ | `gemini_omni` | Reference-driven, native audio, 4–10s, **720p only** (upscaled in Phase F). Best consistency + text for motion-graphics; the cheapest top-tier. | **3 cr/sec** (8s = 24, 10s = 30) |
| Seedance 2.0 | `seedance_2_0` | Native 1080p/4K, reference-driven — but **9 cr/s** at 1080p (a 10-min video ≈ 5,400 cr, over budget). Reserve for short premium shots only. | 1080p ≈ 9 cr/s |

References bound by job_id: `medias:[{value:<job_id>, role:"image_references"}]`.

### Upscale — `upscale_video` (Phase F)
`provider:"bytedance", preset:"aigc", resolution:"1080p"|"4k"`, `video_id:<final MP4 job/media id>`.
Built for AI-generated footage. **No `get_cost` preflight** — its real credits
appear in the delivery receipt (Step 19). One pass on the whole video.

---

## Cost math (credits → dollars — the skill speaks dollars, never credits)

Read the plan from `balance` → $/credit:

| Plan | $/mo | credits/mo | $/credit |
|---|---|---|---|
| Starter | $15 | 200 | $0.075 |
| Plus | $39 | 1,000 | $0.039 |
| **Ultra** | $99 | 3,000 | **$0.033** |

- **Animation drives everything:** 3 cr/s × plan rate ≈ **$0.10/s ≈ $6/min** (Ultra)
  to **$7/min** (Plus). Images are pennies; voice is in the ElevenLabs plan;
  HyperFrames assembly is free.
- **Rule of thumb for the audience:** **~$65/mo toolkit + ~$7 per finished minute**
  (3-min ≈ $20, 10-min ≈ $70).
- **Estimate at the gate:** `get_cost:true` on one image + one clip at the
  planned duration → × counts → +15% buffer → × plan rate → dollars. Announce,
  don't block; stop only if `balance` can't cover it.

---

## fal (alternate engine, non-sponsored)

Pay-per-use in dollars. Defaults: `fal-ai/nano-banana-pro` (images, ~$0.13),
`google/gemini-omni-flash/image-to-video` (video, ~$0.13/s = ~$7.80/min, also
720p). Keep the explicit up-front cost yes — each video is real new money.
Premium video (Seedance/Veo/Kling) can 2–3× the bill; say the delta out loud.
