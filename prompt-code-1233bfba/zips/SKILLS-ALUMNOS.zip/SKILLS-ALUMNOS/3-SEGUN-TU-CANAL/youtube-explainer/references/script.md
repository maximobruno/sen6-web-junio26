# Script — the retention layer

The script carries the meaning; the visuals carry the mood. The script is what
separates a video people finish from beautiful nonsense — and finishing is the
metric YouTube pays for. Write like a professional retention scriptwriter,
because that is the promise this skill makes.

Everything factual comes from `fact-sheet.md` (Step 5). If the script needs a
fact that isn't there, research it and add it to the sheet first — never invent.

This file is the **format**, not a voice. It is brand- and voice-neutral: bring
any topic, write in any narrator's voice on top of it, and the retention
*structure* is what stays constant. That structure is the thing worth teaching.

---

## Voice-first, not block-first (how this script is produced)

Do **not** pre-chop the script into fixed word-count blocks. Write it as **one
continuous spoken essay**. Downstream it becomes ONE continuous voiceover
(Step 8), transcribed to word-timestamps (Step 9), and only THEN sliced into
segments (Step 10). The beats are found in the *audio*, not written as chunks
now.

Why this matters: a single continuous VO sounds like one person telling you
something. Writing to per-block takes (a line at a time, then stitched) drifts
in timbre and pacing at every cut. Flow is a retention device — protect it.

- **Pace:** ~140–150 words per minute. A 10-minute video ≈ ~1,400 words. Write
  to roughly the target minutes; the exact segment count is derived later from
  the timestamps, not decided here.
- **Write for the ear:** connected sentences with the emphasis woven in, not
  stacked punch-fragments. If a line only works on the page, rewrite it to work
  when *heard once, at speed*.

---

## Retention architecture (the format that works)

Structure by length. The headings are annotation for the human review — they
are never spoken and never become cuts:

- **Short-form (≲90s): Hook → Body → Payoff.** No chapters — at this length
  chapter doorways don't exist; the whole piece is one intro-energy arc.
- **Long-form (>90s): Hook → Intro → Chapters → Ending.** The hook (cold open)
  and the intro come BEFORE the first chapter — chapters never absorb the hook.
  The intro is where the video's promise gets framed and the first loop planted;
  the chapters are the delivery.

Either shape is engineered so that leaving feels expensive.

- **Cold open on the payoff (first ~15s).** Open on the most arresting concrete
  image or claim in the research — the *result*, not the backstory. Never
  "today we'll explore…"; the viewer should learn something startling before
  they've decided to stay. **The hook must also deliver on the working title's
  promise** — the click and the first 15 seconds are the same promise, kept.
- **Chapters of ~90–120s.** Each chapter answers ONE question and ends by
  *raising the next one*. The last line of a chapter is a **doorway, not a
  summary**.
- **An open loop roughly once a minute.** Plant a specific question and defer it
  ("that one decision sank the whole project — but not for the reason you'd
  guess"), then pay it off one or two chapters later. **Track every loop: each
  one planted must close before the final chapter.** This is the technique
  professional scriptwriters are paid for — the signature of the format.
- **Concrete over abstract, always.** Named people, dated events, physical
  detail, numbers with stakes. One idea at a time — a beat that needs two
  sentences of setup is two beats.
- **Ending (last ~20–30s).** Close the largest loop, land one resonant takeaway
  line, and add a single quiet next-video hook. No "like and subscribe" essay —
  one short line at most.

---

## Narration line rules (the voice engine is literal)

- Plain spoken text only — no parentheticals, stage directions, or emphasis
  markup.
- Spell numbers out ("twenty percent", "nineteen fifty-eight").
- No "in this video".
- Every sentence must stand alone when heard once, at speed.

---

## What you write

**`script.md` — for the human to read and approve.** The flowing narration
under the length-appropriate headings, with loop annotations so the craft is
visible (this is what you teach and what the user QCs):

```markdown
# <working title>

<!-- short-form (≲90s): -->
## Hook
## Body
## Payoff

<!-- long-form (>90s): -->
## Hook
## Intro
## Chapter 1 — <the question it answers>
## Chapter N — …
## Ending

<narration as flowing paragraphs — write prose, NOT "Block 1 / Block 2">
[loop planted: <the question>]  …  [loop closed: <where it pays off>]
```

**Mark the intro→body handoff** — for long-form, that is where the Intro
section ends and Chapter 1 begins. The animation step reads this to set each beat's energy
zone: everything in the intro animates at MAX energy (all bold); the body follows
the graded high-floor rule. A short-form video (≲90s) is all intro. Don't tie this
to a timer — the writer decides the intro's length.

Do not produce a numbered block list here. The prose is the deliverable; the
segments come later from the timestamps (Step 10).

---

## Quality gate (self-check before showing the user — fail any → fix)

- Hook states a **payoff**, not a promise to explain.
- Hook **delivers on the working title's promise** (title ↔ script aligned — no
  drift between the click and the open).
- **Every open loop closes** before the end.
- Chapters end on **doorways**, not summaries (long-form; short-form: the Hook
  hands off on a raised question, not a topic statement).
- Every fact / stat traces to `fact-sheet.md`.
- **Concrete**, not abstract: named people, dated events, numbers with stakes.
- Reads as **continuous speech** at ~145 wpm — no choppy fragments, no
  page-only lines.
- Passes the "both stay" test: a bored 14-year-old and a sharp 40-year-old both
  finish it.

---

## Presenting the script (🚦 GATE 1)

When the script passes the self-check, present it in chat:

1. The **chaptered narration itself**, plus one stats line — e.g. *"Script's
   done — ~1,400 words, 6 chapters, 9 open loops, ~10 min."*
2. The **reference links behind the facts** (from Step 5), so the user checks
   accuracy in one click before anything costs money.
3. A short **craft note (2–4 sentences), written fresh for THIS script** —
   point at where the retention engineering actually lives: quote the real
   hook, name one or two of the actual open loops and where they close, note a
   chapter handoff that works. **Never reuse a note.** If it could be pasted
   under a different script unchanged, it's too generic — rewrite it. (For a
   video you're *teaching*, this note is the lesson: it makes the craft visible
   instead of magic.)

Then **STOP**. Nothing visual generates until the user approves. Script and fact
edits here are free; every image after this costs money.
