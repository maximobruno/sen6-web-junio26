# Vox Prompt Pack — the no-mascot / single-generation prompt architecture

The proven prompt scaffolding for the **Documentary Vox / single-generation
(no-mascot / Path S)** route, battle-tested across
production runs. It is **brand-neutral**: `<PLACEHOLDERS>` stand in for palette,
type, and accent — fill them from your chosen preset in
[style-presets.md](style-presets.md). The *architecture* is what stays constant;
the skin is yours.

**SEN6 rule:** every IMAGE prompt below (master sheet, keyframes) opens with the
Prompt Cine 6-box line — `<encuadre>, <ángulo>, <sujeto + acción>, <foco>,
<luz>, <color>` — built with the `prompt-cine` skill (see SKILL.md, "Image
prompts = Prompt Cine"); the STYLE block follows it verbatim. Video prompts keep
the SHOT/AUDIO/AVOID skeleton as is.

Use this pack at three steps:
- **Step 11** — the master style sheet (the "board").
- **Step 13 (Path S)** — per-beat keyframes (same STYLE block + the beat's scene).
- **Step 15** — the per-clip video prompts.

---

## Core principle: lock ONE style sheet · restate STYLE every clip · swap only the ACTION

- **Style lock (never changes):** the reference board + the STYLE paragraph,
  repeated word-for-word in every prompt.
- **Action block (changes per clip):** the SHOT / ACTION paragraph — what happens
  this beat.
- **Two generation paths:**
  1. **ref → still image → video** — when a clip needs **logos or known faces**
     (control the frame first; required for the black-bar workaround).
  2. **ref → video direct** — fine for most clips; skip the still step.
- **Critical rule:** even with the reference image attached, **restate the full
  STYLE inside the video prompt** — or the model transforms the style mid-clip.
- **Critical rule 2 — the video reference is the KEYFRAME ONLY.** Pass the single
  beat keyframe as the video reference; do NOT also attach the style board. A flat
  rulebook image as a 2nd video reference ANCHORS the model to stillness and kills
  the camera move (confirmed A/B: same keyframe, board removed → dramatically more
  travel). The keyframe already carries the style; STYLE-LOCK is held by the
  restated style paragraph, not by re-attaching the board.

---

## A. Master style sheet prompt (the board — Step 11)

Fill `<PLACEHOLDERS>` from your style preset. Panels: Type Specimen, Palette,
Component Zoo (incl. a halftone **figure** cutout), Mini-Scenes, Motion
Thumbnails, and **The Stage** (the persistent background world).

```
MASTER STYLE SHEET — <PROJECT> visual system, one <ASPECT, e.g. 16:9> reference board.
A single polished art-direction sheet defining the visual language for a
<STYLE NAME, e.g. documentary paper-collage> explainer. Editorial grid,
consistent margins, section labels. Baked-in typography is intentional here
(this is a style guide).

SURFACE & MOOD: <surface, e.g. aged archival paper / muted map texture field,
visible grain and print texture>. Mood: <mood words>.

TYPE SPECIMEN PANEL: a headline sample "<HEADLINE WORDS>" in <type, e.g.
condensed bold headline caps>; a huge stat-number sample "<STAT, e.g. 90%>"
treated as a hero character; a small annotation label sample "<Fig. label>".
Type aligned and sharp, no broken letters.

PALETTE STRIP: labeled swatches — <BASE, e.g. archival tan #______>,
<INK #______>, <NEUTRAL, e.g. halftone gray #______>,
<ONE HOT ACCENT #______>, <OPTIONAL SECONDARY #______>. The accent is reserved
only for stresses, underlines, arrows, and hero numbers; secondary is sparing.

COMPONENT ZOO PANEL: a clean black-and-white halftone cutout of a generic FIGURE
with a rough white keyline and an offset <accent> stroke behind it; a torn-paper
edge; a big <accent> stat-counter card; a map/marker pin; an underline in
<accent> beneath a headline word; an archival photo card with a thin white
border. One construction logic throughout: halftone texture + offset stroke pop.

MINI-SCENE PANEL: 3-5 small example frames showing the language assembled — e.g.
(a) two halftone figures on the stage with a stat counter between them, (b) a map
with a pin and an accent underline swipe beneath a caption, (c) an archival photo
card with a torn edge beside a label. Same lighting and finish.

MOTION THUMBNAILS: 4 tiny storyboard frames with arrows only: cutout springs up /
counter ticks upward / accent underline swipes / camera holds a slow ~2% drift.

THE STAGE (one panel): the persistent background world every clip lives on — a
<muted archival field>, empty, pre-lit, evenly toned, ready for cutouts and cards
to enter and exit. No midground elements in this panel.

FINISH: <print grain, halftone dot texture, torn-paper edges, matte>, no glossy
3D, no lens flares, no watermarks, no lorem ipsum, no unrelated logos, no
gibberish text — every visible word is one of the samples above.
```

---

## B. Per-clip skeleton (every keyframe + video prompt — Steps 13 & 15)

```
[STYLE BLOCK — locked; restate every clip. Pick one variant below.]

SHOT:  (or ACTION:)
[Match the REFERENCE 3-part structure (see Section E — the creator's real
prompts). ~600 chars total, dense, no timestamps:
  1. BACKGROUND at depth — name it, push it out of focus ("a faded world map
     tilted in perspective, far out of focus" / "a collage field of ledger
     sheets and ticker strips at depth").
  2. FG that THRUSTS at the lens — the subject/elements race, rocket, whip, or
     spiral PAST or STRAIGHT AT the camera with motion blur. THIS, not camera
     drift, is where the energy lives ("'AI CAPEX' rockets straight at the
     camera, the bar face rushing past the lens" / "coin chips race along it,
     the nearest whipping past the lens").
  3. CAMERA move with 2-3 hard LANDINGS — ONE committed move (orbit / climb /
     lateral track / double-whip) that LANDS 2-3 times; each landing snaps a
     new subject into razor RACK FOCUS while the previous blurs away ("the
     camera WHIPS right twice, each whip landing hard … each landing snaps its
     figure into razor focus, previous field blurring away"). End on a specific
     SETTLE ("Settle on the sliver in macro" / "Settle mid-orbit").
This 3-part shot is what makes ONE 8s clip carry 3 beats. A single slow camera
move with no landings and no subject-at-lens thrust IS the flat-clip failure.
Devices to reach for: whip-pan landing, rack focus, deep focus falloff, dutch
tilt, ALERT WASH (frame floods to accent), macro settle, trembling summit.]

AUDIO:
[3-4 diegetic sound-design cues] — sound design only, no music, no narration.

AVOID:  (the reference's verbatim negative — paste it)
no flat single-plane composition, no static locked-off camera, no glossy plastic
CG (depth stays papercraft), no full-color midground portraits (people stay
halftone black-and-white), no warped or gibberish text, no invented logos, no
watermarks, no music, no soundtrack, no voice-over, no narration, no lyrics.
```

### Style-block variants (same DNA, three phrasings)

**Variant A — "materials only"** (default, most clips):
```
Use the attached style sheet for materials only — <surface> textures, halftone
black-and-white cutout people/objects with rough keylines and offset accent
strokes, giant stat numbers, print grain. Do NOT copy the sheet's layout or its
flatness: every clip is a deep 3D paper diorama — cutouts are physical layers
separated in real space, strong shallow depth of field, foreground elements
crossing close to the lens. The camera is an actor: it flies between layers,
orbits, dives, whips, racks focus — ONE committed cinematic move per clip.
Backgrounds change per clip, always within the sheet's palette. ALERT WASH =
the whole frame floods to the hot accent tone in one beat. Motion: springs with
overshoot, staggered entrances, ticking counters. Audio: sound design only —
paper pops, whooshes, stamps, ticks. No music. No voice-over.
```

**Variant B — "strict visual system"** (hero data beats):
```
Use the attached style sheet as the strict visual system — match its <surface>,
desaturated palette with one hot accent, condensed headline caps with giant stat
numbers, halftone black-and-white cutouts with rough white keylines and offset
accent strokes, and its print-grain finish. Do NOT copy the sheet's layout; it
defines the language, not the composition. Layers sit at distinct depths like a
paper diorama — true parallax, never glossy 3D. Backgrounds are muted fields,
varying per clip within this palette. ALERT WASH = the whole frame floods toward
the hot accent. Motion: spring pop-ups with overshoot, staggered entrances,
ticking counters, underline swipes; ONE slow camera move per clip. Audio: sound
design only. No music. No voice-over.
```

**Variant C — "documentary cutout-collage stage"** (chart / bar beats):
```
Documentary cutout-collage stage: a locked, muted <background> that never
changes. Midground: black-and-white halftone cutouts with a rough white keyline
and an offset accent stroke behind each. Foreground: structures, props, and big
stat numbers in full color. Condensed bold headline caps; numbers rendered huge,
as characters. Desaturated palette plus one hot accent. Spring pop-ups with
overshoot, staggered entrances, counters ticking up, underline swipes. Camera:
subtle slow drift only, never cuts.
```

*Energy-zone override:* in the MAX-energy zone (the intro, or ALL of a
short-form ≲90s video) keep Variant C's structure but replace "subtle slow
drift only" with ONE committed camera move — e.g. a bold push-in that rises
and lands with the final pop event. Subtle-drift-only is a long-form-body
camera. See the ENERGY-ZONE law in SKILL.md Step 15.

---

## C. Real people & logos — the black-bar workaround

The video model **blocks recognizable real people**. To get a known face (or a
real logo) in:

1. **Text→image** on `gpt_image_2` — generate the still with the person(s)/logo.
2. **Image→image** pass — lay a **black bar over the eyes** (for a face) / place
   the logo **flat, unmodified**.
3. Feed that controlled still as the **reference for the video** (Gemini Omni).

The black-bar look reads as a deliberate editorial device, not a defect.
**Text and numbers: bake them into the generation — do NOT overlay them at
assembly.** gpt_image_2 renders short big numbers/labels well, and generated text
inherits the paper grain and lighting. A crisp CSS/vector overlay laid on
textured collage footage never matches — it reads as pasted-on (a tested
failure). Pixel-exact LOGOS are the one hard case: prefer supplying the real logo
as a reference into the generation, or accept a stylized generated mark; a hard
overlay will still look foreign on paper.

---

## D. Guardrails (what makes the model behave)

- **Lock the style, swap the action.** One board, restated every prompt; only
  SHOT changes.
- **Restate STYLE in the video prompt** even with the image attached, or it
  transforms mid-clip.
- **Big fonts survive; micro/fine typography breaks** — think in big blocks.
  Small labels drift into gibberish.
- **Bake text into the frame; never overlay it.** gpt_image_2 renders short big
  numbers/labels cleanly and they inherit the paper texture — generate them IN the
  keyframe. Do NOT overlay crisp CSS/vector text at assembly for a textured style;
  it can't match the grain and reads as pasted-on (tested failure). Keep numbers
  SHORT and BIG ($5T, 90%, $700B) — long strings still garble.
- **ONE move, but a BOLD one.** "Simpler = fewer artifacts" means ONE committed
  camera move per clip (not five, no cuts) — it does NOT mean a gentle or timid
  move. That single move is the full camera-as-actor energy of the chosen variant
  (dive / fly between layers / rack focus / foreground crossing the lens). Never
  trade camera energy for safety — the no-morph / no-glossy guardrails are what
  keep it safe.
- **One-way, no boomerang.** The final frame must DIFFER from the opening. A
  single-reference video model anchors to that image and drifts out-and-back to it
  unless you force a distinct end and forbid the return ("one-way, no boomerang /
  loop"). If a beat truly must land near its start, pass a separate end-frame
  image as a second reference (A→B).
- **Motion = the CAMERA, not morphing.** The clip is a PARALLAX move through
  RIGID paper layers; cutouts SLIDE, POP, HINGE, SETTLE — they must NOT morph,
  melt, topple into rubble, or transform. A reveal stays matte PRINTED paper
  (halftone ink); never let it become a glossy, glowing, emitted-light CG surface
  (a screen, a circuit board, a 3D render). Put "deep paper diorama, physical
  layers, true parallax, never glossy CG" in the STYLE block and forbid
  morph/glossy in AVOID. (Learned the hard way: "the chip peels and the lattice
  spreads" produced a glossy CG circuit board; "a paper flap HINGES to reveal a
  printed green-circuit paper layer" kept it paper.)
- **Energy graded by retention position.** Intro / hook (the script's cold-open
  through the first chapter doorway, writer-defined length, NOT a timer) and *all*
  of a short-form video (≲90s) = MAX energy, every beat bold, no restraint (the
  immersive mode — a short piece is one long hook, so keep it bold front to back).
  Long-form body = graded with a HIGH floor: bold peaks, controlled-but-moving
  troughs, never a timid crawl. **flat ≠ restrained** — dead-static (first frame ≈
  last) is always wrong; a slow move that still travels is a valid calm beat.
- **Single video reference.** The video reference is the KEYFRAME ONLY — never also
  the style board; a flat rulebook image as a 2nd reference damps the camera move.
  Restate the style in words instead.
- **Text under motion duplicates / garbles.** A pull-back that reveals fresh canvas
  makes the model draw a SECOND copy of the words (and mangle them). Prefer a
  push-IN on text-hero / closer beats, add "EXACTLY one copy, do not duplicate /
  repeat / mirror the text," and for a text-critical closer fall back to a slow
  ZOOM on the clean keyframe still (guaranteed clean letters).
- **Skip the still step** except for logos/faces (then use the black-bar path).
- **Trim glitch frames in the edit** — at normal speed it reads clean.

---

## E. Reference exemplars — the creator's ACTUAL clip prompts

Transcribed verbatim from the reference video's "REF → IMAGE → VIDEO" case
study (his prompts shown on screen). This skill is an IMITATION engine — when a
clip feels flat, the fix is to make the SHOT read like these, not to add more
adjectives. Note the shared shape: fixed STYLE preamble → a SHOT that names a
depth BACKGROUND, sends FG elements THRUSTING at the lens, and rides ONE camera
move through 2-3 hard LANDINGS with rack focus → per-clip AUDIO → the AVOID
negative. Each full prompt is only ~600 chars.

**Fixed STYLE preamble (identical on every clip — this IS Variant A):**
> Use the attached style sheet for materials only — aged-print collage textures,
> halftone black-and-white cutout people with rough keylines and offset accent
> strokes, giant stat numbers, print grain. Do NOT copy the sheet's layout or
> its flatness: every clip is a deep 3D paper diorama — cutouts are physical
> layers separated in real space, strong shallow depth of field, foreground
> elements crossing close to the lens. The camera is an actor: it flies between
> layers, orbits, dives, whips, racks focus — one committed cinematic move per
> clip. Backgrounds change per clip, always within the sheet's palette. ALERT
> WASH means the entire frame floods to the hot accent tone in one beat. Motion:
> springs with overshoot, staggered entrances, ticking counters. Audio: sound
> design only — paper pops, whooshes, stamps, ticks. No music. No voice-over.

**SHOT exemplars (the part that changes per clip — study the density):**

1. *(logos / orbit)* Background: a faded world map tilted in perspective, far
   out of focus. FG: three cards snap in at different depths forming a triangle,
   each carrying one attached logo — Nvidia, OpenAI, Microsoft — flat,
   unmodified. A thick arrow draws card-to-card into a closed loop; coin chips
   race along it, the nearest whipping past the lens with motion blur. Camera
   orbits the triangle a quarter turn, focus racking card to card. Settle
   mid-orbit. — AUDIO: thwips, coin whooshes past lens, low hum.

2. *(stat hero / climb)* Background: a collage field of ledger sheets and ticker
   strips at depth. Two bars rise staggered: "CONSUMERS" (label) stops low; "AI
   CAPEX" (label) rockets straight at the camera — the camera tilts up and
   climbs alongside it, the bar face rushing past the lens, slight dutch tilt,
   the small bar shrinking below in deep focus falloff. Settle at the trembling
   summit. — AUDIO: bass rumble, paper scrape, two pops.

3. *(meter / lateral track)* Background: a long factory-paper field of desks and
   machines in repeating depth. The camera tracks fast laterally along an endless
   meter labeled "ACTUALLY PAID", fill line racing ahead of the lens — then the
   fill stalls at a sliver and the camera stops hard with it, overshooting
   slightly. The empty remainder flickers and drains; worker cutouts behind fall
   out of focus one depth layer at a time. Settle on the sliver in macro. —
   AUDIO: track rumble, stall click, drain hiss.

4. *(figures / double-whip)* Three fields at different depths, the camera WHIPS
   right twice, each whip landing hard: first a founder cutout with a counter
   reading "$7T" (counter); whip — a second figure beside a card carrying the
   attached logo, flat, unmodified; whip — a third figure before a government
   building cutout, flag strips swaying in parallax. Each landing snaps its
   figure into razor focus, previous field blurring away. Settle on the last. —
   AUDIO: three whip whooshes, pops landing each hit.

5. *(transition / ALERT WASH)* A single wide stroke sweeps across the frame and
   the camera whips with it; ALERT WASH floods behind the stroke's trailing edge
   while printed dots and paper fragments spiral past the lens in three depth
   layers, then settle. No text in frame. — AUDIO: heavy swipe whoosh, sub thud,
   dot swirl ticks.

**What makes these energetic (the checklist for every SHOT you write):**
- The BACKGROUND is named and thrown out of focus (depth is established).
- At least one element RACES / ROCKETS / WHIPS / SPIRALS **past or at the lens**
  with motion blur — the subject moves violently, not just the camera.
- The single camera move contains **2-3 hard landings**, each a **rack focus**
  onto a new subject while the previous blurs away — that is how one 8s clip
  reads as three beats.
- It ends on a **specific settle** (macro / mid-orbit / trembling summit), never
  drifting to a stop.
- Named cinematography verbs, not adjectives: whip, rack focus, climb, track,
  dutch tilt, ALERT WASH, deep focus falloff.

---

## F. Finishing — "cutting on twos" (the stepped-framerate hand-drawn pass)

The one Vox motion signature the prompts above can't produce — added as a
**FINISHING step in assembly**, so it never affects generation. Real Vox (and
Spider-Verse, Puss in Boots) steps the framerate DOWN so motion looks hand-drawn,
not computer-smooth. "On **twos**" = a new frame every 2nd frame (a **12fps** feel);
"on **threes**" (**8fps**) = heavier, super-collage. Omni renders smooth ~24fps, so
you re-introduce the choppiness afterward. It's the fastest "reads Vox" signal.

**Apply to the analog/collage look only** — this Documentary Vox style (also Retro
Print / Mixed Media). NOT the smooth styles (3D Paper Cut, Flat Vector) — it looks
broken there.

**On the Omni clips (the main lever).** Decimate then re-expand so the container fps
holds but motion only updates on twos. `ffmpeg` is already in the toolchain — run it
per clip, or once on the stitched cut, BEFORE the upscale:

```
# on twos (12fps feel) — the default Vox look
ffmpeg -i in.mp4 -vf "fps=12,fps=24" -c:a copy out.mp4

# on threes (8fps) — heavier, "super collage"
ffmpeg -i in.mp4 -vf "fps=8,fps=24" -c:a copy out.mp4
```

(`fps=12` keeps 12 distinct frames/sec; `fps=24` duplicates each once → 24fps
container, motion stepped on twos. Match the 2nd number to your timeline fps.)

**On HyperFrames-native layers** (markup, counters, title cards). Quantize the drive
time to a 1/12s (or 1/8s) grid so those tweens step; keep the video track and captions
at full fps — step only the motion graphics.

**Don'ts:** don't strobe the captions (step the motion graphics, keep text/legibility
smooth); don't double-step a clip Omni already rendered choppy; keep it OPTIONAL per
clip — a calm camera-over-document beat can stay smooth; too jittery → stay at 12 not
8, still too smooth → try 8.

---

*This pack is the portable, brand-neutral distillation of a proven,
production-tested prompt architecture — fully self-contained, nothing external
required.*
