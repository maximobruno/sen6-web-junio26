# Style Presets

Each preset is a reusable style block. Insert it verbatim into the style
frame prompt, every keyframe prompt, and (the "Motion" line) into clip
prompts. Consistency comes from repeating the same words every time, not
from writing new descriptions per scene.

Present these to the user as: name + the one-line pitch. Custom styles are
fine; write them in the same three-part shape (look / palette / motion).

---

## Paper Cut
*Pitch: layered construction-paper dioramas with real depth shadows.*
- **Look:** handcrafted layered paper-cut diorama, visible paper texture and
  cut edges, elements on separate depth layers casting soft real shadows,
  slightly imperfect hand-cut shapes
- **Palette:** 4-5 flat saturated paper colors against a neutral backdrop
- **Motion:** layers slide and rotate like a paper theatre; parallax between
  depth layers; nothing morphs, things move as rigid cutouts

## 3D Paper Cut
*Pitch: fully dimensional papercraft sculptures with real volume (the rich,
premium look). NOT flat layers — actual 3D paper models.*
- **Look:** three-dimensional papercraft sculpture, objects and characters
  built from folded, curled, and layered paper with genuine volume and
  rounded form, tactile paper grain, standing up off the surface; soft studio
  lighting with gentle shadows and a shallow depth of field, like a macro
  photograph of a real handmade paper diorama. Every element has thickness
  and casts its own contact shadow. Rich, crafted, premium.
- **Palette:** warm cohesive paper tones with soft directional lighting;
  colored paper stocks with subtle sheen, not flat print
- **Motion:** dimensional camera moves — slow orbit, dolly-in, and parallax
  that reveals the real depth; the paper forms hold their volume as the
  camera moves around them; gentle settle, never morphing
- **Note:** this is the "looks expensive" option and the one to reach for
  when the flat Paper Cut feels too simple. Front-load "fully three
  dimensional, real volume, NOT flat layered cutouts" in every prompt so the
  model builds sculptural depth rather than stacked flat shapes.

## Claymation
*Pitch: stop-motion clay world, Aardman energy.*
- **Look:** hand-molded plasticine clay figures and sets, visible thumbprints
  and tool marks, stop-motion aesthetic, miniature studio lighting
- **Palette:** warm earthy clay tones with one bold accent color
- **Motion:** slightly stepped stop-motion cadence, squash and stretch,
  characters move with weight

## Mixed Media
*Pitch: collage of photos, paper scraps, and hand-drawn doodles.*
- **Look:** cut-out photo elements collaged with torn paper, tape, and
  hand-drawn marker doodles and arrows layered on top, scrapbook energy
- **Palette:** photographic tones + one marker accent color for doodles
- **Motion:** cutouts jitter and hop like animated collage; doodles draw
  themselves on; camera does slow push-ins

## Pixel Art
*Pitch: 16-bit game world nostalgia.*
- **Look:** crisp 16-bit pixel art, chunky sprites, dithered gradients,
  scanline-era game aesthetic
- **Palette:** limited 16-color retro palette
- **Motion:** sprite-style stepped animation, side-scrolling camera moves,
  screen-shake on impact beats

## Fluffy Toy
*Pitch: everything is plush felt and soft fur.*
- **Look:** the entire world made of plush toys and felt, visible fabric
  weave, stitching, and fuzz, soft studio macro lighting
- **Palette:** soft pastels with high-key lighting
- **Motion:** gentle bouncy motion, fabric jiggle, slow loving close-ups

## Ink & Wash
*Pitch: East-Asian brush painting that breathes.*
- **Look:** sumi-e ink brush painting, expressive brushstrokes, ink wash
  gradients on textured rice paper, generous negative space
- **Palette:** black ink on warm paper with a single vermilion accent
- **Motion:** ink blooms and flows, strokes appear with brush energy, slow
  contemplative camera drifts

## Flat Vector
*Pitch: clean modern 2D explainer, tech-company style.*
- **Look:** flat 2D vector illustration, geometric shapes, clean line work,
  subtle grain texture, generous whitespace
- **Palette:** 3 brand-ish colors + neutral background
- **Motion:** crisp ease-in-out translations, elements pop and slide in
  sequence, isometric drift

## Silhouette Theatre
*Pitch: backlit shadow-puppet storytelling.*
- **Look:** black silhouette figures against luminous gradient backgrounds,
  ornate cut-out detail inside the silhouettes, shadow-puppet theatre
- **Palette:** black figures over one rich gradient (dusk orange, deep teal)
- **Motion:** figures glide laterally like puppets on sticks; light rays
  and particles drift; dramatic scale shifts

## Watercolor Storybook
*Pitch: soft children's-book illustration.*
- **Look:** hand-painted watercolor storybook illustration, soft wet-on-wet
  edges, pencil underdrawing peeking through, paper texture
- **Palette:** gentle warm watercolors, low saturation
- **Motion:** paint blooms in, pages of the world gently breathe, slow pans

## Retro Print
*Pitch: risograph zine, grainy and cool.*
- **Look:** risograph print aesthetic, 2-3 ink layers slightly misregistered,
  heavy grain, halftone shading, zine energy
- **Palette:** 2-3 riso inks (e.g., fluorescent pink + teal + paper)
- **Motion:** stepped 8fps-feel animation, print layers shift and re-register,
  bold graphic transitions

## Documentary Vox / Newsprint Collage
*Pitch: the graphic "video-essay" explainer look — aged-newsprint collage,
halftone cutouts, one hot accent, giant stat numbers. Best for topical /
data-driven explainers; the natural fit for the **no-mascot single-generation
path**.*
- **Look:** hand-cut documentary paper-collage — aged newsprint / archival-map
  surface, black-and-white halftone photo cutouts with rough white keylines and
  an offset accent-stroke behind each, desaturated palette with ONE hot signal
  accent, condensed bold headline caps, giant stat-number "hero" figures, torn
  paper edges, print grain, matte — never glossy CG
- **Palette:** desaturated archival base (tan / ink / halftone gray) + ONE hot
  accent (reserved for stresses, underlines, arrows) + an optional secondary
  accent. This is a LOOK, not a brand — pick any accent; a brand user swaps in
  their own colors
- **Motion:** cutouts spring up with slight overshoot, staggered entrances,
  counters tick up, underline swipes; ONE committed camera move per clip (orbit
  / push / lateral drift); "ALERT WASH" = the frame floods to the accent in one
  beat; nothing morphs — pieces slide, pop, hinge, settle. **Finish** with the
  stepped-framerate "cutting on twos" pass (step to ~12fps in assembly) so motion
  reads hand-drawn, not computer-smooth — the defining Vox motion tell
- **Note:** big type only — micro/fine typography breaks; think in big blocks.
  The full prompt scaffolding — master-sheet template, per-clip
  STYLE/SHOT/AUDIO/AVOID skeleton, the three style-block variants, and the
  black-bar recipe — lives in [vox-prompt-pack.md](vox-prompt-pack.md) (baked
  into this skill).

---

## Caption styles (only when subtitles are turned on)

If the user wants burned-in captions, style them to match the animation
instead of using plain default subtitles. These `force_style` (libass) strings
are the styling recipe — apply them via the HyperFrames caption block when you
assemble (Step 17). Fonts listed are common on most machines; for a brand font,
drop the `.ttf` alongside the composition.

Colors are libass `&H00BBGGRR`. Bump `FontSize` ~+6 and `MarginV` ~+40 for
9:16 vertical so captions read on a phone.

| Style | force_style |
|---|---|
| Paper Cut | `FontName=Georgia,FontSize=22,Bold=1,PrimaryColour=&H00D6EBF8,OutlineColour=&H00050E1A,BorderStyle=1,Outline=2,Shadow=1,MarginV=45` |
| 3D Paper Cut | `FontName=Georgia,FontSize=22,Bold=1,PrimaryColour=&H00E8F2F5,OutlineColour=&H00120A05,BorderStyle=1,Outline=2,Shadow=2,MarginV=45` |
| Claymation | `FontName=Verdana,FontSize=22,Bold=1,PrimaryColour=&H00F0F5FA,OutlineColour=&H00203040,BorderStyle=1,Outline=2,Shadow=2,MarginV=45` |
| Mixed Media | `FontName=Trebuchet MS,FontSize=22,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Shadow=0,MarginV=45` |
| Pixel Art | `FontName=Courier New,FontSize=20,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,Outline=3,Shadow=0,MarginV=45` |
| Fluffy Toy | `FontName=Verdana,FontSize=22,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00C8B0E0,BorderStyle=1,Outline=2,Shadow=1,MarginV=45` |
| Ink & Wash | `FontName=Georgia,FontSize=23,Italic=1,PrimaryColour=&H00050505,OutlineColour=&H00D5E8F2,BorderStyle=1,Outline=3,Shadow=0,MarginV=45` |
| Flat Vector | `FontName=Arial,FontSize=20,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00303030,BorderStyle=1,Outline=1,Shadow=1,MarginV=45` |
| Silhouette Theatre | `FontName=Georgia,FontSize=22,Bold=1,PrimaryColour=&H005D9BF0,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=1,MarginV=45` |
| Watercolor Storybook | `FontName=Georgia,FontSize=22,PrimaryColour=&H00303A55,OutlineColour=&H00E8F0F5,BorderStyle=1,Outline=3,Shadow=0,MarginV=45` |
| Retro Print | `FontName=Trebuchet MS,FontSize=22,Bold=1,PrimaryColour=&H00B048FF,OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=2,MarginV=45` |
| Documentary Vox | `FontName=Georgia,FontSize=22,Bold=1,PrimaryColour=&H00FFFFFF,OutlineColour=&H00101010,BorderStyle=1,Outline=3,Shadow=1,MarginV=45` |

For a custom style, build the caption from its palette: text in the
lightest color, outline in the darkest, a serif font for painterly/print
looks and a mono or bold sans for pixel/graphic looks.

**Note on palette vs style:** these presets are animation *mediums* (how the
frame is rendered and moves). A brand color scheme is a separate layer. If a
user wants their own palette (e.g. a warm gold brand look), apply it as a
color instruction *on top of* a chosen medium, not as a preset of its own.
For example: "Ink & Wash, but with a warm gold and cream palette instead of
black ink." Keep the medium and the palette as two independent choices.
