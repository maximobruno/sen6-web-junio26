"""Pre-video gate: verify keyframes before spending money on clips.

Checks every keyframe against the target aspect ratio and flags:
  - wrong aspect ratio (file dimensions don't match target)
  - "boxed" composition (a large uniform border around the content, i.e.
    the subject floats in the middle with dead space — reads as a small
    square inside a wide frame even when the file is 16:9)

Run this AFTER keyframes and BEFORE clips. Anything it flags is far cheaper
to re-roll now (cents) than after animation (dollars).

Usage:
  python check_frames.py --frames frames/ --aspect 16:9
  python check_frames.py --frames frames/ --aspect 16:9 --exclude style_frame

Exit code is non-zero if any frame is flagged, so it can gate automation.
Requires Pillow (pip install pillow). Falls back to aspect-only check if
Pillow is missing.
"""

import argparse
import glob
import os
import sys


def target_ratio(aspect):
    w, h = aspect.split(":")
    return int(w) / int(h)


def empty_fraction(path, grid_x=16, grid_y=9):
    """Fraction of the frame that is flat, empty background.

    Splits the image into a grid and marks each cell as 'content' if its
    local color variation is above a small threshold. Returns the fraction
    of cells that are empty. This catches BOTH symmetric borders and
    asymmetric dead space (subject shoved to one side), which is what makes
    a 16:9 file still read as a small boxed shape floating in the frame."""
    try:
        from PIL import Image, ImageStat
    except ImportError:
        return None
    im = Image.open(path).convert("RGB")
    w, h = im.size
    cw, ch = w // grid_x, h // grid_y
    empty = 0
    total = 0
    for gy in range(grid_y):
        for gx in range(grid_x):
            box = (gx * cw, gy * ch, (gx + 1) * cw, (gy + 1) * ch)
            cell = im.crop(box)
            stat = ImageStat.Stat(cell)
            # average per-channel stddev = how much detail/variation in cell
            variation = sum(stat.stddev) / 3
            total += 1
            if variation < 8:  # near-flat cell = empty background
                empty += 1
    return empty / total if total else 0.0


def main():
    p = argparse.ArgumentParser(description="Gate keyframes before clip generation")
    p.add_argument("--frames", required=True, help="Directory of keyframe PNGs")
    p.add_argument("--aspect", default="16:9", help="Target aspect ratio, e.g. 16:9 or 9:16")
    p.add_argument("--exclude", action="append", default=[],
                   help="Filename substring to skip (repeatable, e.g. style_frame)")
    p.add_argument("--empty-limit", type=float, default=0.45,
                   help="Flag if flat/empty background exceeds this fraction of the frame")
    args = p.parse_args()

    target = target_ratio(args.aspect)
    frames = sorted(glob.glob(os.path.join(args.frames, "block_*.png")))
    if not frames:
        frames = sorted(glob.glob(os.path.join(args.frames, "*.png")))
    frames = [f for f in frames if not any(x in os.path.basename(f) for x in args.exclude)]
    if not frames:
        sys.exit(f"No keyframes found in {args.frames}")

    from PIL import Image  # optional; guarded below
    flagged = []
    print(f"Checking {len(frames)} keyframes against {args.aspect} (ratio {target:.3f})\n")
    for f in frames:
        name = os.path.basename(f)
        try:
            im = Image.open(f)
            w, h = im.size
        except Exception:
            # Pillow missing or unreadable; skip dimension detail
            print(f"  {name}: (could not open — install pillow for full check)")
            continue
        ratio = w / h
        ratio_off = abs(ratio - target) / target > 0.02
        empty = empty_fraction(f)
        empty_off = empty is not None and empty > args.empty_limit

        issues = []
        if ratio_off:
            issues.append(f"aspect {w}x{h} (ratio {ratio:.3f} != {target:.3f})")
        if empty_off:
            issues.append(f"sparse/boxed composition ({empty*100:.0f}% of frame is empty background)")

        if issues:
            flagged.append(name)
            print(f"  FLAG {name}: " + "; ".join(issues))
        else:
            e = f", {empty*100:.0f}% empty" if empty is not None else ""
            print(f"  ok   {name}: {w}x{h}{e}")

    print()
    if flagged:
        print(f"{len(flagged)} frame(s) flagged — re-roll these before generating clips:")
        for n in flagged:
            print(f"  - {n}")
        sys.exit(1)
    print("All keyframes passed. Safe to generate clips.")


if __name__ == "__main__":
    main()
