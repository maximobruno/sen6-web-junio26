"""List the narration voices available to this member.

If ELEVENLABS_API_KEY is set, lists THEIR ElevenLabs voices (cloned and
custom included) so they can pick their own. Otherwise lists fal's stock
ElevenLabs voices.

Usage:  python list_voices.py
"""

import os
import sys

import requests

STOCK = [
    ("Rachel", "warm female — safe default"),
    ("Bella", "soft female"),
    ("Adam", "deep male"),
    ("Antoni", "warm male"),
    ("Elli", "young female"),
    ("Josh", "deep young male"),
]


def main():
    ek = os.environ.get("ELEVENLABS_API_KEY")
    if ek:
        r = requests.get("https://api.elevenlabs.io/v1/voices",
                         headers={"xi-api-key": ek}, timeout=60)
        r.raise_for_status()
        voices = r.json().get("voices", [])
        if not voices:
            print("Your ElevenLabs account has no voices yet.")
            return
        print("Your ElevenLabs voices (use the name or id with --voice):\n")
        for v in voices:
            cat = v.get("category", "")
            tag = " [cloned]" if cat == "cloned" else (" [custom]" if cat == "generated" else "")
            print(f"  {v.get('name'):<24} {v.get('voice_id')}{tag}")
    else:
        print("Stock ElevenLabs voices via fal (connect your own ElevenLabs "
              "key for cloned/custom voices):\n")
        for name, desc in STOCK:
            print(f"  {name:<10} — {desc}")


if __name__ == "__main__":
    main()
