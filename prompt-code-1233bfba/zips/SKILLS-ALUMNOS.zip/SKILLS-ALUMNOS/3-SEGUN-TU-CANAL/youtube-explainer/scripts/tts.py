"""Generate the narration voiceover.

Two paths, chosen automatically:

  1. If ELEVENLABS_API_KEY is set, use the member's OWN ElevenLabs account.
     This unlocks their full voice library — including cloned voices and
     custom voices — not just the stock ones. Pass --voice as either the
     voice name or the voice_id.

  2. Otherwise, fall back to fal's stock ElevenLabs voices via FAL_KEY
     (Rachel, Adam, Bella, Antoni, ...). This keeps the one-key setup working
     for members who have not connected their own ElevenLabs.

Usage:
  python tts.py --text "full narration" --voice "Rachel" --out narration.mp3
  python tts.py --text "..." --voice "My Cloned Voice" --out narration.mp3

Requires: requests (always), fal-client (only for the fallback path).
"""

import argparse
import os
import sys

import requests

ELEVEN_MODEL = "eleven_turbo_v2_5"


def eleven_list(key):
    r = requests.get("https://api.elevenlabs.io/v1/voices",
                     headers={"xi-api-key": key}, timeout=60)
    r.raise_for_status()
    return r.json().get("voices", [])


def eleven_resolve(voices, wanted):
    """Match the requested voice by id first, then case-insensitive name."""
    for v in voices:
        if v.get("voice_id") == wanted:
            return v["voice_id"], v.get("name", wanted)
    for v in voices:
        if v.get("name", "").lower() == wanted.lower():
            return v["voice_id"], v.get("name")
    return None, None


def eleven_tts(key, voice_id, text, out):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    r = requests.post(url,
                      headers={"xi-api-key": key, "accept": "audio/mpeg",
                               "content-type": "application/json"},
                      json={"text": text, "model_id": ELEVEN_MODEL},
                      timeout=300)
    r.raise_for_status()
    with open(out, "wb") as f:
        f.write(r.content)


def fal_tts(text, voice, out):
    import fal_client
    res = fal_client.subscribe("fal-ai/elevenlabs/tts/turbo-v2.5",
                               arguments={"text": text, "voice": voice})
    url = None
    for k in ("audio", "audio_url", "audio_file"):
        v = res.get(k)
        if isinstance(v, dict) and v.get("url"):
            url = v["url"]; break
        if isinstance(v, str) and v.startswith("http"):
            url = v; break
    if not url:
        sys.exit(f"No audio URL in fal result: {res}")
    a = requests.get(url, timeout=300); a.raise_for_status()
    with open(out, "wb") as f:
        f.write(a.content)


def main():
    p = argparse.ArgumentParser(description="Generate narration voiceover")
    p.add_argument("--text", required=True)
    p.add_argument("--voice", required=True, help="Voice name or ElevenLabs voice_id")
    p.add_argument("--out", default="narration.mp3")
    args = p.parse_args()

    ek = os.environ.get("ELEVENLABS_API_KEY")
    if ek:
        voices = eleven_list(ek)
        vid, vname = eleven_resolve(voices, args.voice)
        if not vid:
            names = ", ".join(v.get("name", "?") for v in voices) or "(none found)"
            sys.exit(f"Voice '{args.voice}' not found in your ElevenLabs library.\n"
                     f"Your voices: {names}")
        print(f"ElevenLabs (your account) — voice: {vname}")
        eleven_tts(ek, vid, args.text, args.out)
    else:
        if not os.environ.get("FAL_KEY"):
            sys.exit("Neither ELEVENLABS_API_KEY nor FAL_KEY is set.")
        print(f"fal stock ElevenLabs — voice: {args.voice}")
        fal_tts(args.text, args.voice, args.out)

    print(f"Saved {args.out} ({os.path.getsize(args.out)/1e6:.2f} MB)")


if __name__ == "__main__":
    main()
