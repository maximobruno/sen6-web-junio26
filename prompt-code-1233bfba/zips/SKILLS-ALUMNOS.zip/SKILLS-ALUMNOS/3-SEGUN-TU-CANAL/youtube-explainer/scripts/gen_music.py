"""Generate a music bed FROM the script's emotional arc via the ElevenLabs Music API.

Build the --prompt from the SCRIPT: name the genre + instruments and the ARC you
want (sparse -> rising percussion/ostinato -> climax -> resolve), matched to where
the narration's tension builds and pays off. Never ask for "minimal / ambient /
restrained / drone" — that produces a flat hum; the bed must BUILD.

Uses the member's OWN ElevenLabs plan (same ELEVENLABS_API_KEY as tts.py).

Usage:
  python gen_music.py --prompt "<music description built from the script>" \
      --seconds 60 --out audio/music.mp3
"""
import argparse
import os
import sys

import requests


def main():
    p = argparse.ArgumentParser(description="Script-driven music bed (ElevenLabs Music)")
    p.add_argument("--prompt", required=True,
                   help="Music description built from the script's arc (build + climax)")
    p.add_argument("--seconds", type=int, default=60, help="Track length in seconds")
    p.add_argument("--out", default="audio/music.mp3")
    args = p.parse_args()

    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        sys.exit("ELEVENLABS_API_KEY not set (music uses the member's own ElevenLabs plan).")

    r = requests.post(
        "https://api.elevenlabs.io/v1/music",
        headers={"xi-api-key": key, "content-type": "application/json"},
        json={"prompt": args.prompt, "music_length_ms": int(args.seconds * 1000)},
        timeout=600,
    )
    ct = r.headers.get("content-type", "")
    if r.status_code == 200 and "audio" in ct:
        with open(args.out, "wb") as f:
            f.write(r.content)
        print(f"Saved {args.out} ({len(r.content) / 1e6:.2f} MB, ~{args.seconds}s)")
    else:
        sys.exit(f"ElevenLabs Music failed: HTTP {r.status_code} {ct}\n{r.text[:400]}")


if __name__ == "__main__":
    main()
