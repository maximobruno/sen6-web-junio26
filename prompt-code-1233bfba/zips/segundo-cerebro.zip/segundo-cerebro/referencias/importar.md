# Traer lo que Claude ya sabe del alumno

## 1. Claude Code (esta compu)
Solo lectura, nunca mover ni borrar:
- `~/.claude/CLAUDE.md` (instrucciones globales)
- `~/.claude/projects/*/memory/*.md` (memorias que Claude Code fue guardando por proyecto)
- Si el alumno nombra otras carpetas con un `CLAUDE.md` (proyectos suyos), leelas también con su permiso.

Quedate con hechos sobre él: quién es, a qué se dedica, proyectos, objetivos, decisiones, preferencias, herramientas que usa. Ignorá instrucciones técnicas que no le sirvan al cerebro.

## 2. La app o la web de Claude (claude.ai): pedido para pegar
Que abra un chat nuevo en claude.ai (si usa Proyectos, mejor dentro del proyecto que más use) y pegue esto:

> Escribime todo lo que sabés o recordás de mí por nuestras conversaciones: quién soy, a qué me dedico, mis proyectos y en qué estado están, mis objetivos, decisiones que tomé y por qué, mis preferencias, herramientas que uso, gente con la que trabajo y cualquier dato importante. Ordenalo por temas, con fechas si las sabés. No inventes nada: si algo no lo sabés, no lo pongas. No incluyas contraseñas ni claves. Dámelo en un solo bloque para copiar.

Que copie la respuesta y te la pegue en Claude Code (o la guarde como .txt en RAW).

## 3. Historial completo (opcional)
claude.ai → Configuración → Privacidad → **Exportar datos**. Llega un link por email con un zip (conversations.json y otros). Se tira el zip o la carpeta en `RAW/`. Leelo por partes: buscá hechos sobre él y sus proyectos, no copies las conversaciones.

## Cómo queda
`RAW/AAAA-MM-DD-lo-que-claude-sabe-de-mi.md`:

```
# Lo que Claude sabe de mí (AAAA-MM-DD)
## Quién soy            — dato · (fuente)
## Proyectos            — ...
## Objetivos            — ...
## Decisiones y porqués — ...
## Preferencias         — ...
## Herramientas         — ...
```
Antes de guardarlo, mostrale un resumen y preguntá si saca algo.
