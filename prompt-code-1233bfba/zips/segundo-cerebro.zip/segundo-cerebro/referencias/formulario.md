# Formulario inicial

Hacé las preguntas **de a una**. Mostrá las opciones numeradas para que el alumno conteste con un número. Si escribe otra cosa, aceptala.

---

## 1. Nombre y lugar

> ¿Cómo querés que se llame tu cerebro y dónde lo guardo?
> 1. `CEREBRO` en el Escritorio (`~/Desktop/CEREBRO`) — recomendado
> 2. Otro nombre en el Escritorio (decime cuál)
> 3. Otra carpeta (pegame la ruta)

Si en la pregunta 2 elige "todo junto" y acepta separar, los nombres pasan a ser `CEREBRO-PERSONAL` y `CEREBRO-NEGOCIO` (o los que prefiera) en el mismo lugar.

## 2. Para qué lo querés

> ¿Para qué lo vas a usar principalmente?
> 1. Vida personal (salud, hábitos, plata propia, metas)
> 2. Negocio digital (productos, clientes, números)
> 3. Canal de YouTube (nicho, ideas, guiones, métricas)
> 4. Estudio (cursos, libros, apuntes)
> 5. Todo junto

Si elige **5**: "Te recomiendo armar **dos cerebros separados**: uno PERSONAL y uno NEGOCIO. Lo personal (salud, familia, tu plata) no se mezcla con el negocio: así cada respuesta sale más limpia y lo privado queda aparte. ¿Armamos los dos? 1. Sí, dos cerebros  2. No, uno solo con todo".

## 3. A qué te dedicás

> Contame en 2 o 3 líneas a qué te dedicás y qué proyecto tenés hoy.
> Ejemplo: "Trabajo en relación de dependencia y estoy arrancando un canal faceless de historia. Llevo 3 videos subidos."

## 4. Tus 3 objetivos (90 días)

> ¿Cuáles son tus 3 objetivos para los próximos 90 días? Cuanto más concretos, mejor.
> Ejemplo: "1. Subir 24 videos  2. Llegar a 1.000 suscriptores  3. Ahorrar para una compu nueva"

## 5. Temas iniciales de la wiki

Sugerí según la respuesta 2 y preguntá: "¿Te sirven estos? Podés sacar, sumar o cambiar. 1. Así están bien  2. Quiero cambiar algunos".

| Tipo | Temas sugeridos |
|---|---|
| Vida personal | `salud`, `habitos`, `finanzas-personales`, `metas`, `aprendizajes` |
| Negocio digital | `productos`, `clientes`, `numeros`, `contenido`, `ideas`, `pendientes` |
| Canal de YouTube | `nicho`, `canales-de-referencia`, `ideas-de-videos`, `guiones`, `metricas` |
| Estudio | `cursos`, `libros`, `apuntes`, `dudas`, `proyectos` |
| Todo junto (1 cerebro) | `salud`, `finanzas-personales`, `metas`, `negocio`, `contenido`, `ideas`, `pendientes` |

Siempre se crean además: `perfil`, `objetivos`, `gaps`.

Ejemplos de qué tirar en RAW (para `{{EJEMPLOS_RAW}}` de BIENVENIDA.md):

- **Personal**: fotos de recetas médicas y estudios, resumen de la tarjeta, notas de libros, tu rutina de la semana.
- **Negocio**: capturas de ventas, mensajes de clientes, ideas de productos, facturas, notas de llamadas.
- **Canal**: links de canales de referencia, capturas de YouTube Studio, ideas de videos, guiones, transcripciones de videos que te gustaron.
- **Estudio**: PDFs de cursos, apuntes, transcripciones de clases, dudas que te quedaron.

## 6. Cómo te respondo

> ¿Cómo te gusta que te responda?
> 1. Corto y al grano
> 2. Detallado, con explicación

## 7. ¿Todas tus conversaciones consultan este cerebro?

> ¿Querés que cada vez que hables con Claude Code (en cualquier carpeta) mire tu cerebro antes de responder sobre tu vida o tu negocio?
> 1. Sí
> 2. No, solo cuando abra Claude en la carpeta del cerebro

Si dice **1**: mostrá el bloque exacto que se agrega al final de `~/.claude/CLAUDE.md` (está en SKILL.md, Paso 1) y pedí un "sí" explícito antes de escribirlo. Si el archivo ya existe, se agrega al final sin pisar nada.
