# Cómo usar tu segundo cerebro ({{NOMBRE}})

**Vos solo tocás `RAW/`. El resto lo ordena Claude.**

1. **Tirá cosas en `RAW/`** — lo que sea y sin ordenar: notas, PDFs, capturas, transcripciones, exports, mensajes copiados. Si querés, ponele la fecha adelante al nombre (`2026-10-27-idea.txt`), pero no hace falta.
2. **Abrí Claude Code en esta carpeta** (`{{RUTA}}`) y decile:
   - **"procesá RAW"** → lee lo nuevo y actualiza la wiki
   - **"¿qué dice mi cerebro sobre X?"** → te responde con lo tuyo y te dice de dónde lo sacó
   - **"guardá esto"** → la respuesta queda en `OUTPUTS/` con fecha
   - **"¿cuáles son mis gaps?"** → las 3 cosas que más le faltan a tu cerebro
   - **"resumen de la semana"** → qué entró, qué cambió y qué quedó pendiente
3. **Mirá `WIKI/index.md`** cuando quieras ver todo de un vistazo. Se ve lindo en Obsidian (gratis), pero cualquier editor de texto sirve.

**No tires nunca** contraseñas, claves ni tokens. Todo esto vive en tu compu: nadie más lo ve.

Las reglas que sigue Claude están en `CLAUDE.md`. No hace falta que lo toques.
