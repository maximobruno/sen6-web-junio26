# Gaps

Las 3 cosas que más le faltan a tu cerebro para ayudarte con tus [[objetivos]].
Actualizado: {{FECHA}}

## Vigentes

{{GAP_1}}

{{GAP_2}}

{{GAP_3}}

<!-- Formato de cada gap:
### 1. <Qué falta>
- **Por qué importa:** <atado a un objetivo>
- **Qué tirar en RAW:** <archivo o nota concreta>
-->

## Resueltos

_Ninguno todavía._

## Fuentes

- Formulario inicial, {{FECHA}}
