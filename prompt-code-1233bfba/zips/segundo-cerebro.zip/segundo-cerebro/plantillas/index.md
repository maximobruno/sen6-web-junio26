# {{NOMBRE}} — Índice

Mapa de todo lo que hay en tu cerebro. Lo mantiene Claude.
Actualizado: {{FECHA}}

## Vos

- [[perfil]] — quién sos, a qué te dedicás y cómo te gusta que te respondan
- [[objetivos]] — tus 3 objetivos a 90 días y cómo vas
- [[gaps]] — lo que más le falta a tu cerebro ahora

## Temas

{{TEMAS}}

## Outputs

_Todavía no hay. Cuando digas "guardá esto", aparecen acá con fecha._

## Fuentes

- Formulario inicial, {{FECHA}}
