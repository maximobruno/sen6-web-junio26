# Bienvenido a tu RAW

Esta carpeta es tu **cajón de sastre**. Tirá acá todo lo que quieras que tu cerebro recuerde, **sin ordenar nada**.

## Qué podés tirar

- Notas sueltas (.txt, .md, notas copiadas del celular)
- PDFs (cursos, contratos, estudios, facturas)
- Capturas de pantalla (métricas, mensajes, ideas que viste)
- Transcripciones de videos, llamadas o audios
- Audios: mejor transcriptos (pegá el texto en una nota)
- Exports (planillas, CSV, resúmenes de cuenta)

Para tu cerebro de **{{PARA_QUE}}**, por ejemplo:

{{EJEMPLOS_RAW}}

## Cómo seguir

1. Arrastrá el archivo a esta carpeta.
2. Abrí Claude Code en la carpeta de tu cerebro y decí **"procesá RAW"**.
3. Listo: Claude lo lee, lo ordena en `WIKI/` y te cuenta qué cambió.

## Tres reglas

- **Nunca** tires contraseñas, claves ni tokens.
- Nada de acá se borra: es tu archivo original.
- Todo queda en tu compu. Igual, no tires nada que no quieras que lea Claude.

_No borres `_procesado.md`: es el registro de lo que ya se leyó._
