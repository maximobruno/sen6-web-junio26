# Skill "segundo-cerebro"

Te arma un **segundo cerebro** en tu compu: una carpeta donde tirás todo sin ordenar (notas, PDFs, capturas, transcripciones) y Claude lo ordena en una wiki, te responde con tu información real y te dice qué le falta.

## Cómo instalarla

**Opción fácil (recomendada)**

1. Descomprimí el zip. Te queda una carpeta `segundo-cerebro` en Descargas.
2. Abrí Claude Code y decile:

   > instalá la skill que está en Descargas/segundo-cerebro

**Opción manual**

Copiá la carpeta `segundo-cerebro` entera dentro de `~/.claude/skills/` (en Mac: Finder → Ir → Ir a la carpeta… → `~/.claude/skills`). Si la carpeta `skills` no existe, creala.

Después cerrá y volvé a abrir Claude Code.

## Cómo arrancar

En Claude Code escribí:

> armá mi segundo cerebro

Te hace 7 preguntas cortas (de a una, con opciones numeradas), te arma la carpeta y hace una primera prueba con vos.

## Después, todos los días

- **"procesá RAW"** → ordena lo nuevo que tiraste
- **"¿qué dice mi cerebro sobre X?"** → te responde con lo tuyo
- **"guardá esto"** → guarda la respuesta con fecha
- **"¿cuáles son mis gaps?"** → lo que más le falta a tu cerebro
- **"resumen de la semana"** → qué entró y qué cambió

Todo queda en tu compu. Nunca tires contraseñas ni claves en el cerebro.
