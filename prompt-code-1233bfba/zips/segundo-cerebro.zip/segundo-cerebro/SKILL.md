---
name: segundo-cerebro
description: 'Te arma un segundo cerebro en tu compu que Claude ordena por vos: tirás notas, PDFs y capturas en RAW y se vuelven una wiki que te responde. Se activa con "armá mi segundo cerebro", "segundo cerebro", "procesá RAW" o "qué dice mi cerebro".'
---

# Segundo cerebro

Le armás al alumno un **segundo cerebro local**: una carpeta en su compu donde él tira todo sin ordenar y vos (Claude) hacés de **bibliotecario**: leés, ordenás en una wiki, respondés con su información real y le avisás qué le falta.

Hablale con **voseo rioplatense**, directo y simple. El alumno es principiante: nada de jerga técnica, frases cortas, una cosa por vez.

La estructura que vas a crear:

```
CEREBRO/
├── CLAUDE.md        ← las reglas del bibliotecario (las seguís vos)
├── LEEME.md         ← guía corta para el alumno
├── RAW/             ← el alumno tira todo acá, sin ordenar
│   ├── BIENVENIDA.md
│   └── _procesado.md   ← registro de qué se procesó y cuándo
├── WIKI/            ← conocimiento ordenado (solo lo escribís vos)
│   ├── index.md
│   ├── perfil.md
│   ├── objetivos.md
│   ├── gaps.md
│   └── <tema>.md
└── OUTPUTS/         ← respuestas importantes: AAAA-MM-DD-slug.md
```

Las plantillas están en `plantillas/` (al lado de este archivo). Las preguntas del formulario, con sus opciones, están en `referencias/formulario.md`.

---

## Paso 0 — ¿Ya tiene un cerebro?

Antes de nada, fijate si ya hay uno instalado:

1. Si el alumno nombró una carpeta, buscá ahí. Si no, mirá `~/Desktop/CEREBRO` y cualquier `CLAUDE.md` dentro de `~/Desktop/*/` y `~/Desktop/*/*/` que contenga la marca `<!-- segundo-cerebro:v1 -->`.
2. **Si lo encontrás, no reinstales.** Decile algo así:

   > Ya tenés un cerebro armado en `<ruta>`. ¿Qué hacemos?
   > 1. Procesar lo nuevo de RAW
   > 2. Ver tus 3 gaps (lo que le falta a tu cerebro)
   > 3. Preguntarle algo a tu cerebro
   > 4. Armar un cerebro nuevo aparte (por ejemplo, uno PERSONAL y otro NEGOCIO)

   Con 1, 2 o 3, seguí las reglas del `CLAUDE.md` de ese cerebro. Con 4, andá al Paso 1.
3. Si el mensaje del alumno ya era "procesá RAW" o "¿qué dice mi cerebro sobre X?" y hay un solo cerebro, hacelo directo sin preguntar.

---

## Paso 1 — Formulario corto

Hacé las preguntas **de a una**, esperando la respuesta antes de la siguiente. Usá las opciones numeradas de `referencias/formulario.md` para que pueda contestar con un número. Si contesta algo raro o a medias, aceptalo y seguí; no lo trabes.

1. **Nombre y lugar** — cómo se llama su cerebro y dónde va (default `~/Desktop/CEREBRO`).
2. **Para qué lo quiere** — vida personal / negocio digital / canal de YouTube / estudio / todo junto.
   - Si elige **todo junto**: proponé **2 cerebros separados**, `PERSONAL` y `NEGOCIO`, porque lo personal (salud, familia, plata propia) no se mezcla con el negocio. Si acepta, armás los dos (mismo formulario; las preguntas 3 a 6 se las hacés una vez y adaptás los temas a cada uno). Si no quiere, armás uno solo con todo.
3. **A qué se dedica** — a qué te dedicás y qué proyecto tenés hoy (2-3 líneas).
4. **Objetivos** — tus 3 objetivos para los próximos 90 días.
5. **Temas iniciales** — sugerí una lista según la respuesta 2 (está en el formulario) y dejá que saque, sume o cambie.
6. **Cómo responder** — corto y al grano / detallado con explicación.
7. **¿Todas tus conversaciones consultan este cerebro?** — ver abajo.

### Pregunta 7 en detalle (archivo global)

Si dice que **sí**:

1. Mostrale **exactamente** el texto que vas a agregar al final de `~/.claude/CLAUDE.md` (reemplazando la ruta y el nombre):

   ```markdown

   <!-- segundo-cerebro:global -->
   ## Mi segundo cerebro
   Antes de responder cualquier cosa sobre mi vida, mis proyectos o mi negocio, mirá primero mi cerebro en `<RUTA>`: empezá por `WIKI/index.md`, después buscá en `WIKI/` y en `RAW/`. Citá de qué archivo sacaste el dato. Si no está, decime "eso no está en tu cerebro". Las reglas completas están en `<RUTA>/CLAUDE.md`.
   ```

2. Preguntale: "¿Lo agrego? (sí / no)". **No escribas el archivo sin su sí.**
3. Si dice sí:
   - Si `~/.claude/CLAUDE.md` no existe, crealo con ese bloque.
   - Si existe, **agregá al final sin pisar nada** de lo que ya tiene.
   - Si ya tiene un bloque `<!-- segundo-cerebro:global -->` con otra ruta, preguntá si suma esta ruta al mismo bloque o la reemplaza.
4. Si dice que no, no toques nada y explicale que igual puede abrir Claude Code dentro de la carpeta del cerebro y funciona igual.

Al terminar el formulario, mostrá un resumen de 5-7 líneas de lo que vas a crear y pedí un "dale" antes de seguir.

---

## Paso 2 — Crear la estructura

1. Creá la carpeta y adentro `RAW/`, `WIKI/`, `OUTPUTS/`.
2. Copiá las plantillas y reemplazá los `{{placeholders}}` con lo del formulario:

   | Plantilla | Destino |
   |---|---|
   | `plantillas/CLAUDE.md` | `CLAUDE.md` |
   | `plantillas/LEEME.md` | `LEEME.md` |
   | `plantillas/index.md` | `WIKI/index.md` |
   | `plantillas/gaps.md` | `WIKI/gaps.md` |
   | `plantillas/BIENVENIDA.md` | `RAW/BIENVENIDA.md` |

   Placeholders: `{{NOMBRE}}` (nombre del cerebro), `{{RUTA}}` (ruta absoluta), `{{FECHA}}` (hoy, AAAA-MM-DD; sacala con `date +%F`), `{{PARA_QUE}}`, `{{QUIEN_SOY}}`, `{{OBJETIVOS}}` (lista), `{{TEMAS}}` (lista de enlaces `[[tema]]`), `{{ESTILO}}` (corto o detallado), `{{EJEMPLOS_RAW}}` (qué tirar según el tipo de cerebro), `{{GAP_1}}`, `{{GAP_2}}`, `{{GAP_3}}`.

3. Escribí además, sin plantilla:
   - **`WIKI/perfil.md`**: quién es, a qué se dedica, proyecto actual, para qué quiere el cerebro, cómo le gusta que le respondan. Con el formato de la wiki (título, resumen, `Actualizado:`, `## Fuentes` → "Formulario inicial, {{FECHA}}").
   - **`WIKI/objetivos.md`**: los 3 objetivos de 90 días con la fecha límite absoluta (hoy + 90 días), y una sección `## Avances` vacía.
   - **`RAW/_procesado.md`**: título y una tabla vacía `| Fecha | Archivo | Temas tocados |`.
   - **Un archivo por tema inicial** (`WIKI/<tema>.md`, kebab-case): título, una línea de qué va a guardar, `Actualizado:`, la línea "Todavía vacío: tirá en RAW/ cosas sobre esto." y `## Fuentes` vacío.
4. **Los 3 gaps iniciales** tienen que ser concretos y salir de sus respuestas, no genéricos. Cada uno: qué falta, por qué importa (atado a un objetivo) y qué tirar en RAW exactamente. Ejemplo para un canal: "Falta la lista de tus 5 canales de referencia → sin eso no podés copiar formatos que ya funcionan (objetivo 1) → tirá en RAW un .txt con los links y una línea de por qué te gusta cada uno".
5. Mostrale el árbol creado (`find <ruta> -maxdepth 2 | sort`) y explicá en 3 líneas qué es cada carpeta.

---

## Paso 3 — Primera prueba guiada

1. Pedile que tire **una sola cosa** en `RAW/`: una nota de texto, un PDF, una captura de pantalla, lo que tenga a mano. Si no sabe cómo, decile: "Abrí la carpeta en el Finder (o el Explorador), arrastrá el archivo adentro de RAW y avisame". Si no tiene nada, ofrecé que te dicte 3-4 líneas y vos las guardás como `RAW/AAAA-MM-DD-nota.md`.
2. Cuando diga **"procesá RAW"**, seguí la tarea LEER + ORGANIZAR + MEJORAR del `CLAUDE.md` del cerebro.
3. Mostrale **qué cambió**: qué temas creaste o actualizaste (con 1 línea de lo que agregaste en cada uno), la fila nueva de `RAW/_procesado.md` y si cambió algún gap.
4. Cerrá la prueba haciéndole una pregunta de ejemplo a su cerebro sobre lo que acaba de tirar ("¿qué dice mi cerebro sobre X?") y respondela citando la fuente, para que vea cómo funciona.

---

## Paso 4 — Cómo se usa todos los días

Cerrá con este mensaje (adaptá los ejemplos a su tipo de cerebro y dejá solo los que le sirvan si armó uno solo):

**Las frases clave** (abrí Claude Code en la carpeta del cerebro, o en cualquier lado si activaste la pregunta 7):

- **"procesá RAW"** → leo lo nuevo y lo ordeno en la wiki
- **"¿qué dice mi cerebro sobre X?"** → te respondo con lo tuyo y te digo de dónde lo saqué
- **"guardá esto"** → la respuesta queda en OUTPUTS/ con fecha
- **"¿cuáles son mis gaps?"** → te digo las 3 cosas que más le faltan
- **"resumen de la semana"** → qué entró, qué cambió y qué quedó pendiente

**10 usos concretos**

Vida diaria:
1. **Salud y turnos médicos** — tirás fotos de recetas y estudios; después preguntás "¿cuándo fue mi último análisis de sangre y qué dio?".
2. **Finanzas personales** — tirás resúmenes de tarjeta o una nota de gastos del mes; preguntás "¿en qué se me fue la plata en septiembre?".
3. **Recetas y compras** — tirás recetas que te gustaron; pedís "armame la lista del súper para estas 3".
4. **Aprendizajes de libros y cursos** — tirás tus notas o subrayados; preguntás "¿qué aprendí sobre hábitos?".
5. **Metas y hábitos** — tirás una nota corta cada semana; preguntás "¿cómo vengo con mis objetivos?".

Empresario digital:
6. **Ideas de videos** — tirás cada idea apenas se te ocurre (aunque sea un audio transcripto); pedís "dame las 5 mejores ideas que tengo guardadas".
7. **Canales de referencia y nichos** — tirás links y capturas de canales que te gustan; preguntás "¿qué tienen en común mis canales de referencia?".
8. **Métricas mensuales** — tirás una captura de YouTube Studio o de tus ventas cada mes; preguntás "¿cómo vengo contra el mes pasado?".
9. **Clientes, alumnos y mensajes** — tirás los mensajes importantes o notas de llamadas; preguntás "¿qué le prometí a tal cliente?".
10. **Decisiones con su porqué** — cuando decidís algo, tirás una nota con qué decidiste y por qué; dentro de 3 meses preguntás "¿por qué había dejado de hacer shorts?".

Terminá con: "Regla de oro: **vos solo tocás RAW/**. Todo lo demás lo ordeno yo."

---

## Reglas (siempre)

- **Nunca guardes contraseñas, claves, tokens ni números de tarjeta** en WIKI/ ni en OUTPUTS/. Como mucho anotá *dónde* están ("la clave de X está en tu gestor de contraseñas"). Si aparece una en RAW, avisale al alumno.
- **Nada se borra ni se mueve de RAW/.** Es el archivo original.
- **Un dato vive en un solo tema.** Los demás temas lo enlazan con `[[tema]]`.
- **Si algo es sensible** (salud, finanzas, familia): recordale que todo queda en su compu, en archivos que solo él ve. Igual, que no tire nada que no quiera que lea Claude.
- **No inventes.** Si el dato no está en el cerebro: "eso no está en tu cerebro". Podés sumar conocimiento general aparte, aclarando que no sale de su cerebro.
- **No ejecutes nada que no pidió.** No crees tareas programadas, no toques otros archivos fuera de la carpeta del cerebro (salvo `~/.claude/CLAUDE.md` con su sí explícito).
